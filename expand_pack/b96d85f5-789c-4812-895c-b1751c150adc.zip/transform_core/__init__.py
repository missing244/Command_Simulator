from typing import Dict,Union,List,Tuple,Literal,TypedDict
import re
class TOKEN(TypedDict) :
    type: str
    token: Union[str, int, float]

STAR_TEST = re.compile("^[\\u002a]{1,}")
New_Execute_Syntax:bool = False
Command_Version:tuple = None
BLOCKSTATE_SYNTAX:bool = False
Command_Parser_Tree = None
SettingSave = None



def Analysis_Setting(Setting) :
    global BLOCKSTATE_SYNTAX, Command_Version, New_Execute_Syntax, Command_Parser_Tree, SettingSave
    
    BLOCKSTATE_SYNTAX = Setting[2] >= 2
    Command_Version = ((1,19,0), (1,19,50))[Setting[1]]
    New_Execute_Syntax = bool(Setting[1])
    Command_Parser_Tree = command_tree.Generate_Parser_Tree(Setting[0], Setting[1], Setting[2])
    SettingSave = Setting

def Command_Str_Transfor(Command:str, FastPath:TOKEN=None) :

    if FastPath is None :
        if STAR_TEST.search(Command) :
            return ("语法错误: >>***<<\n错误位于字符0至3", command_tree.BaseMatch.Not_Match("", pos=(0,3)))
        else :
            token_list = Command_Parser_Tree.parser(Command, Command_Version)
            if isinstance(token_list, tuple) : return token_list
            if token_list[0]["type"] == "Any_Command" : return token_list[0]["token"]
    else : token_list = FastPath

    if token_list[0]["token"] == "execute" :
        if SettingSave[0][0] : return execute.Start_Transformer(BLOCKSTATE_SYNTAX, token_list, New_Execute_Syntax)

        if Command_Version == (1,19,0) : Pass_Execute_Index = transfor.Pass_Command_execute_1_19_0(token_list)
        elif Command_Version == (1,19,50) : Pass_Execute_Index = transfor.Pass_Command_execute_1_19_50(token_list)

        if token_list[Pass_Execute_Index]["token"] in {"fill", "setblock", "testforblock", "clone"} :
            a = blocks.Start_Transformer(BLOCKSTATE_SYNTAX, token_list[Pass_Execute_Index:])
            b = Command[0:token_list[Pass_Execute_Index]["start"]]
            return "".join((b, a))
        elif token_list[Pass_Execute_Index]["token"] == "summon" :
            a = summon.Start_Transformer(token_list[Pass_Execute_Index:])
            b = Command[0:token_list[Pass_Execute_Index]["start"]]
            return "".join((b, a))
        elif token_list[Pass_Execute_Index]["token"] == "structure" :
            a = structure.Start_Transformer(token_list[Pass_Execute_Index:])
            b = Command[0:token_list[Pass_Execute_Index]["start"]]
            return "".join((b, a))
        else : return Command
    elif token_list[0]["token"] in {"fill", "setblock", "testforblock", "clone"} :
        return blocks.Start_Transformer(BLOCKSTATE_SYNTAX, token_list)
    elif token_list[0]["token"] == "summon" :
        return summon.Start_Transformer(token_list)
    elif token_list[0]["token"] == "structure" :
        return structure.Start_Transformer(token_list)
    


from . import command_tree
from . import transfor
from . import execute,blocks,summon,structure