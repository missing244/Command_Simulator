import tkinter, os, sys, pickle, random, time, json, tkinter.messagebox
import webbrowser, tkinter.font, re, copy, traceback, base64
sys.path.append(os.path.realpath(os.path.join(__file__, os.pardir)))
base_path = os.path.dirname(os.path.abspath(__file__))

import tkinter.ttk as ttk
from package.file_operation import PathSandBox
import package.tk_tool as tk_tool
from typing import Dict, List, Literal, Union

class DataError(Exception) : pass
SandBoxPath = PathSandBox("[EXP]Rawtext_Json")
Copy_Content:List[Union[str, dict]] = []
tk_component = {"file_select": tkinter.Listbox, "pack_frame":tkinter.Frame, 
    "input_widget":tkinter.Text, "output_widget":tkinter.Text}
InputBoxSettingFunction = None


def random_name() :
    l1 = random.randint(0, 2**32-1).to_bytes(4, "big")
    return base64.b32encode(l1).decode()


def Copy_event(widget:tkinter.Text) :
    Copy_Content.clear()
    try : widget.index(tkinter.SEL_FIRST)
    except : return None

    RawData = RawtextType.translate_ui.Text_get_content(widget, tkinter.SEL_FIRST, tkinter.SEL_LAST)
    Copy_Content.extend(RawData)
    
    tk_tool.copy_to_clipboard(widget.get(tkinter.SEL_FIRST, tkinter.SEL_LAST))

def Paste_event(widget:tkinter.Text) :
    if not hasattr(widget, "rawtext_sign") : 
        widget.event_generate("<<Paste>>")
        widget.see(tkinter.INSERT)
        return "break"

    if widget.clipboard_get() != "".join( Content for Content in Copy_Content if isinstance(Content, str) ) :
        widget.event_generate("<<Paste>>")
        widget.see(tkinter.INSERT)
        return "break"
    
    for Content in Copy_Content :
        try : widget.delete(tkinter.SEL_FIRST, tkinter.SEL_LAST)
        except : pass

        if isinstance(Content, str) : widget.insert(tkinter.INSERT, Content)
        else :
            inner_button = RawtextType.Text_Inner_Button(widget, widget.master.master, copy.deepcopy(Content))
            widget.window_create(tkinter.INSERT, window=inner_button)
    widget.see(tkinter.INSERT)
    return "break"

def Trans_RawtextJson(rawtext_component:list) :

    def find_return_str(str1 : str) :
        l = list(re.finditer("[\\\\]+n",str1))
        l.reverse()
        return l

    def replace_str(base:str, start:int, end:int, replace:str) -> str:
        return "".join([ base[:start] , replace , base[end:] ])


    def change_to_text(rawtext_comp:str) -> dict :
        return {"text": rawtext_comp}

    def change_to_score(rawtext_comp:dict) -> dict :
        return {"score" : {"name": rawtext_comp['name'], "objective": rawtext_comp['scoreboard']}}

    def change_to_selector(rawtext_comp:dict) -> dict :
        return {"selector" : rawtext_comp['name']}

    def change_to_translate(rawtext_comp:dict) -> dict :
        #print("rawtext_comp：",rawtext_comp)
        return {"translate":rawtext_comp['text'], "with":translate_result(rawtext_comp['json_list'])}

    def translate_result(rawtext_list:list) -> dict :
        lines_all = [[]]
        for rawtext_comp in rawtext_list :
            if not isinstance(rawtext_comp, str) : lines_all[-1].append(rawtext_comp) ; continue
            if rawtext_comp.count("\n") == 0 : lines_all[-1].append(rawtext_comp) ; continue
            split_text = rawtext_comp.split("\n")
            for index,str_line in enumerate(split_text) :
                if index > 0 : lines_all.append([])
                if str_line == "" : continue
                list_1 = find_return_str(str_line)
                mid_str1 = str_line
                for iter1 in list_1 :
                    count1 = iter1.group().count("\\")
                    if count1 == 1 : mid_str1 = replace_str(mid_str1 , iter1.start() , iter1.end() , "\n")
                    elif count1 > 1 : mid_str1 = replace_str(mid_str1 , iter1.start() , iter1.end() , "\\" * (count1 - 1) + "n")
                lines_all[-1].append(mid_str1)

        base_json = {"rawtext":[]} ; base_translate = {"translate":"", "with":{"rawtext":[]}}
        for lines, lines_comp in enumerate(lines_all) :
            if len(lines_comp) == 0 : base_json['rawtext'].append(change_to_text("")) ; continue
            for rawtext_comp in lines_comp :
                if len(lines_comp) == 1 :
                    if isinstance(rawtext_comp, str) : base_json['rawtext'].append(change_to_text(rawtext_comp))
                    if isinstance(rawtext_comp, dict) :
                        if rawtext_comp['type'] == 'score' : base_json['rawtext'].append(change_to_score(rawtext_comp))
                        elif rawtext_comp['type'] == 'selector' : base_json['rawtext'].append(change_to_selector(rawtext_comp))
                        elif rawtext_comp['type'] == 'translate' : base_json['rawtext'].append(change_to_translate(rawtext_comp))
                else :
                    if isinstance(rawtext_comp, str) : base_translate['translate'] += rawtext_comp
                    if isinstance(rawtext_comp, dict) :
                        base_translate['translate'] += '%%s'
                        m1 = {"translate" : "%%s", "with" : {"rawtext":[{"text":""}]}}
                        if rawtext_comp['type'] == 'score' : m1['with']['rawtext'].insert(0,change_to_score(rawtext_comp))
                        elif rawtext_comp['type'] == 'selector' : m1['with']['rawtext'].insert(0,change_to_selector(rawtext_comp))
                        elif rawtext_comp['type'] == 'translate' : m1['with']['rawtext'].insert(0,change_to_translate(rawtext_comp))
                        base_translate['with']['rawtext'].append(m1)
            if len(lines_comp) > 1 : 
                base_json['rawtext'].append(base_translate)
                base_translate = {"translate" : "", "with" : {"rawtext":[]}}
        
        return base_json

    Json = {"rawtext":[]}
    for con in rawtext_component : 
        if isinstance(con, str) : Json['rawtext'].append(change_to_text(con))
        if isinstance(con, dict) :
            if con['type'] == 'score' : Json['rawtext'].append(change_to_score(con))
            elif con['type'] == 'selector' : Json['rawtext'].append(change_to_selector(con))
            elif con['type'] == 'translate' : Json['rawtext'].append(change_to_translate(con))
    return Json


def Text_add_button(last:tkinter.Frame, raw_type:Literal["selector","score","translate"]) :
    focus_comp:tkinter.Text = main_window.focus_input
    if not isinstance(focus_comp, tkinter.Text) : return None
    if not hasattr(focus_comp, "rawtext_sign") : return None
    
    inner_button = RawtextType.Text_Inner_Button(focus_comp, last, raw_type)
    focus_comp.window_create(tkinter.INSERT, window=inner_button)

def Batch_add_button() :
    focus_comp:tkinter.Text = main_window.focus_input
    def combobox_select_change(e:tkinter.Event) :
        list1 = [frame_score, frame_selector, frame_translate]
        for index,element in enumerate(list1) :
            if index == e.widget.current() : element.pack()
            else : element.pack_forget()

    self = tkinter.Toplevel(main_window.window)
    small_win_width, small_win_height = int(self.master.winfo_width()*0.95), int(self.master.winfo_height()*0.60)
    self.resizable(False, False)
    self.geometry('%sx%s+%s+%s'%(small_win_width, small_win_height, self.master.winfo_x(),self.master.winfo_y()))
    self.transient(self.master)
    self.title('setting')

    tkinter.Label(self,text="",fg='black',font=tk_tool.get_default_font(3),width=15,height=1).pack()
    frame_m11 = tkinter.Frame(self) ; frame_m11.pack()
    tkinter.Label(frame_m11,text="按钮类型",bg="#b0b0b0",fg='black',font=tk_tool.get_default_font(12),width=10,height=1).pack(side=tkinter.LEFT)
    input0 = ttk.Combobox(frame_m11, font=tk_tool.get_default_font(13), width=6, state='readonly', justify='center')
    input0["value"] = ("分数", "实体", "翻译")
    input0.current(0)
    input0.bind("<<ComboboxSelected>>", combobox_select_change)
    input0.pack(side=tkinter.LEFT)

    tkinter.Label(self,text="",fg='black',font=tk_tool.get_default_font(3),width=15,height=1).pack()
    frame_m11 = tkinter.Frame(self) ; frame_m11.pack()
    tkinter.Label(frame_m11,text="按钮数量",bg="#b0b0b0",fg='black',font=tk_tool.get_default_font(12),width=8,height=1).pack(side=tkinter.LEFT)
    input1 = tkinter.Entry(frame_m11,font=tk_tool.get_default_font(12),justify='center',width=11)
    input1.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a)) 
    input1.insert(tkinter.END, "5")
    input1.pack(side=tkinter.LEFT)

    tkinter.Label(self,text="",fg='black',font=tk_tool.get_default_font(3),width=15,height=1).pack()
    tkinter.Label(self,text="按钮间分隔字符",bg="#b0b0b0",fg='black',font=tk_tool.get_default_font(12),width=16,height=1).pack()
    input2 = tkinter.Text(self,font=tk_tool.get_default_font(12),width=20,height=2)
    input2.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a))
    input2.pack()

    def update0() : 
        try : 
            if int(input1.get()) < 1 : raise Exception
        except : tkinter.messagebox.showerror("Error","按钮数量应为正整数")
        else :
            if not hasattr(focus_comp, "rawtext_sign") : self.destroy() ; return None
            main_window.focus_input = focus_comp
            times = int(input1.get())
            if input0.current() == 0 : data = {"annotation":"score%s", "type":"score", "scoreboard":score_input1.get(), "name":score_input2.get()}
            elif input0.current() == 1 : data = {"annotation":"selector%s", "type":"selector", "name":selector_input1.get()}
            elif input0.current() == 2 : data = {"annotation":"translate%s", "type":"translate", "text":translate_input1.get("1.0",tkinter.END)[:-1], "json_list":[]}
            for i in range(times) :
                copy_data = data.copy()
                copy_data["annotation"] = data["annotation"] % i
                inner_button = RawtextType.Text_Inner_Button(focus_comp, ["score","selector","translate"][input0.current()], copy_data)
                focus_comp.window_create(tkinter.INSERT, window=inner_button)
                if (i < (times - 1)) : focus_comp.insert(tkinter.INSERT, input2.get("0.0",tkinter.END)[:-1])
            self.destroy()
    def update1() : 
        main_window.focus_input = focus_comp

    tkinter.Label(self,text="",fg='black',font=tk_tool.get_default_font(3),width=15,height=1).pack()
    frame_score = tkinter.Frame(self)
    frame_m11 = tkinter.Frame(frame_score) ; frame_m11.pack()
    tkinter.Label(frame_m11,text="计分板名",bg="#b0b0b0",fg='black',font=tk_tool.get_default_font(12),
        width=8,height=1).pack(side=tkinter.LEFT)
    score_input1 = tkinter.Entry(frame_m11,font=tk_tool.get_default_font(12),justify='center',width=11)
    score_input1.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a)) 
    score_input1.insert(tkinter.END,"aaa")
    score_input1.pack(side=tkinter.LEFT)

    tkinter.Label(frame_score,text="",fg='black',font=tk_tool.get_default_font(3),width=15,height=1).pack()
    frame_m12 = tkinter.Frame(frame_score) ; frame_m12.pack()
    tkinter.Label(frame_m12,text="目标选择器",bg="#b0b0b0",fg='black',font=tk_tool.get_default_font(12),width=8,height=1).pack()
    score_input2 = tkinter.Entry(frame_m12,font=tk_tool.get_default_font(12),justify='center',width=22)
    score_input2.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a)) 
    score_input2.insert(tkinter.END,"@s[scores={aaa=..1}]")
    score_input2.pack()
    frame_score.pack()

    frame_selector = tkinter.Frame(self)
    frame_m12 = tkinter.Frame(frame_selector) ; frame_m12.pack()
    tkinter.Label(frame_m12,text="目标选择器",bg="#b0b0b0",fg='black',font=tk_tool.get_default_font(12),width=8,height=1).pack()
    selector_input1 = tkinter.Entry(frame_m12,font=tk_tool.get_default_font(12),justify='center',width=22)
    selector_input1.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a)) 
    selector_input1.insert(tkinter.END, "@s")
    selector_input1.pack()

    frame_translate = tkinter.Frame(self)
    frame_m12 = tkinter.Frame(frame_translate) ; frame_m12.pack()
    tkinter.Label(frame_m12,text="翻译基本内容",bg="#b0b0b0",fg='black',font=tk_tool.get_default_font(12),width=12,height=1).pack()
    translate_input1 = tkinter.Text(frame_m12,font=tk_tool.get_default_font(12),width=22,height=2)
    translate_input1.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a)) 
    translate_input1.insert(tkinter.END,"%%s")
    translate_input1.pack()


    tkinter.Button(self,text='确    定',font=tk_tool.get_default_font(13),bg='aquamarine',width=9,height=1,
        command=lambda : update0()).pack(side="bottom")
    self.protocol("WM_DELETE_WINDOW", lambda:[update1(), self.destroy()])
    self.grab_set()


class RawtextType :
# {"name": "", "prefix":"", "text_to_json":[]}
# str -> text ; 
# {"annotation":"", "type":"score", "scoreboard":"", "name":""} ; 
# {"annotation":"", "type":"selector", "name":""}
# {"annotation":"", "type":"translate", "text":"", "json_list":[]} ; 
# "json_list" -> str score selector translate
    class RawtextWidget(tkinter.Text) :

        def __init__(self, master, *arg, **karg) :
            super().__init__(master, *arg, **karg)
            self.current_maker: str = "1.0"
            self.rawtext_sign = True
            def update0(e) : self.current_maker = self.index(tkinter.INSERT)
            self.bind("<ButtonRelease-1>", update0, add="+")
            self.bind("<KeyPress>", update0, add="+")

        def reset_current_marker(self) :
            self.see(self.current_maker)
            self.mark_set(tkinter.INSERT, self.current_maker)

    class Text_Inner_Button(tkinter.Frame) :

        def __init__(self, master, last:tkinter.Frame, raw_data:Union[str, dict], **karg) :
            super().__init__(master, **karg)
            self.last_frame = last
            self.rawtext_dict:dict = raw_data
            self.rawtext_ui: Union[RawtextType.selector_ui, RawtextType.score_ui, RawtextType.translate_ui] = None

            if raw_data == "score" : self.rawtext_dict = {"annotation":"score", "type":"score", "scoreboard":"", "name":""}
            elif raw_data == "selector" : self.rawtext_dict = {"annotation":"selector", "type":"selector", "name":""}
            elif raw_data == "translate" : self.rawtext_dict = {"annotation":"translate", "type":"translate", "text":"", "json_list":[]}

            left1 = tkinter.Label(self,text=" ",fg='black',font=tk_tool.get_default_font(9),width=1,height=1)
            left1.bind("<Button-1>", lambda a:self.see_TEXT_index(master, self, 0))
            left1.pack(side=tkinter.LEFT)
            self.button1 = button1 = tkinter.Button(self, text=self.rawtext_dict["annotation"], font=tk_tool.get_default_font(8))
            button1.config(command=self.win_open)
            button1.pack(side=tkinter.LEFT)
            right1 = tkinter.Label(self,text=" ",fg='black',font=tk_tool.get_default_font(9),width=1,height=1)
            right1.bind("<Button-1>", lambda a:self.see_TEXT_index(master, self, 1))
            right1.pack(side=tkinter.LEFT)

        @staticmethod
        def see_TEXT_index(focus_input:tkinter.Text, frame1:tkinter.Frame, add_value:int) :
            "设置光标位置"
            if not hasattr(focus_input, "rawtext_sign") : return None
            button_content = focus_input.dump("0.0", tkinter.END, window=True)
            button_content_text = [i[1] for i in button_content]
            if str(frame1) not in button_content_text : return None
            index1 = button_content_text.index(str(frame1))
            list1 = button_content[index1][2].split(".")
            list1[1] = str(int(list1[1]) + add_value)
            focus_input.focus_set()
            focus_input.mark_set(tkinter.INSERT,".".join(list1))

        def win_open(self) :
            self.last_frame.pack_forget()
            if self.rawtext_dict["type"] == "score" : 
                self.rawtext_ui = RawtextType.score_ui(tk_component["pack_frame"], self, self.rawtext_dict)
            elif self.rawtext_dict["type"] == "selector" : 
                self.rawtext_ui = RawtextType.selector_ui(tk_component["pack_frame"], self, self.rawtext_dict)
            elif self.rawtext_dict["type"] == "translate": 
                self.rawtext_ui = RawtextType.translate_ui(tk_component["pack_frame"], self, self.rawtext_dict)
            self.rawtext_ui.pack()
            self.rawtext_ui.set_forcus()

        def win_close(self) :
            self.rawtext_dict = self.rawtext_ui.to_dict()
            self.button1.config(text=self.rawtext_dict["annotation"])
            self.rawtext_ui.destroy()
            self.last_frame.pack()
            if hasattr(self.last_frame, "set_forcus") : self.last_frame.set_forcus()
            else : 
                tk_component["input_widget"].event_generate("<FocusIn>")
                tk_component["input_widget"].event_generate("<Button-1>")
                tk_component["input_widget"].reset_current_marker()
            self.rawtext_ui = None

    class score_ui(tkinter.Frame) : 

        def __init__(self, master, button, data:dict, **karg) :
            super().__init__(master, **karg)
            self.raference_button:RawtextType.Text_Inner_Button = button
            self.raw_data = data.copy()

            tkinter.Label(self,text="注释",fg='black',font=tk_tool.get_default_font(12),width=15, bg="#9D9D9D").pack()
            self.input0 = input0 = tkinter.Entry(self,font=tk_tool.get_default_font(12),justify='center',width=25)
            input0.insert(tkinter.END, self.raw_data['annotation'])
            input0.pack()

            tkinter.Label(self,text="",fg='black',font=('Arial',6),width=15,height=1).pack()
            tkinter.Label(self,text="计分板名称",fg='black',font=tk_tool.get_default_font(12),width=15, bg="#9D9D9D").pack()
            self.input1 = input1 = tkinter.Entry(self,font=tk_tool.get_default_font(12),justify='center',width=25)
            input1.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a)) 
            input1.insert(tkinter.END, self.raw_data['scoreboard'])
            input1.pack()

            tkinter.Label(self,text="",fg='black',font=('Arial',6),width=15,height=1).pack()
            tkinter.Label(self,text="假名或目标选择器",fg='black',font=tk_tool.get_default_font(12),width=15, bg="#9D9D9D").pack()
            self.input2 = input2 = tkinter.Text(self,font=tk_tool.get_default_font(12),width=25,height=6)
            input2.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a)) 
            input2.insert(tkinter.END, self.raw_data['name'])
            input2.pack()

            def update0() : self.raw_data['annotation'] = input0.get()
            def update1() : self.raw_data['scoreboard'] = input1.get()
            def update2() : self.raw_data['name'] = input2.get("1.0", "end-1c")
            tkinter.Label(self,text="",fg='black',font=tk_tool.get_default_font(10),width=15,height=1).pack()
            tkinter.Button(self,text=' 确    定 ', font=tk_tool.get_default_font(13), bg='aquamarine', width=10, height=1,
                command=lambda : [update0(), update1(), update2(), self.on_close()]).pack()

            self.set_forcus = lambda : input2.event_generate("<FocusIn>")

        def to_dict(self) :
            return self.raw_data

        def on_close(self) :
            self.raference_button.win_close()

    class selector_ui(tkinter.Frame) : 

        def __init__(self, master, button, data:dict, **karg) :
            super().__init__(master, **karg)
            self.raference_button:RawtextType.Text_Inner_Button = button
            self.raw_data = data.copy()

            tkinter.Label(self,text="注释",fg='black',font=tk_tool.get_default_font(12),width=15, bg="#9D9D9D").pack()
            self.input0 = input0 = tkinter.Entry(self,font=tk_tool.get_default_font(12),justify='center',width=25)
            input0.insert(tkinter.END, self.raw_data['annotation'])
            input0.pack()
            
            tkinter.Label(self,text="",fg='black',font=('Arial',15),width=15,height=1).pack()
            tkinter.Label(self,text="目标选择器",fg='black',font=tk_tool.get_default_font(12), width=15, bg="#9D9D9D").pack()
            self.input1 = input1 = tkinter.Text(self,font=tk_tool.get_default_font(12),width=25,height=8)
            input1.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a)) 
            input1.insert(tkinter.END, self.raw_data['name'])
            input1.pack()

            def update0() : self.raw_data['annotation'] = input0.get()
            def update1() : self.raw_data['name'] = input1.get("1.0", "end-1c")
            tkinter.Label(self,text="",fg='black',font=tk_tool.get_default_font(10),width=15,height=1).pack()
            tkinter.Button(self,text=' 确    定 ',font=tk_tool.get_default_font(13), bg='aquamarine', width=10, height=1,
                command=lambda : [update0(), update1(), self.on_close()]).pack()
            
            self.set_forcus = lambda : input1.event_generate("<FocusIn>")

        def to_dict(self) :
            return self.raw_data

        def on_close(self) :
            self.raference_button.win_close()

    class translate_ui(tkinter.Frame) :

        def __init__(self, master, button, data:dict, **karg) :
            super().__init__(master, **karg)
            self.raference_button:RawtextType.Text_Inner_Button = button
            self.raw_data = data

            tkinter.Label(self,text="注释",fg='black',font=tk_tool.get_default_font(12), width=15, bg="#9D9D9D").pack()
            input0 = tkinter.Entry(self,font=tk_tool.get_default_font(12),justify='center',width=25)
            input0.insert(tkinter.END,self.raw_data['annotation'])
            input0.pack()

            tkinter.Label(self,text="",fg='black',font=tk_tool.get_default_font(1),width=15,height=1).pack()
            tkinter.Label(self,text="基本内容",fg='black',font=tk_tool.get_default_font(12), width=20, bg="#9D9D9D").pack()
            frame_m10 = tkinter.Frame(self)
            sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
            input1 = tkinter.Text(frame_m10,font=tk_tool.get_default_font(12),width=23,height=6,yscrollcommand=sco1.set,undo=True)
            input1.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a)) 
            input1.insert(tkinter.END,self.raw_data['text'])
            sco1.config(command=input1.yview)
            input1.grid() ; sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
            frame_m10.pack()

            tkinter.Label(self,text="",fg='black',font=tk_tool.get_default_font(1),width=15,height=1).pack()
            tkinter.Label(self,text="with列表(一行一个元素)",fg='black',font=tk_tool.get_default_font(12), width=20, bg="#9D9D9D").pack()
            frame_m10 = tkinter.Frame(self)
            sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
            sco2 = tkinter.Scrollbar(frame_m10,orient="horizontal")
            input2 = RawtextType.RawtextWidget(frame_m10,font=tk_tool.get_default_font(10), width=26, height=7,
                wrap=tkinter.NONE,yscrollcommand=sco1.set,xscrollcommand=sco2.set,undo=True)
            input2.bind("<FocusIn>",lambda a:InputBoxSettingFunction(a))
            input2.bind("<Control-c>", lambda e: Copy_event(e.widget), add="+")
            input2.bind("<Control-x>", lambda e: Copy_event(e.widget), add="+")
            input2.bind("<Control-v>", lambda e: Paste_event(e.widget))
            self.content_to_component(input2, self.raw_data['json_list'])
            sco1.config(command=input2.yview) ; sco2.config(command=input2.xview)
            input2.grid() ; sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
            sco2.grid(sticky=tkinter.E+tkinter.W)
            frame_m10.pack()

            tkinter.Label(self, text="",fg='black',font=tk_tool.get_default_font(6), width=15, height=1).pack()
            frame_m6 = tkinter.Frame(self) ; frame_m6.pack()
            tkinter.Button(frame_m6,text=tk_tool.platform_string('分数'),font=tk_tool.get_default_font(10), bg="#00e183", 
                command=lambda: Text_add_button(self, "score")).pack(side='left')
            tkinter.Label(frame_m6, text="  ",fg='black',font=tk_tool.get_default_font(3)).pack(side='left')
            tkinter.Button(frame_m6,text=tk_tool.platform_string('名字'),font=tk_tool.get_default_font(10), bg='#00e183', 
                command=lambda: Text_add_button(self, "selector")).pack(side='left')
            tkinter.Label(frame_m6, text="  ",fg='black',font=tk_tool.get_default_font(3)).pack(side='left')
            tkinter.Button(frame_m6,text=tk_tool.platform_string('翻译'),font=tk_tool.get_default_font(10), bg='#00e183',
                command=lambda: Text_add_button(self, "translate")).pack(side='left')
            tkinter.Label(frame_m6, text="  ",fg='black',font=tk_tool.get_default_font(3)).pack(side='left')
            tkinter.Button(frame_m6,text=tk_tool.platform_string('批量'),font=tk_tool.get_default_font(10), bg="#e45eff", 
                command=Batch_add_button).pack(side='left')


            def update0() : self.raw_data['annotation'] = input0.get()
            def update1() : self.raw_data['text'] = input1.get("0.0",tkinter.END)[:-1]
            def update2() : self.raw_data["json_list"] = self.Text_get_content(input2)
            tkinter.Label(self,text="",fg='black',font=tk_tool.get_default_font(6),width=15,height=1).pack()
            tkinter.Button(self,text='确    定',font=tk_tool.get_default_font(13),bg='aquamarine', width=10, height=1,
                        command=lambda:[update0(), update1(), update2(), self.on_close()]).pack(side="bottom")

            self.set_forcus = lambda : [input2.event_generate("<FocusIn>"),
                input2.reset_current_marker(), input2.event_generate("<ButtonRelease-1>")]

        @staticmethod
        def content_to_component(input_text:tkinter.Text, content_list:List[Union[str, dict]]) : 
            """反序列化"""
            widget = input_text.master.master
            for i in content_list :
                if isinstance(i, str) : input_text.insert(tkinter.END, i)
                elif isinstance(i, dict) : 
                    inner_button = RawtextType.Text_Inner_Button(input_text, widget, i)
                    input_text.window_create(tkinter.END, window=inner_button)

        @staticmethod
        def Text_get_content(text_obj:tkinter.Text, sel_start="1.0", sel_end="end-1c") : 
            """将Text内容对象进行序列化"""
            button_content = text_obj.dump(sel_start, sel_end, window=True)

            result_list = []
            start_pos = sel_start
            for content_type, content, pos in button_content :
                text_get = text_obj.get(start_pos, pos)
                if text_get : result_list.append(text_get)
                result_list.append( text_obj.nametowidget(content).rawtext_dict )
                start_pos = pos

            text_get = text_obj.get(start_pos, sel_end)
            if text_get : result_list.append(text_get)
            return result_list


        def to_dict(self) :
            return self.raw_data

        def on_close(self) :
            self.raference_button.win_close()


class pack_class : 

    def __init__(self) -> None : 
        Old_File_Path = os.path.join(base_path, 'rawtext_saves')
        if os.path.isfile(Old_File_Path) : 
            with open(Old_File_Path, 'rb') as f:
                try : old_save_data = pickle.load(f)
                except : old_save_data = []
            for data in old_save_data :
                _file = SandBoxPath.file_operate("internal", random_name()+".rtj", 'w', encoding="utf-8")
                json.dump(data, _file)
                _file.close()
            os.remove(Old_File_Path)

        self.FileVersion = 0
        self.__file_list:dict = {}
        self.current_file:str = None
        self.current_file_data:dict = {}
        
        self.__hash1 = -1
        self.__hash2 = -1
        self.flash_timestemp = time.time()
        self.save_timestemp = time.time()

    def loop_method(self) :
        if not isinstance(tk_component["file_select"], tkinter.Listbox) : return None

        if self.current_file is not None and time.time() > self.save_timestemp :
            self.save_timestemp = time.time() + 120
            RawData = RawtextType.translate_ui.Text_get_content(tk_component["input_widget"])
            self.current_file_data["text_to_json"] = RawData
            str1 = json.dumps(self.current_file_data)
            if self.__hash2 != hash(str1) :
                self.__hash2 = hash(str1)
                self.save_file()

        file_list = {}
        for location, path_type, name in SandBoxPath.list_dirs("all", "") :
            if path_type != "file" : continue
            if not name.endswith(".rtj") : continue

            if location == "internal" : file_name = "[内部]" + name[:-4]
            else : file_name = "[外部]" + name[:-4]

            file_list[file_name] = [location, name]

        if self.__file_list != file_list :
            self.__file_list = file_list
            tk_component["file_select"].delete(0, tkinter.END)
            tk_component["file_select"].insert(tkinter.END, *file_list)


    def check_integrity_V0(self, json1:dict, init=True) :
        if init and not isinstance( json1, dict) : raise DataError("起始数据非字典类型")
        if init and not isinstance( json1.get("name", None), str ) : raise DataError("字典无或错误 name")
        if init and not isinstance( json1.get("text_to_json", None), list ) : raise DataError("字典无或错误 text_to_json")
        if init and "prefix" not in json1 : json1["prefix"] = "execute as @a run titleraw @s actionbar"

        for i in json1 :
            if not isinstance(i, (str, dict)) : raise DataError("RawObject中存在非法数据")
            if isinstance(i, str) : continue

            if not isinstance(i.get("annotation", None), str) : raise DataError("RawObject字典无或错误 annotation")
            if i.get("type", None) not in ("score",'selector','translate') : raise DataError("RawObject字典无或错误 type")
            if i['type'] == "score" and not isinstance(i.get('scoreboard', None), str) : raise DataError("RawScore字典无或错误 scoreboard")
            if i['type'] == "score" and not isinstance(i.get('name', None), str) : raise DataError("RawScore字典无或错误 name")
            if i['type'] == "selector" and not isinstance(i.get('name', None), str) : raise DataError("RawSelector字典无或错误 name")
            if i['type'] == "translate" and not isinstance(i.get('text', None), str) : raise DataError("RawTranslate字典无或错误 text")
            if i['type'] == "translate" and not isinstance(i['json_list'], list) : raise DataError("RawTranslate字典无或错误 json_list")
            if i['type'] == "translate" : self.check_integrity_V0(i['json_list'], False)

        self.current_file_data = json1


    def print_name(self, listbox1:tkinter.Listbox, label1:tkinter.Label) : 
        if not listbox1.curselection() : return None

        file_name = listbox1.get( listbox1.curselection()[0] )
        file_per_data = self.__file_list[file_name]
        _file = SandBoxPath.file_operate(file_per_data[0], file_per_data[1], "r", encoding="utf-8")
        try : Json1 = json.load(_file)
        except : 
            label1.config(text="(文件错误，数据损坏)")
            _file.close()
            return None

        if "name" not in Json1 : label1.config(text="项目名：(文件错误，数据损坏)")
        else : label1.config(text="项目名：" + Json1["name"])
        _file.close()

    def create_file(self, listbox1:tkinter.Listbox) : 
        Template_Data = {'name': 'Json模板%s'%random.randint(0, 100000), "text_to_json": []}
        file_save_name = random_name() + ".rtj"
        _file = SandBoxPath.file_operate("internal", file_save_name, "w", encoding="utf-8")
        json.dump(Template_Data, _file)
        _file.close()

        file_name = "[内部]" + file_save_name[:-4]
        self.__file_list[file_name] = ["internal", file_save_name]
        listbox1.insert(0, file_name)
        listbox1.select_clear(0, "end")
        listbox1.selection_set(0)

    def delete_file(self, listbox1:tkinter.Listbox) : 
        if not listbox1.curselection() : return None
        a = tkinter.messagebox.askquestion("Q","二次确认\n是否删除该模板？")
        if a != "yes" : return None

        file_name = listbox1.get( listbox1.curselection()[0] )
        file_per_data = self.__file_list[file_name]
        SandBoxPath.delete_path(file_per_data[0], file_per_data[1])
        del self.__file_list[file_name]
        listbox1.delete( listbox1.curselection()[0] )

        tkinter.messagebox.showinfo("Info", "已删除Json模板")


    def open_file(self, listbox1:tkinter.Listbox, entry1:tkinter.Entry, text1:tkinter.Entry, text2:tkinter.Text) :
        if not listbox1.curselection() : return None
        
        file_name = listbox1.get( listbox1.curselection()[0] )
        file_per_data = self.__file_list[file_name]
        _file = SandBoxPath.file_operate(file_per_data[0], file_per_data[1], "r", encoding="utf-8")

        try : JsonContant = json.load(fp=_file)
        except : tkinter.messagebox.showerror("Error", "加载错误：\n文件数据损坏") ; return None
        self.current_file_data.clear()
        FileVersion = JsonContant.get("Version", 0)
        try :
            if FileVersion == 0 : self.check_integrity_V0(JsonContant)
            elif FileVersion == 1 : self.check_integrity_V1(JsonContant)
        except DataError as e :
            tkinter.messagebox.showerror("Error", "文件加载错误：\n%s\nVersion: %s" % (e.args[0], FileVersion))
            return False

        text1.delete("0.0", tkinter.END)
        text2.delete("0.0", tkinter.END)
        entry1.delete("0", tkinter.END)
        entry1.insert("0", self.current_file_data["name"])
        text1.insert("0.0", self.current_file_data["prefix"])
        RawtextType.translate_ui.content_to_component(text2, self.current_file_data["text_to_json"])
        self.current_file = file_per_data
        self.flash_timestemp = time.time() + 2
        self.save_timestemp = time.time() + 120
        return True

    def save_file(self, exit=False) :
        RawData = RawtextType.translate_ui.Text_get_content(tk_component["input_widget"])
        self.current_file_data["text_to_json"] = RawData

        SaveFileData = {"Version":self.FileVersion}
        SaveFileData.update( (i, j) for i, j in self.current_file_data.items() if i != "Version" )
        _file = SandBoxPath.file_operate(self.current_file[0], self.current_file[1], "w", encoding="utf-8")
        json.dump(SaveFileData, _file)
        _file.close()

        if exit : 
            self.__hash1 = -1
            self.__hash2 = -1
            self.current_file = None
            self.current_file_data.clear()
            tkinter.messagebox.showinfo("Info","已成功保存rawtext内容")



def UI_set(main_win, tkinter_Frame:tkinter.Frame) :
    global main_window, tk_component, InputBoxSettingFunction
    main_window = main_win
    InputBoxSettingFunction = main_win.set_focus_input
    pack_object:pack_class = main_win.get_expand_pack_class_object("b61a9a5c-0831-4d2a-b4bd-56513876be27")

    if "主界面" :
        tkinter.Label(tkinter_Frame, text="  ",fg='black',font=tk_tool.get_default_font(6)).pack()
        main_frame = tkinter.Frame(tkinter_Frame) ; main_frame.pack()
        tkinter.Label(main_frame,text="Rawtext Json",fg='black',font=tk_tool.get_default_font(20),width=15,height=1).pack()
        tkinter.Label(main_frame, text="",fg='black',font=tk_tool.get_default_font(1), width=2, height=1).pack()

        def open_process(e=None) :
            if pack_object.open_file(file_select, Json_title, Json_Prefix, expand_input_1) :
                main_frame.pack_forget()
                edit_frame.pack()
                expand_input_1.event_generate("<FocusIn>")

        frame_m10 = tkinter.Frame(main_frame)
        sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
        file_select = tkinter.Listbox(frame_m10,font=tk_tool.get_default_font(12),selectmode=tkinter.SINGLE,
            height=15,width=24,yscrollcommand=sco1.set)
        file_select.grid()
        sco1.config(command=file_select.yview)
        sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
        file_select.bind("<ButtonRelease-1>", lambda e : pack_object.print_name(e.widget, name_printer) )
        file_select.bind("<Double-ButtonRelease-1>", open_process)
        frame_m10.pack()

        tkinter.Label(main_frame, text="   ", font=tk_tool.get_default_font(2)).pack()
        name_printer = tkinter.Label(main_frame, text="项目名：(点击列表项目获取)", font=tk_tool.get_default_font(10), 
            fg="#357fff", width=20, anchor="w")
        name_printer.pack()

        tkinter.Label(main_frame, text="",fg='black',font=tk_tool.get_default_font(1), width=2, height=1).pack()
        frame_m6 = tkinter.Frame(main_frame) ; frame_m6.pack()
        tkinter.Button(frame_m6,text=tk_tool.platform_string('新建'),font=tk_tool.get_default_font(12),bg='#9ae9d1', height=1,
            command=lambda: pack_object.create_file(file_select) ).grid(row=0, column=0)
        tkinter.Label(frame_m6,fg='black',font=tk_tool.get_default_font(6),width=2,height=1).grid(row=0, column=1)
        tkinter.Button(frame_m6,text=tk_tool.platform_string('删除'),font=tk_tool.get_default_font(12),bg='#9ae9d1', height=1,
            command=lambda: pack_object.delete_file(file_select) ).grid(row=0, column=2)
        tkinter.Label(frame_m6,fg='black',font=tk_tool.get_default_font(6),width=2,height=1).grid(row=0, column=3)
        tkinter.Button(frame_m6,text=tk_tool.platform_string('打开'),font=tk_tool.get_default_font(12),bg='#9ae9d1', height=1,
            command=open_process).grid(row=0, column=4)

        tkinter.Label(main_frame, text="   ", font=tk_tool.get_default_font(2)).pack()
        frame_m6 = tkinter.Frame(main_frame) ; frame_m6.pack()
        tkinter.Label(frame_m6, text="第一次使用请\n阅读帮助文档", font=tk_tool.get_default_font(9), fg="red").grid(row=1, column=0)
        tkinter.Label(frame_m6,fg='black',font=tk_tool.get_default_font(6),width=2,height=1).grid(row=1, column=1)
        tkinter.Button(frame_m6,text=tk_tool.platform_string('帮助文档'),font=tk_tool.get_default_font(12),bg='#7fc8ff', height=1, command=lambda: 
            webbrowser.open("http://localhost:32323/?pack=b61a9a5c-0831-4d2a-b4bd-56513876be27&page=help") ).grid(row=1, column=2)

    if "编辑界面" :
        edit_frame = tkinter.Frame(tkinter_Frame)

        def update0(e:tkinter.Event) : pack_object.current_file_data["name"] = e.widget.get()
        def update1(e:tkinter.Event) : pack_object.current_file_data["prefix"] = e.widget.get("0.0", "end-1c")

        Json_title = tkinter.Entry(edit_frame,font=tk_tool.get_default_font(13), width=18,justify='center')
        Json_title.event_add("<<update-status>>","<KeyRelease>", "<ButtonRelease>")
        Json_title.bind("<<update-status>>", update0)
        Json_title.bind("<FocusIn>", lambda a : InputBoxSettingFunction(a))
        Json_title.pack()
        tkinter.Label(edit_frame, text="",fg='black',font=tk_tool.get_default_font(6), width=15, height=1).pack()

        tkinter.Label(edit_frame, text=" 前缀文字(拼接RawJson) ",fg='black',bg="#9D9D9D",
            width=18, font=tk_tool.get_default_font(12)).pack()
        Json_Prefix = tkinter.Text(edit_frame, font=tk_tool.get_default_font(10), width=28, height=3)
        Json_Prefix.event_add("<<update-status>>","<KeyRelease>", "<ButtonRelease>")
        Json_Prefix.bind("<<update-status>>", update1)
        Json_Prefix.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a))
        Json_Prefix.pack()
        tkinter.Label(edit_frame, text="",fg='black',font=tk_tool.get_default_font(6), width=15, height=1).pack()

        tkinter.Label(edit_frame, text=" RawJson正文 ", fg='black', bg="#9D9D9D",
            width=18, font=tk_tool.get_default_font(12)).pack()
        frame_m10 = tkinter.Frame(edit_frame)
        sco1 = tkinter.Scrollbar(frame_m10, orient='vertical')
        sco2 = tkinter.Scrollbar(frame_m10, orient="horizontal")
        expand_input_1 = RawtextType.RawtextWidget(frame_m10,show=None,wrap=tkinter.NONE, height=11, width=26,
            font=tk_tool.get_default_font(10),undo=True,yscrollcommand=sco1.set,xscrollcommand=sco2.set)
        expand_input_1.grid()
        expand_input_1.bind("<FocusIn>", lambda a : InputBoxSettingFunction(a))
        expand_input_1.bind("<Control-c>", lambda e: Copy_event(e.widget), add="+")
        expand_input_1.bind("<Control-x>", lambda e: Copy_event(e.widget), add="+")
        expand_input_1.bind("<Control-v>", lambda e: Paste_event(e.widget))
        sco1.config(command=expand_input_1.yview)
        sco2.config(command=expand_input_1.xview)
        sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
        sco2.grid(sticky=tkinter.W+tkinter.E)
        frame_m10.pack()

        tkinter.Label(edit_frame, text="",fg='black',font=tk_tool.get_default_font(6), width=15, height=1).pack()
        frame_m6 = tkinter.Frame(edit_frame) ; frame_m6.pack()
        tkinter.Button(frame_m6,text=tk_tool.platform_string('分数'),font=tk_tool.get_default_font(10), bg="#00e183", 
            command=lambda: Text_add_button(edit_frame, "score")).pack(side='left')
        tkinter.Label(frame_m6, text="  ",fg='black',font=tk_tool.get_default_font(3)).pack(side='left')
        tkinter.Button(frame_m6,text=tk_tool.platform_string('名字'),font=tk_tool.get_default_font(10), bg='#00e183', 
            command=lambda: Text_add_button(edit_frame, "selector")).pack(side='left')
        tkinter.Label(frame_m6, text="  ",fg='black',font=tk_tool.get_default_font(3)).pack(side='left')
        tkinter.Button(frame_m6,text=tk_tool.platform_string('翻译'),font=tk_tool.get_default_font(10), bg='#00e183',
            command=lambda: Text_add_button(edit_frame, "translate")).pack(side='left')
        tkinter.Label(frame_m6, text="  ",fg='black',font=tk_tool.get_default_font(3)).pack(side='left')
        tkinter.Button(frame_m6,text=tk_tool.platform_string('批量'),font=tk_tool.get_default_font(10), bg="#e45eff", 
            command=Batch_add_button).pack(side='left')

        def save_and_quit() :
            pack_object.save_file(True)
            edit_frame.pack_forget()
            main_frame.pack()

        def jump_view() :
            RawData = RawtextType.translate_ui.Text_get_content(expand_input_1)
            Json = Trans_RawtextJson(RawData)
            expand_output_1.delete("0.0", "end")
            expand_output_1.insert("end", Json_Prefix.get("1.0", "end-1c"))
            expand_output_1.insert("end", json.dumps(Json, separators=(',', ':'), ensure_ascii=False))
            expand_output_1.see("end")
            edit_frame.pack_forget()
            view_frame.pack()

        tkinter.Label(edit_frame, text="      ",fg='black',font=tk_tool.get_default_font(6)).pack()
        frame_m6 = tkinter.Frame(edit_frame) ; frame_m6.pack()
        tkinter.Button(frame_m6,text=tk_tool.platform_string('保存退出'),font=tk_tool.get_default_font(12),
            bg='#00ffff', command=save_and_quit).pack(side='left')
        tkinter.Label(frame_m6, text="   ",fg='black',font=tk_tool.get_default_font(6), height=1).pack(side='left')
        tkinter.Button(frame_m6,text=tk_tool.platform_string('进入预览'),font=tk_tool.get_default_font(12),
            bg='#00ffff', command=jump_view).pack(side='left')

    if "预览界面" : 
        view_frame = tkinter.Frame(tkinter_Frame)
        
        frame_m6 = tkinter.Frame(view_frame) ; frame_m6.pack()
        sco1 = tkinter.Scrollbar(frame_m6,orient='vertical')
        expand_output_1 = tkinter.Text(frame_m6,show=None,height=23,width=28,
            font=tk_tool.get_default_font(10), yscrollcommand=sco1.set)
        expand_output_1.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a))
        expand_output_1.grid()
        sco1.config(command=expand_output_1.yview)
        sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)

        def jump_edit() :
            edit_frame.pack()
            view_frame.pack_forget()

        def copy_json() :
            txt = expand_output_1.get("1.0", "end-1c")
            tk_tool.copy_to_clipboard(txt)

        tkinter.Label(view_frame, text="      ",fg='black',font=tk_tool.get_default_font(6)).pack()
        frame_m6 = tkinter.Frame(view_frame) ; frame_m6.pack()
        tkinter.Button(frame_m6,text=tk_tool.platform_string('返回编辑'),font=tk_tool.get_default_font(12),
            bg='#00ffff', command=jump_edit).pack(side='left')
        tkinter.Label(frame_m6, text="   ",fg='black',font=tk_tool.get_default_font(6), height=1).pack(side='left')
        tkinter.Button(frame_m6,text=tk_tool.platform_string('复制Json'),font=tk_tool.get_default_font(12),
            bg='#00ffff', command=copy_json).pack(side='left')


    tk_component = {"file_select": file_select, "pack_frame": tkinter_Frame, 
        "input_widget": expand_input_1, "output_widget": expand_output_1}
    










"""
# 批量添加新功能
"""


