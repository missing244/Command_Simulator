class IPv4_String(str) : pass
class Unsigned_Int16_Port(int) : pass
class UUID(str) : pass
class EVENT(str) : pass