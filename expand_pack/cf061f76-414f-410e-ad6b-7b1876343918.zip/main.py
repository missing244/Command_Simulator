import tkinter, os, pickle, sys, re, random, tkinter.messagebox
import math, time, string, json, webbrowser, traceback, base64
sys.path.append(os.path.realpath(os.path.join(__file__, os.pardir)))
base_path = os.path.dirname(os.path.abspath(__file__))
from tkinter import ttk
from package.file_operation import PathSandBox
import package.tk_tool as tk_tool

class DataError(Exception) : pass
class CompileError(Exception) : pass
class RuntimeError(Exception) : pass
class StopGenerate(Exception) : pass
InputBoxSettingFunction = None
TemplateStringTag = re.compile("\\$temp[0-9]+")
SandBoxPath = PathSandBox("[EXP]Commannd_Template")
tk_component = {"file_select": tkinter.Listbox}



def replace_zero(str1 : str) :
    return re.sub(r"(\.\d*?[1-9])0+$|(\.)0+$", r"\1", str1)

def random_name() :
    l1 = random.randint(0, 2**32-1).to_bytes(4, "big")
    return base64.b32encode(l1).decode()



class Single_Repeat_List(tkinter.Frame) :

    def __init__(self, master, temp_data:dict, *arg, **karg):
        super().__init__(master, *arg, **karg)

        tkTextFrame = tk_tool.tk_Scrollbar_Text(self, height=17, width=25, font=tk_tool.get_default_font(10), undo=True, wrap='none')
        tkTextFrame.pack()
        tkinter.Label(self, text="一行一个内容，依次填入模板的位置\n如果行数比模板生成次数少\n则会提前终止命令的生成。", 
            font=tk_tool.get_default_font(10), fg="#357fff").pack()

        self.tkText = tkTextFrame.input_box
        self.tkText.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a))
        self.tkText.insert("end", temp_data.get("temp_detial", ""))

    def __call__(self, globals:dict, locals:dict) :
        globals["var2"] = None
        globals["var3"] = None

        lines = globals["var1"]
        line_count = int( self.tkText.index("end-1c").split(".")[0] )
        if lines > line_count : raise StopGenerate()
        text1 = self.tkText.get("%s.0"%lines, "%s.end"%lines)
        return text1

    def dump_check(self) -> bool :
        return True

    def dumps(self) -> dict :
        return {"temp_type": 1, "temp_detial": self.tkText.get("0.0", "end-1c")}

class Repeat_List(tkinter.Frame) :

    def __init__(self, master, temp_data:dict, *arg, **karg):
        super().__init__(master, *arg, **karg)

        tkTextFrame = tk_tool.tk_Scrollbar_Text(self, height=17, width=25, font=tk_tool.get_default_font(10), undo=True, wrap='none')
        tkTextFrame.pack()
        tkinter.Label(self, text="一行一个内容，依次填入该模板的位置", font=tk_tool.get_default_font(10), fg="#357fff").pack()

        self.tkText = tkTextFrame.input_box
        self.tkText.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a))
        self.tkText.insert("end", temp_data.get("temp_detial", ""))

    def __call__(self, globals:dict, locals:dict) :
        globals["var2"] = None
        globals["var3"] = None

        line_count = int( self.tkText.index("end-1c").split(".")[0] )
        lines = ((globals["var1"]-1) % line_count) + 1
        text1 = self.tkText.get("%s.0"%lines, "%s.end"%lines)
        return text1

    def dump_check(self) -> bool :
        return True

    def dumps(self) -> dict :
        return {"temp_type": 2, "temp_detial": self.tkText.get("0.0", "end-1c")}

class Expression(tkinter.Frame) :

    def __init__(self, master, temp_data:dict, *arg, **karg):
        super().__init__(master, *arg, **karg)

        tkTextFrame = tk_tool.tk_Scrollbar_Text(self, height=17, width=25, font=tk_tool.get_default_font(10), undo=True, wrap='none')
        tkTextFrame.pack()
        tkinter.Label(self, text="通过数学计算生成结果", font=tk_tool.get_default_font(10), fg="#357fff").pack()

        self.tkText = tkTextFrame.input_box
        self.tkText.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a))
        self.tkText.insert("end", temp_data.get("temp_detial", ""))
        self.__compile_object = None

    def __call__(self, globals:dict, locals:dict) :
        if self.__compile_object is None :
            text1 = self.tkText.get("0.0", "end-1c")

            ErrorMsg = None
            try : CodeObj = compile(text1, "ExpandPack Expression", "eval")
            except SyntaxError as e : ErrorMsg = e.msg
            if ErrorMsg : raise CompileError(ErrorMsg)

            set1 = set(CodeObj.co_names) - set(globals) - set(locals)
            if len(set1) : raise CompileError("出现预期外的变量\n%s" % set1)

            self.__compile_object = CodeObj

        globals["var2"] = None
        globals["var3"] = None
        
        ErrorMsg = None
        try : ReturnVal = eval(self.__compile_object, globals, locals)
        except Exception as e : ErrorMsg = str(e)
        else : 
            if isinstance(ReturnVal, float) : 
                ReturnVal = "%.7f" % round(ReturnVal, 7)
            return ReturnVal

        if ErrorMsg : raise RuntimeError(ErrorMsg)


    def dump_check(self) -> bool :
        return True

    def dumps(self) -> dict :
        return {"temp_type": 3, "temp_detial": self.tkText.get("0.0", "end-1c")}

class Single_Line(tkinter.Frame) :

    def __init__(self, master, temp_data:dict, *arg, **karg):
        super().__init__(master, *arg, **karg)

        tkinter.Label(self, text="字段生成次数", bg="#b0b0b0", fg='black', font=tk_tool.get_default_font(13), 
            width=13, height=1).pack()
        gen_times = tkinter.Entry(self, font=tk_tool.get_default_font(10), width=25, justify='center')
        gen_times.pack()

        tkinter.Label(self, text="   ", font=tk_tool.get_default_font(6), height=1).pack()
        frame_m10 = tkinter.Frame(self) ; frame_m10.pack()
        tkinter.Label(frame_m10, text="字段间隔字符", bg="#b0b0b0", fg='black', font=tk_tool.get_default_font(13), 
            width=13, height=1).pack(side='left')
        temp_split = tkinter.Entry(frame_m10, font=tk_tool.get_default_font(13), width=7, justify='center')
        temp_split.pack(side='left')
        
        tkinter.Label(self, text="   ", font=tk_tool.get_default_font(6), height=1).pack()
        tkinter.Label(self, text="单行模板字段", bg="#b0b0b0", fg='black', font=tk_tool.get_default_font(13), 
            width=13, height=1).pack()
        tkTextFrame1 = tk_tool.tk_Scrollbar_Text(self, height=3, width=25, font=tk_tool.get_default_font(10), undo=True, wrap='none')
        tkTextFrame1.pack()

        tkinter.Label(self, text="   ", font=tk_tool.get_default_font(6), height=1).pack()
        tkinter.Label(self, text="占位符表达式", bg="#b0b0b0", fg='black', font=tk_tool.get_default_font(13), 
            width=13, height=1).pack()
        tkTextFrame2 = tk_tool.tk_Scrollbar_Text(self, height=7, width=25, font=tk_tool.get_default_font(10), undo=True, wrap='none')
        tkTextFrame2.pack()

        self.tkEntry1 = gen_times
        self.tkEntry2 = temp_split
        self.tkText1 = tkTextFrame1.input_box
        self.tkText2 = tkTextFrame2.input_box
        self.tkEntry1.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a))
        self.tkEntry2.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a))
        self.tkText1.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a))
        self.tkText2.bind("<FocusIn>",lambda a : InputBoxSettingFunction(a))
        self.tkEntry1.insert("end", temp_data.get("subtemp_repeat", ""))
        self.tkEntry2.insert("end", temp_data.get("subtemp_split", ""))
        self.tkText1.insert("end", temp_data.get("subtemp", ""))
        self.tkText2.insert("end", temp_data.get("subtemp_detial", ""))
        self.__compile_object = None
        self.__compile_times = None

    def __call__(self, globals:dict, locals:dict) :
        if self.__compile_object is None :
            ErrorMsg = None
            try : CodeObj = compile(self.tkEntry1.get(), "ExpandPack Expression", "eval")
            except SyntaxError as e : ErrorMsg = e.msg
            if ErrorMsg : raise CompileError(ErrorMsg) 

            self.__compile_object = []
            self.__compile_times = CodeObj
            text1 = self.tkText1.get("0.0", "end-1c")
            text2 = self.tkText2.get("0.0", "end-1c").split("\n")
            StrTempCount = text1.count("%s")
            if StrTempCount < len(text2) : raise CompileError("占位符表达式数量不足")

            for i in range(StrTempCount) :
                ErrorMsg = None
                try : CodeObj = compile(text2[i], "ExpandPack Expression", "eval")
                except SyntaxError as e : ErrorMsg = e.msg
                if ErrorMsg : raise CompileError("第" + str(i+1) + "行：" + ErrorMsg)

                set1 = set(CodeObj.co_names) - set(globals) - set(locals)
                if len(set1) : raise CompileError("第" + str(i+1) + "行；%s" % set1)

                self.__compile_object.append(CodeObj)

        ErrorMsg = None
        try : TempTimes = eval(self.__compile_times, globals, locals)
        except Exception as e : ErrorMsg = str(e)
        if ErrorMsg : raise RuntimeError(ErrorMsg)

        TempTimes = int(round(TempTimes, 6))
        TempStr = self.tkText1.get("0.0", "end-1c")
        AllTempList = []
        for i in range(1, TempTimes+1) :
            globals["var2"] = TempTimes
            globals["var3"] = i
            return_val_list = []

            for code in self.__compile_object :
                ErrorMsg = None
                try : ReturnVal = eval(code, globals, locals)
                except Exception as e : ErrorMsg = str(e)
                else : return_val_list.append(ReturnVal)
                if ErrorMsg : raise RuntimeError(ErrorMsg)

            AllTempList.append(TempStr % tuple(return_val_list))
        return self.tkEntry2.get().join(AllTempList)

    def dump_check(self) -> bool :
        return True

    def dumps(self) -> dict :
        return {"temp_type": 4, "subtemp_repeat": self.tkEntry1.get(), "subtemp_split": self.tkEntry2.get(),
            "subtemp": self.tkText1.get("0.0", "end-1c"), "subtemp_detial": self.tkText2.get("0.0", "end-1c")}

def GetExpressionType(temp_data: dict, temp_set_frame=tkinter.Frame()) :
    if temp_data["temp_type"] == 1 : return Single_Repeat_List(temp_set_frame, temp_data)
    elif temp_data["temp_type"] == 2 : return Repeat_List(temp_set_frame, temp_data)
    elif temp_data["temp_type"] == 3 : return Expression(temp_set_frame, temp_data)
    elif temp_data["temp_type"] == 4 : return Single_Line(temp_set_frame, temp_data)



class pack_class : 

    def __init__(self) -> None : 
        Old_File_Path = os.path.join(base_path, 'template_saves')
        if os.path.isfile(Old_File_Path) : 
            with open(Old_File_Path, 'rb') as f:
                try : old_save_data = pickle.load(f)
                except : old_save_data = []
            for data in old_save_data :
                _file = SandBoxPath.file_operate("internal", random_name()+".cbt", 'w', encoding="utf-8")
                json.dump(data, _file)
                _file.close()
            os.remove(Old_File_Path)
        if not SandBoxPath.path_exist("internal", "XCiEmwWCUo8=.cbt") :
            Json1 = {"Version": 1, "name": "\u5b98\u65b9\u5b66\u4e60\u6a21\u677f", 
                "template_command": "testfor $temp0\ntestfor $temp2\ntestfor $temp3\ntestfor $temp4\ntestfor $temp5\n", 
                "generate_times": "10", "Template": {"$temp1": {"temp_type": 1, "temp_detial": "1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15"}, 
                "$temp2": {"temp_type": 2, "temp_detial": "1\n2\n3\n4\n5"}, "$temp3": {"temp_type": 3, "temp_detial": "sqrt(var1)"}, 
                "$temp4": {"temp_type": 4, "subtemp_repeat": "var1 if var1<=3 else 3", "subtemp_split": "-", 
                "subtemp": "(%s, %s)", "subtemp_detial": "var2\nvar3"}, "$temp5": {"temp_type": 3, "temp_detial": "var2"}, 
                "$temp0": {"temp_type": 3, "temp_detial": "var1"}}}
            _file = SandBoxPath.file_operate("internal", "XCiEmwWCUo8=.cbt", 'w', encoding="utf-8")
            json.dump(Json1, _file)
            _file.close()

        self.FileVersion = 1
        self.__file_list:dict = {}
        self.current_file:str = None
        self.current_template:dict = {}

        self.__hash = -1
        self.save_timestemp:int = time.time() + 120

        self.support_const = {'var0':None, 'var1':None, 'var2':None, 'var3':None, 'pi':math.pi, "tau":math.tau, 'e':math.e, 'degrees':math.pi/180}
        self.support_compute = {'sin':math.sin, 'cos':math.cos, "tan":math.tan, 'random':random.random, 'randfloat':random.uniform,
                                'randint':random.randint, 'pow':math.pow, 'log':lambda a,N: 1/math.log(N,a), 'arcsin':math.asin,
                                'arccos':math.acos, 'arctan':math.atan, 'floor':math.floor, 'ceil':math.ceil, "factorial":math.factorial,
                                "comb":lambda k,n: 1/math.comb(n,k), 'abs':abs, "sqrt":math.sqrt, }

    def loop_method(self) :
        if not isinstance(tk_component["file_select"], tkinter.Listbox) : return None
        if self.current_file is not None and time.time() > self.save_timestemp :
            self.save_timestemp = time.time() + 120
            str1 = json.dumps(self.current_template)
            if self.__hash != hash(str1) : self.save_template()

        file_list = {}
        for location, path_type, name in SandBoxPath.list_dirs("all", "") :
            if path_type != "file" : continue
            if not name.endswith(".cbt") : continue

            if location == "internal" : file_name = "[内部]" + name[:-4]
            else : file_name = "[外部]" + name[:-4]

            file_list[file_name] = [location, name]

        if self.__file_list != file_list :
            self.__file_list = file_list
            tk_component["file_select"].delete(0, "end")
            tk_component["file_select"].insert("end", *file_list)


    def check_integrity_V0(self, json1:dict) : 
        if not isinstance(json1, dict) : raise DataError("起始数据非字典类型")
        if not isinstance( json1.get("name", None), str ) : raise DataError("字典无或错误 name")
        if not isinstance( json1.get("template_command", None), str ) : raise DataError("字典无或错误 template_command")
        if not isinstance( json1.get("generate_times", None), str ) : raise DataError("字典无或错误 generate_times")
        if not isinstance( json1.get("Template", None), list ) : raise DataError("字典无或错误 Template")

        self.current_template["name"] = json1["name"]
        self.current_template["template_command"] = json1["template_command"]
        self.current_template["generate_times"] = json1["generate_times"]
        self.current_template["Template"] = Template = {}
        
        for index, template_data in enumerate(json1['Template']) :
            if not isinstance(template_data, dict) : raise DataError("模板数据类型错误(%s)" % index)
            if not isinstance( template_data.get("temp_name", None), str ) : raise DataError("模板数据无或错误 temp_name (%s)" % index)
            if not isinstance( template_data.get("temp_type", None), int ) : raise DataError("模板数据无或错误 temp_type (%s)" % index)
            if not isinstance( template_data.get("temp_detial", None), str ) : raise DataError("模板数据无或错误 temp_detial (%s)" % index)

            temp_name = template_data["temp_name"]
            temp_type = template_data["temp_type"]
            temp_detial = template_data["temp_detial"]
            if temp_type != 4 : Template[temp_name] = {"temp_type":temp_type, "temp_detial":temp_detial}
            else : 
                temp_detial_list = temp_detial.split("\n")
                Template[temp_name] = {"temp_type":temp_type, "subtemp_repeat":temp_detial_list[0],
                "subtemp":temp_detial_list[1], "subtemp_split": " ", "subtemp_detial":"\n".join(temp_detial_list[2:]) }

    def check_integrity_V1(self, json1:dict) : 
        if not isinstance(json1, dict) : raise DataError("起始数据非字典类型")
        if not isinstance( json1.get("name", None), str ) : raise DataError("字典无或错误 name 标识")
        if not isinstance( json1.get("template_command", None), str ) : raise DataError("字典无或错误 template_command")
        if not isinstance( json1.get("generate_times", None), str ) : raise DataError("字典无或错误 generate_times")
        if not isinstance( json1.get("Template", None), dict ) : raise DataError("字典无或错误 Template")

        self.current_template["name"] = json1["name"]
        self.current_template["template_command"] = json1["template_command"]
        self.current_template["generate_times"] = json1["generate_times"]
        self.current_template["Template"] = Template = {}
        
        for key, template_data in json1['Template'].items() :
            if not isinstance(template_data, dict) : raise DataError("模板数据类型错误(%s)" % key)
            if not isinstance( template_data.get("temp_type", None), int ) : raise DataError("模板数据无或错误 temp_type (%s)" % key)

            temp_type = template_data["temp_type"]
            if temp_type != 4 and not isinstance( template_data.get("temp_detial", None), str ) : raise DataError("模板数据无或错误 temp_detial (%s)" % key)
            elif temp_type == 4 and not isinstance( template_data.get("subtemp_repeat", None), str ) : raise DataError("模板数据无或错误 subtemp_repeat (%s)" % key)
            elif temp_type == 4 and not isinstance( template_data.get("subtemp", None), str ) : raise DataError("模板数据无或错误 subtemp (%s)" % key)
            elif temp_type == 4 and not isinstance( template_data.get("subtemp_split", None), str ) : raise DataError("模板数据无或错误 subtemp_split (%s)" % key)
            elif temp_type == 4 and not isinstance( template_data.get("subtemp_detial", None), str ) : raise DataError("模板数据无或错误 subtemp_detial (%s)" % key)

            Template[key] = template_data


    def print_name(self, listbox1:tkinter.Listbox, label1:tkinter.Label) : 
        if not listbox1.curselection() : return None

        file_name = listbox1.get( listbox1.curselection()[0] )
        file_per_data = self.__file_list[file_name]
        _file = SandBoxPath.file_operate(file_per_data[0], file_per_data[1], "r", encoding="utf-8")
        try : Json1 = json.load(_file)
        except : 
            label1.config(text="(文件错误，数据损坏)")
            _file.close()
            return None

        if "name" not in Json1 : label1.config(text="项目名：(文件错误，数据损坏)")
        else : label1.config(text="项目名：" + Json1["name"])
        _file.close()

    def create_template(self, listbox1:tkinter.Listbox) : 
        Template_Data = {'name': '模板%s'%random.randint(0,100000), "template_command": "", "generate_times": "0", "Template": []}
        file_save_name = random_name() + ".cbt"
        _file = SandBoxPath.file_operate("internal", file_save_name, "w", encoding="utf-8")
        json.dump(Template_Data, _file)
        _file.close()

        file_name = "[内部]" + file_save_name[:-4]
        self.__file_list[file_name] = ["internal", file_save_name]
        listbox1.insert(0, file_name)
        listbox1.select_clear(0, "end")
        listbox1.selection_set(0)

    def delete_template(self, listbox1:tkinter.Listbox) : 
        if not listbox1.curselection() : return None
        a = tkinter.messagebox.askquestion("Q","二次确认\n是否删除该模板？")
        if a != "yes" : return None

        file_name = listbox1.get( listbox1.curselection()[0] )
        file_per_data = self.__file_list[file_name]
        SandBoxPath.delete_path(file_per_data[0], file_per_data[1])
        del self.__file_list[file_name]
        listbox1.delete( listbox1.curselection()[0] )

        tkinter.messagebox.showinfo("Info", "已删除模板")


    def open_template(self, listbox1:tkinter.Listbox, entry1:tkinter.Entry, entry2:tkinter.Entry, text1:tkinter.Text) :
        if not listbox1.curselection() : return None
        file_name = listbox1.get( listbox1.curselection()[0] )
        file_per_data = self.__file_list[file_name]
        _file = SandBoxPath.file_operate(file_per_data[0], file_per_data[1], "r", encoding="utf-8")

        try : JsonContant = json.load(fp=_file)
        except : tkinter.messagebox.showerror("Error", "加载错误：\n文件数据损坏") ; return None
        self.current_template.clear()
        FileVersion = JsonContant.get("Version", 0)
        try :
            if FileVersion == 0 : self.check_integrity_V0(JsonContant)
            elif FileVersion == 1 : self.check_integrity_V1(JsonContant)
        except DataError as e :
            tkinter.messagebox.showerror("Error", "文件加载错误：\n%s\nVersion: %s" % (e.args[0], FileVersion))
            return False

        text1.delete("0.0", tkinter.END)
        entry1.delete("0", tkinter.END)
        entry2.delete("0", tkinter.END)
        text1.insert("0.0", self.current_template["template_command"])
        entry1.insert("0", self.current_template["name"])
        entry2.insert("0", self.current_template["generate_times"])
        self.current_file = file_per_data
        self.save_timestemp = time.time() + 120
        self.update_hight_light(text1)
        return True

    def save_template(self, exit=False) :
        SaveFileData = {"Version":self.FileVersion}
        SaveFileData.update( (i, j) for i, j in self.current_template.items() if i != "Version" )
        _file = SandBoxPath.file_operate(self.current_file[0], self.current_file[1], "w", encoding="utf-8")
        json.dump(SaveFileData, _file)
        _file.close()

        if exit : 
            self.__hash = -1
            self.current_file = None
            self.current_template.clear()
            tkinter.messagebox.showinfo("Info","已成功保存模板")

    def update_hight_light(self, text1:tkinter.Text): 
        command_list = text1.get("0.0", "end-1c").split("\n")
        text1.tag_remove('template', "0.0", tkinter.END)
        for line, command in enumerate(command_list, start=1) :
            for re1 in re.finditer(TemplateStringTag, command) :
                text1.tag_add('template', "%s.%s"%(line, re1.start()), "%s.%s"%(line, re1.end()))


    def generate_command(self, CommandOutput:tkinter.Text) :
        CommandOutput.delete("0.0", "end")
        Global_Var = self.support_const.copy()
        Local_Var = self.support_compute.copy()
        Repeat_Times = math.floor( float(self.current_template["generate_times"]) )
        Command_Template = string.Template( self.current_template["template_command"]+"\n" )
        Calling_Object = {}
        for re1 in re.finditer(TemplateStringTag, self.current_template["template_command"]) :
            temp_name = re1.group()
            if temp_name not in self.current_template["Template"] :
                tkinter.messagebox.showerror("Error", "未设置模板的类型与参数：\n" + temp_name)
                return None
            temp_data = self.current_template["Template"][temp_name]
            Calling_Object[temp_name] = GetExpressionType(temp_data)

        try :
            for current_times in range(1, Repeat_Times+1) :
                Global_Var['var0'] = Repeat_Times
                Global_Var['var1'] = current_times
                Template_Return_Var = {}

                for TempName, CallFunc in Calling_Object.items() :
                    Template_Return_Var[TempName[1:]] = CallFunc(Global_Var, Local_Var)

                CommandOutput.insert("end", Command_Template.safe_substitute(Template_Return_Var))
        except StopGenerate as e : pass
        except CompileError as e : tkinter.messagebox.showerror("Error", "编译错误(%s)：\n%s" % (TempName, str(e)) )
        except RuntimeError as e : tkinter.messagebox.showerror("Error", "运行时错误(%s)：\n%s" % (TempName, str(e)))
        except Exception as e : tkinter.messagebox.showerror("Error", "非预期错误：\n" + str(e))


    def copy_all(self) :
        text = tk_component["output1"].get("0.0", tkinter.END)[:-1]
        tk_tool.copy_to_clipboard(text)



def UI_set(main_win, tkinter_Frame:tkinter.Frame) :
    global tk_component, InputBoxSettingFunction
    InputBoxSettingFunction = main_win.set_focus_input
    pack_object:pack_class = main_win.get_expand_pack_class_object("cf061f76-414f-410e-ad6b-7b1876343918")

    if "主菜单" :
        main_frame = tkinter.Frame(tkinter_Frame)
        tkinter.Label(main_frame, text="   ", font=tk_tool.get_default_font(4), height=1).pack()
        tkinter.Label(main_frame,text="命令模板生成",fg='black',font=tk_tool.get_default_font(20),width=15,height=1).pack()
        tkinter.Label(main_frame, text="   ", font=tk_tool.get_default_font(4), height=1).pack()

        frame_m10 = tkinter.Frame(main_frame)
        sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
        file_select = tkinter.Listbox(frame_m10, font=tk_tool.get_default_font(12),
            selectmode=tkinter.SINGLE, height=15, width=24, yscrollcommand=sco1.set)
        file_select.grid()
        sco1.config(command=file_select.yview)
        sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
        file_select.bind("<ButtonRelease-1>", lambda e : pack_object.print_name(e.widget, name_printer) )
        file_select.bind("<Double-ButtonRelease-1>", lambda e : [open_template.config(state="disabled", command=None), 
            main_frame.pack_forget(), edit_frame.pack()] if pack_object.open_template(e.widget, temple_title, gen_times, expand_input_1) else None )
        frame_m10.pack()

        tkinter.Label(main_frame, text="   ", font=tk_tool.get_default_font(2)).pack()
        name_printer = tkinter.Label(main_frame, text="项目名：(点击列表项目获取)", font=tk_tool.get_default_font(10), 
            fg="#357fff", width=20, anchor="w")
        name_printer.pack()
        tkinter.Label(main_frame, text="   ", font=tk_tool.get_default_font(2)).pack()

        frame_m6 = tkinter.Frame(main_frame) ; frame_m6.pack()
        tkinter.Button(frame_m6,text=tk_tool.platform_string('新建'),font=tk_tool.get_default_font(12),bg='#9ae9d1', height=1,
            command=lambda: pack_object.create_template(file_select) ).grid(row=0, column=0)
        tkinter.Label(frame_m6,fg='black',font=tk_tool.get_default_font(6),width=2,height=1).grid(row=0, column=1)
        tkinter.Button(frame_m6,text=tk_tool.platform_string('删除'),font=tk_tool.get_default_font(12),bg='#9ae9d1', height=1,
            command=lambda: pack_object.delete_template(file_select) ).grid(row=0, column=2)
        tkinter.Label(frame_m6,fg='black',font=tk_tool.get_default_font(6),width=2,height=1).grid(row=0, column=3)
        tkinter.Button(frame_m6,text=tk_tool.platform_string('打开'),font=tk_tool.get_default_font(12),bg='#9ae9d1', height=1,
            command=lambda: [open_template.config(state="disabled", command=None), main_frame.pack_forget(), edit_frame.pack()] 
            if pack_object.open_template(file_select, temple_title, gen_times, expand_input_1) else None).grid(row=0, column=4)
        
        tkinter.Label(main_frame, text="   ", font=tk_tool.get_default_font(2)).pack()
        frame_m6 = tkinter.Frame(main_frame) ; frame_m6.pack()
        tkinter.Label(frame_m6, text="第一次使用请\n阅读帮助文档", font=tk_tool.get_default_font(9), fg="red").grid(row=1, column=0)
        tkinter.Label(frame_m6,fg='black',font=tk_tool.get_default_font(6),width=2,height=1).grid(row=1, column=1)
        tkinter.Button(frame_m6,text=tk_tool.platform_string('帮助文档'),font=tk_tool.get_default_font(12),bg='#7fc8ff', height=1, command=lambda: 
            webbrowser.open("http://localhost:32323/?pack=cf061f76-414f-410e-ad6b-7b1876343918&page=help") ).grid(row=1, column=2)
        
        main_frame.pack()

    if "编辑界面" :
        edit_frame = tkinter.Frame(tkinter_Frame)
        tkinter.Label(edit_frame, text="   ", font=tk_tool.get_default_font(6), height=1).pack()
        temple_title = tkinter.Entry(edit_frame,font=tk_tool.get_default_font(13),width=18,justify='center')
        temple_title.bind("<FocusIn>",lambda a : main_win.set_focus_input(a))
        temple_title.bind("<KeyRelease>", lambda a : pack_object.current_template.__setitem__("name", temple_title.get()), add="+")
        temple_title.pack()
        tkinter.Label(edit_frame, text="",fg='black',font=tk_tool.get_default_font(6), width=15, height=1).pack()

        frame_m10 = tkinter.Frame(edit_frame) ; frame_m10.pack()
        tkinter.Label(frame_m10, text=" 模板生成次数 ",bg="#b0b0b0",fg='black', font=tk_tool.get_default_font(13), height=1).pack(side='left')
        gen_times = tkinter.Entry(frame_m10, font=tk_tool.get_default_font(13), width=7, justify='center')
        gen_times.bind("<FocusIn>",lambda a : main_win.set_focus_input(a))
        gen_times.bind("<KeyRelease>", lambda a : pack_object.current_template.__setitem__("generate_times", gen_times.get()), add="+")
        gen_times.pack(side='left')

        def test_choose_template_tag(text_widget:tkinter.Text) :
            insert_pos = text_widget.index(tkinter.INSERT).split(".")
            insert_pos[1] = int(insert_pos[1])
            text_get = text_widget.get( "%s.0" % insert_pos[0], "%s.end" % insert_pos[0])
            
            template_find_tag = None
            for template in re.finditer(TemplateStringTag, text_get) :
                if not( template.start() <= insert_pos[1] <= template.end() ) : continue
                template_find_tag = template.group()
                break
            
            if not template_find_tag : open_template.config(state="disabled", command=None)
            else : 
                open_template.config(command=lambda:[read_temp_data(template_find_tag), 
                    edit_frame.pack_forget(), temp_set_frame.pack()], state="normal")
                temp_type.bind("<<ComboboxSelected>>", lambda a : display_temp_set_Frame(template_find_tag,
                    {"temp_type": temp_type.current()+1}) )

        frame_m10 = tkinter.Frame(edit_frame) ; frame_m10.pack()
        sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
        expand_input_1 = tkinter.Text(frame_m10, show=None, height=17, width=29, 
            font=tk_tool.get_default_font(10),undo=True,yscrollcommand=sco1.set)
        expand_input_1.grid()
        expand_input_1.bind("<FocusIn>",lambda a : main_win.set_focus_input(a))
        sco1.config(command=expand_input_1.yview)
        expand_input_1.tag_config("template", foreground="orange", background="#1d701d")
        expand_input_1.event_add("<<update-status>>", "<KeyRelease>", "<ButtonRelease>")
        expand_input_1.bind("<<update-status>>", lambda a: [
            test_choose_template_tag(a.widget), 
            pack_object.update_hight_light(a.widget), 
            pack_object.current_template.__setitem__("template_command", expand_input_1.get("0.0", "end-1c"))], add="+")
        sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)

        tkinter.Label(edit_frame, text="   ", font=tk_tool.get_default_font(2)).pack()
        frame_m6 = tkinter.Frame(edit_frame) ; frame_m6.pack()
        tkinter.Label(frame_m6, text="请点击被着色的\n模板变量", font=tk_tool.get_default_font(10), fg="#357fff").grid(row=1, column=0)
        tkinter.Label(frame_m6,fg='black',font=tk_tool.get_default_font(6),width=1,height=1).grid(row=1, column=1)
        open_template = tkinter.Button(frame_m6, text=tk_tool.platform_string('打开模板设置'), state="disabled",
            font=tk_tool.get_default_font(12), bg="#7287FF", fg="white", command=None )
        open_template.grid(row=1, column=2)

        tkinter.Label(edit_frame, text="  ",fg='black',font=tk_tool.get_default_font(4)).pack()
        frame_m6 = tkinter.Frame(edit_frame) ; frame_m6.pack()
        tkinter.Button(frame_m6,text=tk_tool.platform_string('保存退出'),font=tk_tool.get_default_font(12),bg='#00ffff',
            command=lambda:[pack_object.save_template(True), edit_frame.pack_forget(), main_frame.pack()]).pack(side='left')
        tkinter.Canvas(frame_m6,width=15, height=5).pack(side='left')
        tkinter.Button(frame_m6,text=tk_tool.platform_string('生成命令'),font=tk_tool.get_default_font(12),bg='#00ffff',
            command=lambda: [pack_object.generate_command(expand_output_1), result_frame.pack(), edit_frame.pack_forget()]).pack(side='left')

    if "模板类型界面" :
        def read_temp_data(choose_temp_name: str) :
            Template = pack_object.current_template["Template"]

            choose_temp_data = Template.get(choose_temp_name, {"temp_type": 1, "temp_detial": ""})
            display_temp_set_Frame(choose_temp_name, choose_temp_data)

        def display_temp_set_Frame(temp_name:str, temp_data:dict) :
            nonlocal TempTypeFrame, temp_set_frame
            if TempTypeFrame : TempTypeFrame.destroy()
            
            TempTypeFrame = GetExpressionType(temp_data, temp_set_frame)

            temp_type.current(temp_data["temp_type"]-1)
            CloseTempSetFrame.pack_forget()
            TempTypeFrame.pack()
            CloseTempSetFrame.pack()
            CloseTempSet.config(command=lambda:[save_temp_setting(temp_name, TempTypeFrame), 
                temp_set_frame.pack_forget(), edit_frame.pack()])

        def save_temp_setting(temp_name:str, temp_set_frame:Single_Line) :
            pack_object.current_template["Template"][temp_name] = temp_set_frame.dumps()
            temp_set_frame.destroy()

        temp_set_frame = tkinter.Frame(tkinter_Frame)
        tkinter.Label(temp_set_frame, text="   ", font=tk_tool.get_default_font(6), height=1).pack()
        temp_type = ttk.Combobox(temp_set_frame, font=tk_tool.get_default_font(13), width=15, state='readonly', justify='center')
        temp_type["value"] = ("单次列表", "循环列表", "复杂表达式", "多段字符")
        temp_type.current(0) ; temp_type.pack()
        tkinter.Label(temp_set_frame, text="   ", font=tk_tool.get_default_font(6), height=1).pack()
        TempTypeFrame = None
        
        CloseTempSetFrame = tkinter.Frame(temp_set_frame) ; CloseTempSetFrame.pack()
        tkinter.Label(CloseTempSetFrame, text="   ", font=tk_tool.get_default_font(6), height=1).pack()
        CloseTempSet = tkinter.Button(CloseTempSetFrame, text=tk_tool.platform_string('退出设置'), 
            font=tk_tool.get_default_font(12), bg='#00ffff')
        CloseTempSet.pack()

    if "命令输出界面" :
        result_frame = tkinter.Frame(tkinter_Frame)
        tkinter.Label(result_frame, text=" 命令输出界面 ",fg='black',bg="#b0b0b0",font=tk_tool.get_default_font(13), height=1).pack()
        frame_m10 = tkinter.Frame(result_frame)
        sco1 = tkinter.Scrollbar(frame_m10,orient='vertical')
        sco2 = tkinter.Scrollbar(frame_m10,orient="horizontal")
        expand_output_1 = tkinter.Text(frame_m10,show=None,wrap=tkinter.NONE,height=22, width=30,
            font=tk_tool.get_default_font(10),undo=True,yscrollcommand=sco1.set, xscrollcommand=sco2.set)
        expand_output_1.grid()
        expand_output_1.bind("<FocusIn>",lambda a : main_win.set_focus_input(a))
        sco1.config(command=expand_output_1.yview)
        sco1.grid(row=0,column=1,sticky=tkinter.N+tkinter.S)
        sco2.config(command=expand_output_1.xview)
        sco2.grid(sticky=tkinter.W+tkinter.E)
        frame_m10.pack()

        tkinter.Label(result_frame, text="   ", font=tk_tool.get_default_font(6), height=1).pack()
        frame_m6 = tkinter.Frame(result_frame) ; frame_m6.pack()
        tkinter.Button(frame_m6,text='返回模板',font=tk_tool.get_default_font(12),bg='#00ffff' ,width=9, height=1,
            command=lambda:[result_frame.pack_forget(), edit_frame.pack()]).pack(side='left')
        tkinter.Canvas(frame_m6,width=15, height=5).pack(side='left')
        tkinter.Button(frame_m6,text='复制全部',font=tk_tool.get_default_font(12),bg='#00ffff' ,width=9, height=1,
            command=lambda:tk_tool.copy_to_clipboard( expand_output_1.get("1.0", "end-1c") )).pack(side='left')
        

    tk_component["file_select"] = file_select


