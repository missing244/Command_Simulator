from .FrameUI import FrameUI
import traceback
import tkinter as tk

class EditFrame(FrameUI):
    def __init__(self, MainPack, file, Edit, WinFrame):
        super().__init__(MainPack)
        if isinstance(file, str): self.Name = file.split("/")[-1]
        elif file.BlockNBT.__class__.__name__ in ["TAG_Compound", "NBTFile"]: self.Name = "方块池NBT"
        self._SetWinFrame()
        self._SetEdit()
        self.SetWin()
        
        if file == "    引导    ":
            Text = tk.Label(self.MainFrame, bg="#2B303B", fg="white", font=('',10), text=self.MainPack.Constants.HelpText)
            Text.pack()
            self.SetMainEditMove.AddMoveFrame(Text)
            return
        try:
            if not isinstance(file, str) and file.BlockNBT.__class__.__name__ in ["TAG_Compound", "NBTFile"]:
                self.Type, self.Data = 'bdx-nbt', file
            elif isinstance(file, str): self.Type, self.Data = self.MainPack.ParserFile(file)
            if self.Type == "bdx": self.UI = self.MainPack.GetUI("BlocksUI")(self.MainPack, self)
            if self.Type in ['dat', 'mcstructure', 'nbt', 'bdx-nbt']:
                self.SubFrame = self.MainFrame
                self.UI = self.MainPack.GetUI("NBTagUI")(self.MainPack, self, self, [])
                self.UI.Show()
        except Exception as e:
            self.MainPack.TraceError("Throw", "不支持的文件格式", f"{traceback.format_exc()}")
    
    def _SetWinFrame(self):
        self.WinFrame = tk.Frame(self.MainPack.WinFrame,bd=1)
        Button = tk.Button(self.WinFrame,text=self.Name+" ",anchor="w",takefocus=False,bg="#898C8E",borderwidth=0,highlightthickness=1)
        Button.pack()
        MainClose = tk.Frame(self.WinFrame,bg="red")
        MainClose.place(x=Button.winfo_reqwidth()-self.MainPack.GetInt(63),y=3)
        CloseFrame = tk.Frame(MainClose,width=self.MainPack.GetInt(60),height=self.MainPack.GetInt(60),bg="#898C8E")
        tk.Button(CloseFrame,text="x",font=('',9),width=1,height=1,command=self.Close,bg="#898C8E",borderwidth=0,highlightthickness=0).pack()
        CloseFrame.pack_propagate(0)
        CloseFrame.pack(anchor="se")
        self.WinFrame.pack(side="left")
        self.MainPack.MoveClass[0].AddMoveFrame(Button, lambda: self.SetWin())
    
    def _SetEdit(self):
        Width = self.MainPack.GetInt(100)
        
        self.EditFrame = tk.Frame(self.MainPack.Edit, bg="black",height=self.MainPack.GetInt(1740))
        self.EditFrame.place(x=self.MainPack.GetInt(10))
        EditScrollX = tk.Scrollbar(self.EditFrame, orient="horizontal")
        TopEditFrame = tk.Frame(self.EditFrame)
        EditScrollY = tk.Scrollbar(TopEditFrame, orient="vertical")
        self.MainEdit = tk.Canvas(TopEditFrame,width=self.MainPack.GetInt(1000),height=self.MainPack.GetInt(1675),bg="#2B303B",yscrollcommand=EditScrollY.set,xscrollcommand=EditScrollX.set,scrollregion=(0, 0, 0, 0))
        self.MainEdit.pack_propagate(0) # ***
        EditScrollX.bind("<ButtonPress-1>", lambda a: self.MainEdit.config(scrollregion=(0, 0, self.MainEdit.bbox(self.MainFrameSize)[2]+Width, self.MainEdit.bbox(self.MainFrameSize)[3]+Width)))
        EditScrollY.bind("<ButtonPress-1>", lambda a: self.MainEdit.config(scrollregion=(0, 0, self.MainEdit.bbox(self.MainFrameSize)[2]+Width, self.MainEdit.bbox(self.MainFrameSize)[3]+Width)))
        
        self.MainFrame = tk.Frame(self.MainEdit,bg="#2B303B",borderwidth=0,highlightthickness=0)
        self.MainFrameSize = self.MainEdit.create_window(Width, Width,anchor="nw", window=self.MainFrame)
        self.SetMainEditMove = self.MainPack.GetMoveFrame(self.MainEdit, self.MainFrameSize, "xy", 100)
        self.SetMainEditMove.AddMoveFrame(self.MainEdit)
        self.SetMainEditMove.AddMoveFrame(self.MainFrame)
        self.MainEdit.pack(side="left")
        
        EditScrollY.config(command=self.MainEdit.yview)
        EditScrollY.pack(side='right', fill='y')
        TopEditFrame.pack()
        EditScrollX.config(command=self.MainEdit.xview)
        EditScrollX.pack(side='bottom', fill='x')
    
    def GetData(self):
        if self.Type in ['dat', 'mcstructure', 'nbt', 'bdx']: return self.Data
        if self.Type in ['bdx-nbt']: return self.Data.BlockNBT
    
    def Close(self):
        if not tk.messagebox.askokcancel("Close", "关闭窗口会销毁你所有的数据\n请及时保存"): return
        CloseTime = 0
        self.Hide()
        def Task(Number):
            nonlocal CloseTime
            CloseTime = Number
            if Number >= self.MainPack.Constants.EditFrameRemoveTime:
                self.EditFrame.destroy()
                self.WinFrame.destroy()
                del self.MainPack.EditClassDestroyPool[self.MainPack.EditClassDestroyPool.index(self)]
        def Res():
            if CloseTime < self.MainPack.Constants.EditFrameRemoveTime: self.Show()
        self.MainPack.TraceError("Method", "创建任务失败", self.MainPack.GetUI("TaskUI"), self.MainPack, Task, Res, self.MainPack.Constants.EditFrameRemoveTime, "关闭窗口", "撤销")
    
    def Show(self):
        self.WinFrame.pack(side="left")
        self.MainPack.EditClass.append(self)
        self.SetWin()
    
    def Hide(self):
        self.WinFrame.pack_forget()
        self.EditFrame.place_forget()
        self.MainPack.EditClassDestroyPool.append(self)
        del self.MainPack.EditClass[self.MainPack.EditClass.index(self)]
        try: self.MainPack.EditClass[0].SetWin()
        except: self.MainPack.EditClass.append(EditFrame(self.MainPack, "    引导    ", self.MainPack.Edit, self.MainPack.WinFrame))
    
    def Destroy(self):
        self.EditFrame.destroy()
        self.WinFrame.destroy()
        del self.MainPack.EditClass[self.MainPack.EditClass.index(self)]
        try: self.MainPack.EditClass[0].SetWin()
        except: self.MainPack.EditClass.append(EditFrame(self.MainPack, "    引导    ", self.MainPack.Edit, self.MainPack.WinFrame))
    
    def SetWin(self):
        for i in self.MainPack.EditClass:
            i.EditShow = False
        self.EditShow = True
        for i in self.MainPack.EditClass:
            if i.EditShow == False: i.EditFrame.place_forget()
        self.EditFrame.place(x=self.MainPack.GetInt(10))
    def GetNBT(self):
        return self.UI.GetNBT()