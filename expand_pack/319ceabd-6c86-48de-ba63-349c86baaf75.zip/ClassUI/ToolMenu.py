from .FrameUI import FrameUI
import tkinter as tk

class ToolMenu(FrameUI):
    def __init__(self, MainPack):
        super().__init__(MainPack)
        
        self.State = False
        self.X = 1
        MainPack.AddMoveFrameClick(self.Hide)
        
        self.MainFrame = tk.Frame(MainPack.MainWinFrame,bg="#3f3f3f",bd=5)
        tk.Label(self.MainFrame,bg="#3f3f3f",fg="#ffffff",text="功能菜单栏").pack()
        tk.Button(self.MainFrame,image=MainPack.Picture["ToolButton"],text="打开文件",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=lambda: MainPack.Tool(1)).pack()
        tk.Button(self.MainFrame,image=MainPack.Picture["ToolButton"],text="保存文件",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=lambda: MainPack.Tool(2)).pack()
        tk.Button(self.MainFrame,image=MainPack.Picture["ToolButton"],text="批量操作",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=lambda: MainPack.Tool(3)).pack()
        tk.Button(self.MainFrame,image=MainPack.Picture["ToolButton"],text="语法检查",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=lambda: MainPack.Tool(4)).pack()
        tk.Button(self.MainFrame,image=MainPack.Picture["ToolButton"],text="剪贴板",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=lambda: MainPack.Tool(5)).pack()
        tk.Button(self.MainFrame,image=MainPack.Picture["ToolButton"],text="设置版本",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=lambda: MainPack.Tool(6)).pack()
        tk.Button(self.MainFrame,image=MainPack.Picture["ToolButton"],text="打开网页端(未完成)",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=lambda: MainPack.Tool(7)).pack()
    def Click(self):
        if self.State: self.Hide()
        else: self.Show()
    
    def Show(self):
        self.State = True
        def Show():
            if not self.State: return
            if self.X > 0.5:
                self.X -= 0.02
                self.MainFrame.after(5, Show)
                self.MainFrame.place(relwidth=0.5,relheight=0.51,relx=self.X,y=self.MainPack.GetInt(150))
        Show()
    
    def Hide(self):
        self.State = False
        def Hide():
            if self.State: return
            if self.X < 1:
                self.X += 0.02
                self.MainFrame.after(5, Hide)
                self.MainFrame.place(relwidth=0.5,relheight=0.51,relx=self.X,y=self.MainPack.GetInt(150))
        Hide()