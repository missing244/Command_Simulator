from .FrameUI import FrameUI
import tkinter as tk


class SaveUI(FrameUI):
    def __init__(self, MainPack, Command):
        super().__init__(MainPack)
        self.Command = Command
        self.MainFrame = tk.Frame(MainPack.MainWinFrame, bg="#151515", bd=self.MainPack.GetInt(50))
        tk.Label(self.MainFrame, text="文件名", bg="#151515", fg="#ffffff", bd=self.MainPack.GetInt(35), font=("",10)).pack()
        self.Entry = tk.Entry(self.MainFrame, width=64, bg="#151515", fg="#ffffff", font=("",10), insertbackground="#ffffff")
        self.Entry.insert(0, "输入名字")
        self.MainPack.SetInput(self.Entry)
        self.Entry.pack()
        self.SaveFrame = tk.Frame(self.MainFrame, bg="#151515")
        self.SaveFrame.pack()
        tk.Label(self.SaveFrame, text="后缀", bg="#151515", fg="#ffffff", bd=self.MainPack.GetInt(35), font=("",10)).pack()
        tk.Button(self.SaveFrame, text="mcstructure", bg="#151515", fg="#ffffff", command=lambda: self.Save("mcstructure")).pack(fill="x")
        tk.Button(self.SaveFrame, text="nbt", bg="#151515", fg="#ffffff", command=lambda: self.Save("nbt")).pack(fill="x")
        tk.Button(self.SaveFrame, text="dat", bg="#151515", fg="#ffffff", command=lambda: self.Save("dat")).pack(fill="x")
        tk.Button(self.SaveFrame, text="bdx", bg="#151515", fg="#ffffff", command=lambda: self.Save("bdx")).pack(fill="x")
        tk.Button(self.SaveFrame, text="json", bg="#151515", fg="#ffffff", command=lambda: self.Save("json")).pack(fill="x")
        self.Show()
        MainPack.AddMoveFrameClick(self.Hide)
    
    def Save(self, Mode):
        self.Command(self.Entry.get(), Mode)
        self.Hide()
    
    def Show(self):
        width, height, x = 0, 0, 0.5
        def Show():
            nonlocal width, height, x
            if width < 0.76: width += 0.025
            if height < 0.5: height += 0.02
            if x > 0.12: x -= 0.0126
            if width < 0.76: self.MainFrame.after(5, Show)
            self.MainFrame.place(relwidth=width,relheight=height,relx=x,rely=0.2)
        Show()
    
    def Hide(self):
        width, height, x = 0.76, 0.5, 0.12
        def Hide():
            nonlocal width, height, x
            if width > 0: width -= 0.025
            if height > 0: height -= 0.02
            if x < 0.5: x += 0.0126
            if width > 0:
                self.MainFrame.place(relwidth=width,relheight=height,relx=x,rely=0.2)
                self.MainFrame.after(5, Hide)
            else:
                self.Close()
        Hide()
    
    def Close(self):
        self.MainFrame.destroy()
        del self.MainPack.MoveFrameClick[self.MainPack.MoveFrameClick.index(self.Hide)]

