class FrameUI:
    def __init__(self, MainPack):
        self.MainPack = MainPack
    def Hide(self):
        pass
    def Show(self):
        pass
    def Destroy(self):
        pass