from .FrameUI import FrameUI
import traceback, math, json
import tkinter as tk


class BlocksUI(FrameUI):
    def __init__(self, MainPack, RootFrame):
        super().__init__(MainPack)
        self.RootFrame = RootFrame
        self.Data = RootFrame.Data
        
        self.SplitArea()
        
        self.PageX, self.PageZ, self.Y = 1, 1, 1
        self.StringXZ = tk.StringVar()
        self.StringY = tk.StringVar()
        self.Reset()
        
        self._SetTopTool()
        self._SetMainFrame()
        self._SetMoveFrame()
        
        self.MainPack.GrammarParser(self.Data, self.SetError)
        
        self.Show()
    
    def _SetTopTool(self):
        self.TopFrame = tk.Frame(self.RootFrame.MainEdit,bg="#696C6E",bd=self.MainPack.GetInt(20))
        tk.Label(self.TopFrame,bg="#696C6E",text=" ",font=("",10)).pack(side="left")
        tk.Button(self.TopFrame,bg="#696C6E",text="跳转",font=("",7)).pack(side="left")
        tk.Button(self.TopFrame,bg="#696C6E",text="下",font=("",10),bd=0,command=lambda:self.MoveZ(-1)).pack(side="right")
        tk.Label(self.TopFrame,bg="#696C6E",textvariable=self.StringY,font=("",10)).pack(side="right")
        tk.Button(self.TopFrame,bg="#696C6E",text="上",font=("",10),bd=0,command=lambda:self.MoveZ(1)).pack(side="right")
        tk.Label(self.TopFrame,bg="#696C6E",textvariable=self.StringXZ,font=("",8)).pack(side="right")
    
    def _SetMainFrame(self):
        self.MainFrame = tk.Frame(self.RootFrame.MainFrame)
        self.MainFrame2 = tk.Frame(self.MainFrame)
        self.BlocksFrame = tk.Frame(self.MainFrame2)
        self.BlocksFrame2 = tk.Frame(self.BlocksFrame)
    
    def _SetMoveFrame(self):
        self.TopHeight = tk.Label(self.MainFrame,bg="#2B303B",text=" \n")
        self.UpButton = tk.Button(self.MainFrame2,bg="#898C8E",text="北")
        self.DownButton = tk.Button(self.MainFrame2,bg="#898C8E",text="南")
        self.LeftButton = tk.Button(self.MainFrame,bg="#898C8E",text="西")
        self.RightButton = tk.Button(self.MainFrame,bg="#898C8E",text="东")
        self.RootFrame.SetMainEditMove.AddMoveFrame(self.TopHeight)
        self.RootFrame.SetMainEditMove.AddMoveFrame(self.UpButton, lambda: self.MovePage(1, 0))
        self.RootFrame.SetMainEditMove.AddMoveFrame(self.DownButton, lambda: self.MovePage(-1, 0))
        self.RootFrame.SetMainEditMove.AddMoveFrame(self.LeftButton, lambda: self.MovePage(0, -1))
        self.RootFrame.SetMainEditMove.AddMoveFrame(self.RightButton, lambda: self.MovePage(0, 1))
    
    def Show(self):
        self.TopFrame.pack(fill="x")
        self.MainFrame.pack()
        self.TopHeight.pack(side="top", fill="x")
        self.UpButton.pack(side="top", fill="x")
        self.BlocksFrame.pack()
        self.DownButton.pack(side="bottom", fill="x")
        self.LeftButton.pack(side="left", fill="y")
        self.RightButton.pack(side="right", fill="y")
        self.MainFrame2.pack()
        self.ShowBlocks()
    
    def ShowBlocks(self):
        self.SplitArea()
        self.Reset()
        self.BlocksFrame2.destroy()
        del self.BlocksFrame2
        self.BlocksFrame2 = tk.Frame(self.BlocksFrame)
        for z in range(16):
            f = tk.Frame(self.BlocksFrame2)
            f.pack(side="left")
            for x in range(16):
                Position = [(self.PageX-1)*16+x, self.Y-1, (self.PageZ-1)*16+z,]
                Block = self.Data.GetBlocksValue({'x':Position[0],'y':Position[1],'z':Position[2]})
                Picture = self.MainPack.GetBlockPicture(Block.BlockID, Block.BlockData, Block.BlockStates, Block.BlockNBT) if Block else self.MainPack.Picture["BlockNone"]
                a = tk.Button(f, image=Picture, bd=0, highlightthickness=0, text=str(Position))
                a.pack(side="bottom")
                self.RootFrame.SetMainEditMove.AddMoveFrame(a, self.SetBlockValue, True)
        self.BlocksFrame2.pack()
    
    def Reset(self):
        self.StringY.set(f"{self.Y}/{self.SizeY}")
        self.StringXZ.set(
        f"X轴页数:{self.PageX}/{self.SizePageX}  \n"
        f"Y轴页数:{self.PageZ}/{self.SizePageZ}  ")
    
    
    def SetError(self, Error):
        # PromptUI(self.MainPack, str(Error))
        # 还未实现的功能
        ...
    
    def SplitArea(self):
        self.SizePageX = math.ceil(self.Data.GetBlocksSize()[0]/16)+1
        self.SizePageZ = math.ceil(self.Data.GetBlocksSize()[2]/16)+1
        self.SizeY = self.Data.GetBlocksSize()[1]+1
    
    def MovePage(self, X, Z):
        self.SplitArea()
        self.PageX += X
        self.PageZ += Z
        if self.PageX < 1: self.PageX = 1
        if self.PageZ < 1: self.PageZ = 1
        if self.PageX > self.SizePageX: self.PageX = self.SizePageX
        if self.PageZ > self.SizePageZ: self.PageZ = self.SizePageZ
        self.ShowBlocks()
        self.Reset()
    
    def MoveZ(self, Number):
        self.SplitArea()
        self.Y += Number
        if self.Y < 1: self.Y = 1
        if self.Y > self.SizeY: self.Y = self.SizeY
        self.ShowBlocks()
        self.Reset()
    
    def SetBlockValue(self, Button):
        Pos = json.loads(Button.cget("text"))
        self.MainPack.TraceError("Method", "创建编辑菜单失败", self.MainPack.GetUI("SetBlock"), self.MainPack, self, Pos)
    

