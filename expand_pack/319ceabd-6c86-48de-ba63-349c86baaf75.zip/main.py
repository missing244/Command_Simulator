import os, sys, time, multiprocessing, webbrowser, math
import tkinter as tk
import tkinter.filedialog
import tkinter.messagebox
from main_source.package.python_nbt import nbt

sys.path.append(os.path.realpath(os.path.join(__file__, os.pardir)))

Picture = {}

Picture["Byte"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/Byte.png')
Picture["Short"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/Short.png')
Picture["Int"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/Int.png')
Picture["Long"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/Long.png')
Picture["Float"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/Float.png')
Picture["Double"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/Double.png')
Picture["ByteArray"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/ByteArray.png')
Picture["String"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/String.png')
Picture["List"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/List.png')
Picture["Compound"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/Compound.png')
Picture["IntArray"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/IntArray.png')
Picture["LongArray"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/LongArray.png')
Picture["ToolMenu"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/ToolMenu.png')
Picture["Edit"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/Edit.png')
Picture["Help"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/Help.png')
Picture["ToolButton"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/ToolButton.png')
Picture["NBTListOpen"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/NBTListOpen.png')
Picture["NBTListClose"] = tk.PhotoImage(file='expand_pack/NBTedit/picture/NBTListClose.png')

ToolMenuBoole = False
ToolMenuX = 1

EditClass = []

class pack_class:
    def __init__(self):
        ...
    
    def loop_method(self):
        # 在实例化pack_class对象中，该方法是提供每0.5秒循环一次的功能。
        ...
    
    def reload_method(self):
        # 在实例化pack_class对象中，该方法是提供重启拓展包时执行代码的功能。
        ...
    
def UI_set(main_win, tkinter_Frame):
    #主布局
    global Picture
    global setListFrameMove
    global ToolMenu
    global Edit
    global WinFrame
    global RootFrame
    global getInt
    global SetInput
    
    def SetInput(Entry):
        Entry.bind("<FocusIn>",lambda a :main_win.set_focus_input(a))
    
    def getInt(Int):
        if main_win.platform == "windows": return Int//3.6
        return Int
    
    if main_win.platform == "windows": Picture = {key: value.subsample(2, 2) for key, value in Picture.items()}
    elif main_win.platform == "android": Picture = {key: value.zoom(2, 2) for key, value in Picture.items()}
    
    MainFrame = tk.Frame(tkinter_Frame, width=getInt(1080), height=getInt(1993), bg="#2B303B")
    RootFrame = MainFrame
    MainFrame.pack_propagate(0)
    MainFrame.pack(fill="both")
    #帮助
    def ToHelp():
        webbrowser.open("http://localhost:32323/?pack=319ceabd-6c86-48de-ba63-349c86baaf75&page=help")
    #功能列表
    def ToolMenu():
        global ToolMenuBoole
        ToolMenuBoole = False if ToolMenuBoole else True
        def MoveToolMenu(ToolFrame):
            global ToolMenuX
            if ToolMenuBoole and ToolMenuX > 0.5:
                ToolMenuX -= 0.02
                MainFrame.after(5, MoveToolMenu, ToolFrame)
            elif not ToolMenuBoole and ToolMenuX < 1:
                ToolMenuX += 0.02
                MainFrame.after(5, MoveToolMenu, ToolFrame)
            ToolFrame.place(relwidth=0.5,relheight=0.51,relx=ToolMenuX,y=getInt(150))
        MoveToolMenu(ToolFrame)
    #功能
    def Tool1():
        file = tk.filedialog.askopenfilename()
        if file:
            EditClass.append(NBTEdit(file, Edit, WinFrame, ToolMenu))
    def Tool2():
        if not tk.messagebox.askokcancel("Close", "关闭窗口会销毁你所有的数据\n请及时保存"): return
        for i in range(len(EditClass)):
            EditClass[0].Close(True)
    def Tool3():
        for i in EditClass:
            if i.EditShow: NBT = i.GetNBT()
        def SaveFile():
            file = tk.filedialog.asksaveasfilename(initialfile=FileName.get(), defaultextension=".mcstructure", filetypes=[("NBT", ".nbt"), ("Structure", ".mcstructure"), ("所有文件", ".*")])
            SaveName.destroy()
            if file:
                NBTWrite = open(file, "wb")
                nbt.write_to_nbt_file(NBTWrite, NBT, '', False, "little")
                NBTWrite.close()
        SaveName = tk.Toplevel(MainFrame)
        SaveName.resizable(False, False)
        small_win_width, small_win_height = int(RootFrame.winfo_width()*0.97), int(RootFrame.winfo_height()*0.25)
        SaveName.geometry('%sx%s+%s+%s'%(small_win_width,small_win_height,RootFrame.winfo_x(),RootFrame.winfo_y()))
        SaveName.transient(MainFrame)
        SaveName.title('Save File Name')
        SaveFrame = tk.Frame(SaveName, bd=getInt(100))
        SaveFrame.pack()
        tk.Label(SaveFrame, text="      文件名:").pack(side="left")
        FileName = tk.Entry(SaveFrame, width=30)
        FileName.pack(side="left",fill="x")
        SetInput(FileName)
        tk.Button(SaveName, text="保存", width=25, command=SaveFile).pack()
    def Tool4():
        ...
    def Tool5():
        ...
    def Tool6():
        ...
    def Tool7():
        ...
    #顶栏
    TopFrame = tk.Frame(MainFrame, bg="grey")
    tk.Button(TopFrame,text="帮助",fg='black',width=70,height=1,bg="grey",borderwidth=0,highlightthickness=0,command=ToHelp,image=Picture["Help"],compound="top").pack(side="left",fill="both")
    tk.Label(TopFrame,text="NBT编辑器",fg='black',font=('',20),width=12,height=1,bg="grey").pack(side="left")
    tk.Button(TopFrame,text="功能",fg='black',width=200,height=1,bg="grey",borderwidth=0,highlightthickness=0,command=ToolMenu,image=Picture["ToolMenu"],compound="top").pack(side="left",fill="both")
    TopFrame.pack(fill="x")
    #功能
    ToolFrame = tk.Frame(tkinter_Frame,bg="#3f3f3f",bd=5)
    tk.Label(ToolFrame,bg="#3f3f3f",fg="#ffffff",text="功能菜单栏").pack()
    tk.Button(ToolFrame,image=Picture["ToolButton"],text="打开文件",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=Tool1).pack()
    tk.Button(ToolFrame,image=Picture["ToolButton"],text="关闭全部",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=Tool2).pack()
    tk.Button(ToolFrame,image=Picture["ToolButton"],text="保存文件",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=Tool3).pack()
    tk.Button(ToolFrame,image=Picture["ToolButton"],text="json转换(未完成)",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=Tool4).pack()
    tk.Button(ToolFrame,image=Picture["ToolButton"],text="bdx转换(未完成)",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=Tool5).pack()
    # tk.Button(ToolFrame,image=Picture["ToolButton"],text="还没做",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=Tool6).pack()
    # tk.Button(ToolFrame,image=Picture["ToolButton"],text="打开网页端(未完成)",fg="#ffffff",compound="center",bg="#3f3f3f",activebackground="#3f3f3f",bd=0,highlightthickness=0,command=Tool7).pack()
    #文件列表栏
    ListFrame = tk.Frame(MainFrame, bg="#2B303B")
    ListCanVas = tk.Canvas(ListFrame, height=getInt(110), scrollregion=(0, 0, 0, 0), bg="#2B303B")
    ListCanVas.pack()
    WinFrame = tk.Frame(ListCanVas, bg="#2B303B")
    ListWidth = ListCanVas.create_window(getInt(10), getInt(10),anchor="nw", window=WinFrame)
    def setListFrameMove(MainMove):
        def on_canvas_click(event):
            ListCanVas.scan_mark(event.x_root-ListCanVas.winfo_rootx(), 0)
            ListCanVas.config(scrollregion=(0, 0, ListCanVas.bbox(ListWidth)[2]+10, 0))
            if ToolMenuBoole: ToolMenu()
        def on_canvas_drag(event):
            ListCanVas.scan_dragto(event.x_root-ListCanVas.winfo_rootx(), 0, gain=1)
        MainMove.bind("<ButtonPress-1>", on_canvas_click)
        MainMove.bind("<B1-Motion>", on_canvas_drag)
    setListFrameMove(ListCanVas)
    
    ListFrame.pack(fill="x")
    
    #编辑器界面
    Edit = tk.Frame(MainFrame, bg="#ffffff",height=getInt(1740))
    Edit.pack(fill="both")
    
    global EditClass
    EditClass.append(NBTEdit("    引导    ", Edit, WinFrame, ToolMenu))

class NBTEdit:
    def __init__(self, file, Edit, MainFrame, ToolMenu):
        self.Name = file.split("/")[-1]
        
        self._SetWinFrame(MainFrame)
        self._SetEdit(Edit, ToolMenu)
        self.SetWin()
        
        if file == "    引导    ":
            Text = tk.Label(self.MainFrame, bg="#2B303B", fg="white", font=('',10),
            text=
            "点左上角打开帮助文档\n" +
            "点右上角打开菜单栏\n" +
            "长按并移动可以拖动界面\n" +
            ""
            )
            Text.pack()
            self.SetMainEditMove(Text)
        else:
            try:
                NBT = nbt.read_from_nbt_file(open(file, "rb").read(), "little")
                self.UI = MainUI(self.MainFrame, self.SetMainEditMove, NBT, "Key", "根标签:"+self.Name)
            except Exception as e:
                tk.messagebox.showerror("error", f"不支持的文件格式\nerror:\n    {str(e)}")
                self.Close()
        
    def _SetWinFrame(self, MainFrame):
        
        self.WinFrame = tk.Frame(MainFrame,bd=1)
        
        Button = tk.Button(self.WinFrame,text=self.Name+" ",anchor="w",takefocus=False,bg="#898C8E",borderwidth=0,highlightthickness=1,command=self.SetWin)
        Button.pack()
        
        MainClose = tk.Frame(self.WinFrame,bg="red")
        MainClose.place(x=Button.winfo_reqwidth()-getInt(63),y=3)
        CloseFrame = tk.Frame(MainClose,width=getInt(60),height=getInt(60),bg="#898C8E")
        tk.Button(CloseFrame,text="x",font=('',9),width=1,height=1,command=self.Close,bg="#898C8E",borderwidth=0,highlightthickness=0).pack()
        CloseFrame.pack_propagate(0)
        CloseFrame.pack(anchor="se")
        self.WinFrame.pack(side="left")
        
        setListFrameMove(Button)
        
    def _SetEdit(self, Edit, ToolMenu):
        
        self.EditFrame = tk.Frame(Edit, bg="black",height=getInt(1740))
        self.EditFrame.place(x=getInt(10))
        EditScrollX = tk.Scrollbar(self.EditFrame, orient="horizontal")
        TopEditFrame = tk.Frame(self.EditFrame)
        EditScrollY = tk.Scrollbar(TopEditFrame, orient="vertical")
        self.MainEdit = tk.Canvas(TopEditFrame,width=getInt(1000),height=getInt(1675),bg="#2B303B",yscrollcommand=EditScrollY.set,xscrollcommand=EditScrollX.set,scrollregion=(0, 0, 0, 0))
        self.MainEdit.pack_propagate(0)
        EditScrollX.bind("<ButtonPress-1>", lambda a: self.MainEdit.config(scrollregion=(0, 0, self.MainEdit.bbox(self.MainFrameSize)[2]+getInt(100), self.MainEdit.bbox(self.MainFrameSize)[3]+getInt(100))))
        EditScrollY.bind("<ButtonPress-1>", lambda a: self.MainEdit.config(scrollregion=(0, 0, self.MainEdit.bbox(self.MainFrameSize)[2]+getInt(100), self.MainEdit.bbox(self.MainFrameSize)[3]+getInt(100))))
        
        self.MainFrame = tk.Frame(self.MainEdit,bg="#2B303B",borderwidth=0,highlightthickness=0)
        
        self.MainFrameSize = self.MainEdit.create_window(getInt(100), getInt(100),anchor="nw", window=self.MainFrame)
        
        self.SetMainEditMove(self.MainEdit)
        self.SetMainEditMove(self.MainFrame)
        self.MainEdit.pack(side="left")
        
        EditScrollY.config(command=self.MainEdit.yview)
        EditScrollY.pack(side='right', fill='y')
        TopEditFrame.pack()
        EditScrollX.config(command=self.MainEdit.xview)
        EditScrollX.pack(side='bottom', fill='x')
    
    def SetMainEditMove(self, MainMove):
        def on_canvas_click(event):
            self.MainEdit.scan_mark(event.x_root-self.MainEdit.winfo_rootx(), event.y_root-self.MainEdit.winfo_rooty())
            self.MainEdit.config(scrollregion=(0, 0, self.MainEdit.bbox(self.MainFrameSize)[2]+getInt(100), self.MainEdit.bbox(self.MainFrameSize)[3]+getInt(100)))
            if ToolMenuBoole: ToolMenu()
        def on_canvas_drag(event):
            self.MainEdit.scan_dragto(event.x_root-self.MainEdit.winfo_rootx(), event.y_root-self.MainEdit.winfo_rooty(), gain=1)
        MainMove.bind("<ButtonPress-1>", on_canvas_click)
        MainMove.bind("<B1-Motion>", on_canvas_drag)
    
    
    def Close(self, Mode=False):
        if Mode or tk.messagebox.askokcancel("Close", "关闭窗口会销毁你所有的数据\n请及时保存"):
            global EditClass
            self.EditFrame.place_forget()
            self.WinFrame.pack_forget()
            for i in range(len(EditClass)):
                if EditClass[i-1] == self: del EditClass[i-1]
            try:
                EditClass[0].SetWin()
            except:
                EditClass.append(NBTEdit("    引导    ", Edit, WinFrame, ToolMenu))
    
    def SetWin(self):
        global EditClass
        
        for i in EditClass:
            i.EditShow = False
        self.EditShow = True
        for i in EditClass:
            if i.EditShow == False: i.EditFrame.place_forget()
        self.EditFrame.place(x=getInt(10))
    def GetNBT(self):
        return self.UI.GetNBT()
    



class MainUI:
    def __init__(self, MainFrame, SetMainEditMove, NBT, Type, Name="", Show=True):
        
        self.Value = Name
        self.Type = Type
        self.NBT = NBT
        self.Tag = NBT.type_id
        self.PictureName = list(Picture.keys())[NBT.type_id-1]
        self.SetMainEditMove = SetMainEditMove
        
        
        
        self.HideType = False
        
        self._SetMainFrame(MainFrame, Show)
        if Type == "Key" or Type == "Keys": self._SetTag()
        if not Type == "Keys": self._SetName()
        if Type == "Value": self._SetEdit()
        if Type == "Key" or Type == "Keys": self._SetList()
    
    def _SetMainFrame(self, MainFrame, Show):
        self.MainFrame = tk.Frame(MainFrame,bg="#898C8E",borderwidth=0,highlightthickness=0)
        self.SubFrame = tk.Frame(MainFrame,bg="#2B303B",borderwidth=0,highlightthickness=0)
        if Show: self.MainFrame.pack(anchor="nw")
        Line = tk.Frame(self.SubFrame, width=getInt(90), bg="#2B303B")
        Line.pack(side="left",fill="y")
        if Show: self.SubFrame.pack(anchor="nw")
        self.SetMainEditMove(self.MainFrame)
        self.SetMainEditMove(self.SubFrame)
        self.SetMainEditMove(Line)
    
    def _SetTag(self):
        if hasattr(self, "TagButton"):
            self.TagButton.config(image=Picture[self.PictureName])
            return
        self.TagButton = tk.Button(self.MainFrame, image=Picture[self.PictureName], bg="#898C8E",borderwidth=0,highlightthickness=0, command=self.SetToplevel)
        self.TagButton.pack(side="left")
        self.SetMainEditMove(self.TagButton)
    
    def _SetName(self):
        if hasattr(self, "Name"):
            self.Name.config(text=" "+self.Value+" ")
            return
        self.Name = tk.Label(self.MainFrame, text=" "+self.Value+" ",bg="#898C8E",borderwidth=0,highlightthickness=0)
        self.Name.pack(side="left")
        self.SetMainEditMove(self.Name)
    
    def _SetEdit(self):
        self.Edit = tk.Button(self.MainFrame, image=Picture["Edit"], bg="#898C8E",borderwidth=0,highlightthickness=0, command=self.SetToplevel)
        self.Edit.pack(side="left")
        self.SetMainEditMove(self.Edit)
    
    def _SetList(self):
        self.ListFrame = tk.Frame(self.MainFrame, width=getInt(90), height=getInt(90), bg="#898C8E",borderwidth=0,highlightthickness=0)
        self.ListFrame.pack_propagate(0)
        self.ListFrame.pack(side="left")
        self.List = tk.Button(self.ListFrame, image=Picture["NBTListOpen"], bg="#898C8E",borderwidth=0,highlightthickness=0, command=self.OpenList)
        self.List.pack(side="left")
        self.SetMainEditMove(self.List)
    
    def Hide(self):
        self.MainFrame.pack_forget()
        self.SubFrame.pack_forget()
    
    def Show(self):
        self.MainFrame.pack(anchor="nw")
        self.SubFrame.pack(anchor="nw")
    
    def SetToplevel(self):
        self.EditSet = tk.Toplevel(self.MainFrame)
        self.EditSet.resizable(False, False)
        small_win_width, small_win_height = int(RootFrame.winfo_width()*0.97), int(RootFrame.winfo_height()*0.5)
        self.EditSet.geometry('%sx%s+%s+%s'%(small_win_width,small_win_height,RootFrame.winfo_x(),RootFrame.winfo_y()))
        self.EditSet.transient(self.MainFrame)
        self.EditSet.title('Edit nbt properties')
        tk.Frame(self.EditSet, height=getInt(50)).pack(side="top",fill="x")
        tk.Frame(self.EditSet, width=getInt(50)).pack(side="left",fill="y")
        tk.Frame(self.EditSet, width=getInt(50)).pack(side="right",fill="y")
        tk.Frame(self.EditSet, height=getInt(50)).pack(side="bottom",fill="x")
        MainFrame = tk.Frame(self.EditSet, height=getInt(900))
        MainFrame.pack(fill="both")
        ChangeTag = tk.Frame(MainFrame, bd=getInt(25))
        ChangeValue = tk.Frame(MainFrame, bd=getInt(25))
        ChangeList = tk.Frame(MainFrame, bd=getInt(25))
        ChangeTag.pack(fill="x")
        ChangeValue.pack(fill="x")
        ChangeList.pack(fill="x")
        
        def Close():
            self.EditSet.destroy()
            if not self.Type == "Keys": self.Value = self.value.get()
            if self.Type == "Key" or self.Type == "Keys": self._SetTag()
            if not self.Value == "": self._SetName()
        
        def SetTag(Number):
            if not tk.messagebox.askokcancel("Change", "改变类型会销毁当前标签下的所有数据"): return
            if hasattr(self, "SubUI") and self.HideType: self.OpenList()
            if hasattr(self, "SubUI"): del self.SubUI
            if hasattr(self, "PageUI"): del self.PageUI
            if hasattr(self, "NBT"): del self.NBT
            self.PictureName = list(Picture.keys())[Number-1]
            if Number == 1: self.NBT = nbt.TagByte()
            if Number == 2: self.NBT = nbt.TagShort()
            if Number == 3: self.NBT = nbt.TagInt()
            if Number == 4: self.NBT = nbt.TagLong()
            if Number == 5: self.NBT = nbt.TagFloat()
            if Number == 6: self.NBT = nbt.TagDouble()
            if Number == 7: self.NBT = nbt.TagByteArray()
            if Number == 8: self.NBT = nbt.TagString()
            if Number == 9: self.NBT = nbt.TagList()
            if Number == 10: self.NBT = nbt.TagCompound()
            if Number == 11: self.NBT = nbt.TagIntArray()
            if Number == 12: self.NBT = nbt.TagLongArray()
            self.Tag = self.NBT.type_id
            Close()
        
        def AddList(Number):
            self.OpenList()
            if Number == 1: NBT = nbt.TagByte()
            if Number == 2: NBT = nbt.TagShort()
            if Number == 3: NBT = nbt.TagInt()
            if Number == 4: NBT = nbt.TagLong()
            if Number == 5: NBT = nbt.TagFloat()
            if Number == 6: NBT = nbt.TagDouble()
            if Number == 7: NBT = nbt.TagByteArray()
            if Number == 8: NBT = nbt.TagString()
            if Number == 9: NBT = nbt.TagList()
            if Number == 10: NBT = nbt.TagCompound()
            if Number == 11: NBT = nbt.TagIntArray()
            if Number == 12: NBT = nbt.TagLongArray()
            if self.Tag == 10: self.SubUI["第"+str(len(list(self.SubUI.keys()))+1)+"个元素"] = (MainUI(self.SubFrame, self.SetMainEditMove, NBT, "Key", "第"+str(len(list(self.SubUI.keys()))+1)+"个元素", False))
            if self.Tag == 9: self.SubUI.append(MainUI(self.SubFrame, self.SetMainEditMove, NBT, "Keys", "", False))
            self.OpenList()
            
            tk.messagebox.showinfo("Add", "添加成功")
        
        #Tag
        if self.Type == "Key" or self.Type == "Keys":
            tk.Label(ChangeTag, text="改变当前\n标签类型").pack(side="left")
            TagLine1 = tk.Frame(ChangeTag)
            TagLine2 = tk.Frame(ChangeTag)
            TagLine1.pack()
            TagLine2.pack()
            for i in range(6):
                tk.Button(TagLine1, command=lambda number=i: SetTag(number+1), image=Picture[list(Picture.keys())[i]]).pack(side="left")
            for i in range(6):
                tk.Button(TagLine2, command=lambda number=i: SetTag(number+7), image=Picture[list(Picture.keys())[i+6]]).pack(side="left")
        
        # Value
        if not self.Type == "Keys":
            if self.Type == "Key" or self.Type == "Keys": tk.Label(ChangeValue, text="Key:", font=("",12)).pack(side="left")
            if self.Type == "Value": tk.Label(ChangeValue, text="Value:", font=("",12)).pack(side="left")
            self.value = tk.StringVar()
            Value = tk.Entry(ChangeValue, textvariable=self.value, width=32)
            SetInput(Value)
            Value.pack(side="left", fill="both")
            self.value.set(self.Value)
        
        #Tag
        if self.Tag in [7, 9, 10, 11, 12]:
            tk.Label(ChangeList, text="添加标签").pack(side="left")
            ListLine1 = tk.Frame(ChangeList)
            ListLine2 = tk.Frame(ChangeList)
            ListLine1.pack()
            ListLine2.pack()
            for i in range(6):
                tk.Button(ListLine1, command=lambda number=i: AddList(number+1), image=Picture[list(Picture.keys())[i]]).pack(side="left")
            for i in range(6):
                tk.Button(ListLine2, command=lambda number=i: AddList(number+7), image=Picture[list(Picture.keys())[i+6]]).pack(side="left")
        
        #关闭
        tk.Button(MainFrame, command=Close, text="保存关闭", font=("",20)).pack()
        
    def OpenList(self):
        if hasattr(self, "PageUI") and self.HideType:
            self.HideType = False
            self.List.config(image=Picture["NBTListOpen"])
            self.CloseList()
            return
        elif hasattr(self, "PageUI") and not self.HideType:
            self.HideType = True
            self.List.config(image=Picture["NBTListClose"])
            self.PageUI.SetPage(1)
            return
        elif hasattr(self, "SubUI") and self.HideType:
            self.HideType = False
            self.List.config(image=Picture["NBTListOpen"])
            self.CloseList()
            return
        elif hasattr(self, "SubUI") and not self.HideType:
            self.HideType = True
            self.List.config(image=Picture["NBTListClose"])
            if isinstance(self.SubUI, dict):
                for i in self.SubUI: self.SubUI[i].Show()
            elif isinstance(self.SubUI, list):
                for i in self.SubUI: i.Show()
            else:
                self.SubUI.Show()
            return
        
        #初始化
        if hasattr(self.NBT, "__iter__") and self.Tag == 10:
            self.SubUI = {}
            for k in self.NBT:
                self.SubUI[k] = MainUI(self.SubFrame, self.SetMainEditMove, self.NBT[k], "Key", k, False)
            if len(self.NBT) > 20:
                self.PageUI = PageFrame(self.SubFrame, self.SetMainEditMove, 20, len(self.NBT), self.PageChange)
            self.OpenList()
        elif hasattr(self.NBT, "__iter__") and self.Tag == 9:
            self.SubUI = []
            for v in self.NBT:
                self.SubUI.append(MainUI(self.SubFrame, self.SetMainEditMove, v, "Keys", "", False))
            if len(self.NBT) > 30:
                self.PageUI = PageFrame(self.SubFrame, self.SetMainEditMove, 30, len(self.NBT), self.PageChange)
            self.OpenList()
        else:
            self.SubUI = MainUI(self.SubFrame, self.SetMainEditMove, self.NBT, "Value", str(self.NBT.value), False)
            self.OpenList()
        del self.NBT
    
    def CloseList(self):
        if hasattr(self, "PageUI"):
            self.PageUI.Hide()
        if isinstance(self.SubUI, dict):
            for i in self.SubUI:
                if self.SubUI[i].HideType: self.SubUI[i].OpenList()
                self.SubUI[i].Hide()
        elif isinstance(self.SubUI, list):
            for i in self.SubUI:
                if i.HideType: i.OpenList()
                i.Hide()
        else:
            self.SubUI.Hide()
    def PageChange(self, PageNumber):
        self.CloseList()
        self.PageUI.Show()
        if isinstance(self.SubUI, dict):
            Length = len(self.SubUI)%20
            if Length == 0 or len(self.SubUI) - PageNumber*20 > 0: Length = 20
            for i in range(Length):
                self.SubUI[list(self.SubUI.keys())[(PageNumber-1) * 20 + i]].Show()
        elif isinstance(self.SubUI, list):
            Length = len(self.SubUI)%30
            if Length == 0 or len(self.SubUI) - PageNumber*30 > 0: Length = 30
            for i in range(Length):
                self.SubUI[(PageNumber-1) * 30 + i].Show()
    
    def GetNBT(self):
        if hasattr(self, "NBT") and not self.Type == "Value": return self.NBT
        if self.Type == "Key" or self.Type == "Keys":
            try:
                if self.Tag == 1: NBT = nbt.TagByte(int(self.SubUI.GetNBT()))
                if self.Tag == 2: NBT = nbt.TagShort(int(self.SubUI.GetNBT()))
                if self.Tag == 3: NBT = nbt.TagInt(int(self.SubUI.GetNBT()))
                if self.Tag == 4: NBT = nbt.TagLong(int(self.SubUI.GetNBT()))
                if self.Tag == 5: NBT = nbt.TagFloat(float(self.SubUI.GetNBT()))
                if self.Tag == 6: NBT = nbt.TagDouble(float(self.SubUI.GetNBT()))
                if self.Tag == 7: NBT = nbt.TagByteArray()
                if self.Tag == 8: NBT = nbt.TagString(str(self.SubUI.GetNBT()))
                if self.Tag == 9:
                    try:
                        NBT = nbt.TagList(tag_type=self.SubUI[0].GetNBT())
                    except:
                        NBT = nbt.TagList(tag_type=nbt.NBTTagEnd())
                    for v in self.SubUI:
                        NBT.append(v.GetNBT())
                if self.Tag == 10:
                    NBT = nbt.TagCompound()
                    for k in self.SubUI:
                        NBT[k] = self.SubUI[k].GetNBT()
                if self.Tag == 11: NBT = nbt.TagIntArray()
                if self.Tag == 12: NBT = nbt.TagLongArray()
            except:
                if self.Tag == 1: NBT = nbt.TagByte()
                if self.Tag == 2: NBT = nbt.TagShort()
                if self.Tag == 3: NBT = nbt.TagInt()
                if self.Tag == 4: NBT = nbt.TagLong()
                if self.Tag == 5: NBT = nbt.TagFloat()
                if self.Tag == 6: NBT = nbt.TagDouble()
                if self.Tag == 7: NBT = nbt.TagByteArray()
                if self.Tag == 8: NBT = nbt.TagString()
                if self.Tag == 9: NBT = nbt.TagList(tag_type=nbt.NBTTagEnd())
                if self.Tag == 10: NBT = nbt.TagCompound()
                if self.Tag == 11: NBT = nbt.TagIntArray()
                if self.Tag == 12: NBT = nbt.TagLongArray()
            return NBT
        else:
            return self.Value
    
class PageFrame:
    def __init__(self, MainFrame, SetMainEditMove, UIMaxQuantity, UIQuantity, PageChange):
        self.MaxPage = math.ceil(UIQuantity / UIMaxQuantity)
        self.Page = 1
        self.PageChange = PageChange
        
        self.MainFrame = tk.Frame(MainFrame,bg="#898C8E",borderwidth=0,highlightthickness=0)
        UpPage = tk.Button(self.MainFrame, bg="#393C3E", text="上一页", command=lambda: self.MovePage(-1))
        NextPage = tk.Button(self.MainFrame, bg="#393C3E", text="下一页", command=lambda: self.MovePage(1))
        self.TextPage = tk.Label(self.MainFrame)
        
        UpPage.pack(side="left", fill="y")
        self.TextPage.pack(side="left")
        NextPage.pack(side="left", fill="y")
        
        SetMainEditMove(UpPage)
        SetMainEditMove(NextPage)
        SetMainEditMove(self.TextPage)
        
        
    def Hide(self):
        self.MainFrame.pack_forget()
    
    def Show(self):
        self.MainFrame.pack(anchor="nw")
    
    def SetPage(self, Number):
        self.Page = Number
        self.TextPage.config(text=f"当前是第:{self.Page}页\n总页数:{self.MaxPage}")
        self.PageChange(self.Page)
    
    def MovePage(self, Number):
        Number += self.Page
        if 0 < Number <= self.MaxPage:
            self.SetPage(Number)











