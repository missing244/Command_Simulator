from json import load

with open("expand_pack/NBTedit/config.json") as config:
    Json = load(config)
    LoadPictureList = Json.get("LoadPictureList", None)
    LoadPictureList2 = Json.get("LoadPictureList2", None)
    NBTeditPath = Json.get("NBTeditPath", None)
    HelpText = Json.get("HelpText", None)
    ClipBoardText = Json.get("ClipBoardText", None)
    EditFrameRemoveTime = Json.get("EditFrameRemoveTime", None)
    NBTagFrameMaxList = Json.get("NBTagFrameMaxList", None)
    CommandBlockMap = Json.get("CommandBlockMap", None)
for List in LoadPictureList2:
    for i in range(List[0]):
        LoadPictureList.append([List[1], List[2]+str(i)])

for k, v in CommandBlockMap.items():
    CommandBlockMap[k] = []
    for i in range(v[0]):
        CommandBlockMap[k].append(v[1]+str(i))
