from ._leveldb import (
    LevelDB,
    LevelDBException,
    LevelDBEncrypted,
    LevelDBIteratorException,
    Iterator,
)

# from . import _version

# __version__ = _version.get_versions()["version"]
__version__ = "0.0.1a"
