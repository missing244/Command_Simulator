from setuptools import setup, Extension
import os

setup(
    name="MCBEWorld_C_API",
    ext_modules=[
        Extension(
            "MCBEWorld_C_API", 
            sources=["fast_api.c"],
            define_macros=[("Py_LIMITED_API", "0x03080000")],
            py_limited_api=True
        )
    ]
)
