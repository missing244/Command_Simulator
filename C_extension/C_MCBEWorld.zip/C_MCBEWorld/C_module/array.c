#define Py_LIMITED_API 0x03080000
#define PY_SSIZE_T_CLEAN
#include <math.h>
#include <Python.h>
#include "array.h"

static long long GetCharArrayValue(struct ArrayAttr *Attr, unsigned long long Index) {
    return *((signed char *)(Attr->pointer) + Index);
}
static long long GetUCharArrayValue(struct ArrayAttr *Attr, unsigned long long Index) {
    return *((unsigned char *)(Attr->pointer) + Index);
}
static long long GetShortArrayValue(struct ArrayAttr *Attr, unsigned long long Index) {
    return *((signed short *)(Attr->pointer) + Index);
}
static long long GetUShortArrayValue(struct ArrayAttr *Attr, unsigned long long Index) {
    return *((unsigned short *)(Attr->pointer) + Index);
}
static long long GetIntArrayValue(struct ArrayAttr *Attr, unsigned long long Index) {
    return *((signed int *)(Attr->pointer) + Index);
}
static long long GetUIntArrayValue(struct ArrayAttr *Attr, unsigned long long Index) {
    return *((unsigned int *)(Attr->pointer) + Index);
}
static long long GetLongArrayValue(struct ArrayAttr *Attr, unsigned long long Index) {
    return *((signed long *)(Attr->pointer) + Index);
}
static long long GetULongArrayValue(struct ArrayAttr *Attr, unsigned long long Index) {
    return *((unsigned long *)(Attr->pointer) + Index);
}
static long long GetLongLongArrayValue(struct ArrayAttr *Attr, unsigned long long Index) {
    return *((signed long long *)(Attr->pointer) + Index);
}
static long long GetULongLongArrayValue(struct ArrayAttr *Attr, unsigned long long Index) {
    return *((unsigned long long *)(Attr->pointer) + Index);
}

static void SetCharArrayValue(struct ArrayAttr *Attr, unsigned long long Index, long long Value) {
    *((signed char *)(Attr->pointer) + Index) = (signed char)Value;
}
static void SetUCharArrayValue(struct ArrayAttr *Attr, unsigned long long Index, long long Value) {
    *((unsigned char *)(Attr->pointer) + Index) = (unsigned char)Value;
}
static void SetShortArrayValue(struct ArrayAttr *Attr, unsigned long long Index, long long Value) {
    *((signed short *)(Attr->pointer) + Index) = (signed short)Value;
}
static void SetUShortArrayValue(struct ArrayAttr *Attr, unsigned long long Index, long long Value) {
    *((unsigned short *)(Attr->pointer) + Index) = (unsigned short)Value;
}
static void SetIntArrayValue(struct ArrayAttr *Attr, unsigned long long Index, long long Value) {
    *((signed int *)(Attr->pointer) + Index) = (signed int)Value;
}
static void SetUIntArrayValue(struct ArrayAttr *Attr, unsigned long long Index, long long Value) {
    *((unsigned int *)(Attr->pointer) + Index) = (unsigned int)Value;
}
static void SetLongArrayValue(struct ArrayAttr *Attr, unsigned long long Index, long long Value) {
    *((signed long *)(Attr->pointer) + Index) = (signed long)Value;
}
static void SetULongArrayValue(struct ArrayAttr *Attr, unsigned long long Index, long long Value) {
    *((unsigned long *)(Attr->pointer) + Index) = (unsigned long)Value;
}
static void SetLongLongArrayValue(struct ArrayAttr *Attr, unsigned long long Index, long long Value) {
    *((signed long long *)(Attr->pointer) + Index) = (signed long long)Value;
}
static void SetULongLongArrayValue(struct ArrayAttr *Attr, unsigned long long Index, long long Value) {
    *((unsigned long long *)(Attr->pointer) + Index) = (unsigned long long)Value;
}


struct ArrayAttr GetArrayAttr(PyObject* ArrayObject) {
    struct ArrayAttr Attr = {0, NULL, 0, 'b'};
    
    PyObject *buffer_info = PyObject_CallMethod(ArrayObject, "buffer_info", NULL);
    PyObject *typecode_obj = PyObject_GetAttrString(ArrayObject, "typecode");
    PyObject *itemsize_obj = PyObject_GetAttrString(ArrayObject, "itemsize");

    Attr.pointer = (unsigned char*)PyLong_AsVoidPtr( PyTuple_GetItem(buffer_info, 0) );
    Attr.length = PyLong_AsSsize_t( PyTuple_GetItem(buffer_info, 1) );
    Attr.typecode = PyUnicode_ReadChar(typecode_obj, 0);
    Attr.type_length = (unsigned char)PyLong_AsLong(itemsize_obj);

    switch (Attr.typecode) {
        case 'b': {Attr.GetArrayValue = GetCharArrayValue; break;}
        case 'B': {Attr.GetArrayValue = GetUCharArrayValue; break;}
        case 'h': {Attr.GetArrayValue = GetShortArrayValue; break;}
        case 'H': {Attr.GetArrayValue = GetUShortArrayValue; break;}
        case 'i': {Attr.GetArrayValue = GetIntArrayValue; break;}
        case 'I': {Attr.GetArrayValue = GetUIntArrayValue; break;}
        case 'l': {Attr.GetArrayValue = GetLongArrayValue; break;}
        case 'L': {Attr.GetArrayValue = GetULongArrayValue; break;}
        case 'q': {Attr.GetArrayValue = GetLongLongArrayValue; break;}
        case 'Q': {Attr.GetArrayValue = GetULongLongArrayValue; break;}
        default : {Attr.GetArrayValue = NULL; break;}
    }
    switch (Attr.typecode) {
        case 'b': {Attr.SetArrayValue = SetCharArrayValue; break;}
        case 'B': {Attr.SetArrayValue = SetUCharArrayValue; break;}
        case 'h': {Attr.SetArrayValue = SetShortArrayValue; break;}
        case 'H': {Attr.SetArrayValue = SetUShortArrayValue; break;}
        case 'i': {Attr.SetArrayValue = SetIntArrayValue; break;}
        case 'I': {Attr.SetArrayValue = SetUIntArrayValue; break;}
        case 'l': {Attr.SetArrayValue = SetLongArrayValue; break;}
        case 'L': {Attr.SetArrayValue = SetULongArrayValue; break;}
        case 'q': {Attr.SetArrayValue = SetLongLongArrayValue; break;}
        case 'Q': {Attr.SetArrayValue = SetULongLongArrayValue; break;}
        default : {Attr.SetArrayValue = NULL; break;}
    }

    Py_DECREF(buffer_info);
    Py_DECREF(typecode_obj);
    Py_DECREF(itemsize_obj);
    return Attr;
}

void PrintArrayAttr(struct ArrayAttr *Attr) {
    printf("length -> %lld \n", Attr->length);
    printf("pointer -> %p \n", Attr->pointer);
    printf("typecode -> %c \n", Attr->typecode);
    printf("type_length -> %d \n", Attr->type_length);
}


