#define Py_LIMITED_API 0x03080000
#define PY_SSIZE_T_CLEAN
#include <Python.h>

struct ArrayAttr;
typedef long long (*GetArrayValueFunc)(struct ArrayAttr*, unsigned long long);
typedef void (*SetArrayValueFunc)(struct ArrayAttr*, unsigned long long, long long);

struct ArrayAttr {
    Py_ssize_t length;
    unsigned char *pointer;
    Py_UCS4 typecode;
    unsigned char type_length;
    GetArrayValueFunc GetArrayValue;
    SetArrayValueFunc SetArrayValue;
};

struct ArrayAttr GetArrayAttr(PyObject* ArrayObject);
void PrintArrayAttr(struct ArrayAttr *Attr);
