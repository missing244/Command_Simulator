#define Py_LIMITED_API 0x03080000
#define PY_SSIZE_T_CLEAN
#include <math.h>
#include <Python.h>
PyObject** PyIntArray = NULL;


long long number_div(long long value, long long modulus) {
    lldiv_t result = lldiv(value, modulus) ;
    if (value < 0 && result.rem != 0) return result.quot - 1;
    return result.quot;
}

long long number_mod(long long value, long long modulus) {
    long long result = number_div(value, modulus);
    return value - result*modulus;
}


struct ArrayAttr {
    Py_ssize_t length;
    unsigned char *pointer;
    Py_UCS4 typecode;
    unsigned char type_length;
};

static struct ArrayAttr GetArrayAttr(PyObject* ArrayObject) {
    struct ArrayAttr Attr = {0, NULL, 0, 'b'};
    
    PyObject *buffer_info = PyObject_CallMethod(ArrayObject, "buffer_info", NULL);
    PyObject *typecode_obj = PyObject_GetAttrString(ArrayObject, "typecode");
    PyObject *itemsize_obj = PyObject_GetAttrString(ArrayObject, "itemsize");

    Attr.pointer = (unsigned char*)PyLong_AsVoidPtr( PyTuple_GetItem(buffer_info, 0) );
    Attr.length = PyLong_AsSsize_t( PyTuple_GetItem(buffer_info, 1) );
    Attr.typecode = PyUnicode_ReadChar(typecode_obj, 0);
    Attr.type_length = (unsigned char)PyLong_AsLong(itemsize_obj);

    Py_DECREF(buffer_info);
    Py_DECREF(typecode_obj);
    Py_DECREF(itemsize_obj);
    return Attr;
}

static long long GetArrayValue(struct ArrayAttr *Attr, long long Index) {
    long long NowPointer = Attr->type_length * Index;
    switch (Attr->typecode) {
        case 'b': return *(signed char *)(Attr->pointer + NowPointer);
        case 'B': return *(unsigned char *)(Attr->pointer + NowPointer);
        case 'h': return *(signed short *)(Attr->pointer + NowPointer);
        case 'H': return *(unsigned short *)(Attr->pointer + NowPointer);
        case 'i': return *(signed int *)(Attr->pointer + NowPointer);
        case 'I': return *(unsigned int *)(Attr->pointer + NowPointer);
        case 'l': return *(signed long *)(Attr->pointer + NowPointer);
        case 'L': return *(unsigned long *)(Attr->pointer + NowPointer);
        case 'q': return *(signed long long *)(Attr->pointer + NowPointer);
        case 'Q': return *(unsigned long long *)(Attr->pointer + NowPointer);
        default : return 0;
    }
}

static void SetArrayValue(struct ArrayAttr *Attr, long long Index, long long Value) {
    long long NowPointer = Attr->type_length * Index;
    switch (Attr->typecode) {
        case 'b': {*(signed char *)(Attr->pointer + NowPointer) = Value; break;}
        case 'B': {*(unsigned char *)(Attr->pointer + NowPointer) = Value; break;}
        case 'h': {*(signed short *)(Attr->pointer + NowPointer) = Value; break;}
        case 'H': {*(unsigned short *)(Attr->pointer + NowPointer) = Value; break;}
        case 'i': {*(signed int *)(Attr->pointer + NowPointer) = Value; break;}
        case 'I': {*(unsigned int *)(Attr->pointer + NowPointer) = Value; break;}
        case 'l': {*(signed long *)(Attr->pointer + NowPointer) = Value; break;}
        case 'L': {*(unsigned long *)(Attr->pointer + NowPointer) = Value; break;}
        case 'q': {*(signed long long *)(Attr->pointer + NowPointer) = Value; break;}
        case 'Q': {*(unsigned long long *)(Attr->pointer + NowPointer) = Value; break;}
    }
}

static void PrintArrayAttr(struct ArrayAttr *Attr) {
    printf("length -> %lld \n", Attr->length);
    printf("pointer -> %p \n", Attr->pointer);
    printf("typecode -> %c \n", Attr->typecode);
    printf("type_length -> %d \n", Attr->type_length);
}


typedef struct {
    PyObject_HEAD
    Py_ssize_t startX;
    Py_ssize_t startZ;
    Py_ssize_t endX;
    Py_ssize_t endZ;
    Py_ssize_t middleX1;
    Py_ssize_t middleZ1;
} StructureOperatePosRange;

static PyObject* StructureOperatePos_iter_method(PyObject* self) {
    Py_INCREF(self);
    return self;
}

static PyObject* StructureOperatePos_iter_next_method(PyObject* self) {
    StructureOperatePosRange* it = (StructureOperatePosRange*)self;
    Py_ssize_t tuple_1 = it->middleX1;
    Py_ssize_t tuple_2 = it->middleZ1;
    Py_ssize_t tuple_3 = it->middleX1 + 16;
    Py_ssize_t tuple_4 = it->middleZ1 + 16;
    if (tuple_1 < it->startX) tuple_1 = it->startX;
    if (tuple_2 < it->startZ) tuple_2 = it->startZ;
    if (tuple_3 > it->endX) tuple_3 = it->endX;
    if (tuple_4 > it->endZ) tuple_4 = it->endZ;
    
    if (it->middleX1 >= it->endX) {
        PyErr_SetNone(PyExc_StopIteration);
        return NULL;
    } else {
        PyObject* tuple = PyTuple_New(4);
        PyTuple_SetItem(tuple, 0, PyLong_FromLongLong( tuple_1 ));
        PyTuple_SetItem(tuple, 1, PyLong_FromLongLong( tuple_2 ));
        PyTuple_SetItem(tuple, 2, PyLong_FromLongLong( tuple_3 ));
        PyTuple_SetItem(tuple, 3, PyLong_FromLongLong( tuple_4 ));

        it->middleZ1 += 16;
        if (it->middleZ1 >= it->endZ) {
            it->middleZ1 = number_div(it->startZ, 16) * 16;
            it->middleX1 += 16;
        }

        return tuple;
    }
}

static Py_ssize_t StructureOperatePos_len_method(PyObject* self) {
    StructureOperatePosRange* it = (StructureOperatePosRange*)self;
    Py_ssize_t x_len= number_div((it->endX-1), 16) - number_div(it->startX, 16) + 1;
    Py_ssize_t z_len= number_div((it->endZ-1), 16) - number_div(it->startZ, 16) + 1;
    return x_len * z_len;
}

static void StructureOperatePos_dealloc(PyObject* self) {
    StructureOperatePosRange* obj = (StructureOperatePosRange*)self;
    ((destructor)PyType_GetSlot(Py_TYPE(self), Py_tp_free))(self);
}

static PyType_Slot StructureOperatePosRange_slots[] = {
    {Py_sq_length, StructureOperatePos_len_method},
    {Py_tp_iter, StructureOperatePos_iter_method},
    {Py_tp_iternext, StructureOperatePos_iter_next_method},
    {Py_tp_dealloc, StructureOperatePos_dealloc},
    {0, NULL}
};

static PyType_Spec StructureOperatePosRange_spec = {
    .name = "MCBEWorld_C_API.StructureOperatePosRange",
    .basicsize = sizeof(StructureOperatePosRange),
    .itemsize = 0,
    .flags = Py_TPFLAGS_DEFAULT,
    .slots = StructureOperatePosRange_slots
};

static PyObject* StructureOperatePosRange_Iteration(PyObject* self, PyObject* args) {
    Py_ssize_t startX;
    Py_ssize_t startZ;
    Py_ssize_t endX;
    Py_ssize_t endZ;
    if (!PyArg_ParseTuple(args, "nnnn", &startX, &startZ, &endX, &endZ)) return NULL;

    PyObject* type = PyType_FromSpec(&StructureOperatePosRange_spec);
    if (!type) return NULL;

    PyObject* obj = PyObject_CallObject(type, NULL);
    Py_DECREF(type);
    if (!obj) return NULL;

    ((StructureOperatePosRange*)obj)->startX = startX;
    ((StructureOperatePosRange*)obj)->startZ = startZ;
    ((StructureOperatePosRange*)obj)->endX = endX;
    ((StructureOperatePosRange*)obj)->endZ = endZ;
    ((StructureOperatePosRange*)obj)->middleX1 = number_div(startX, 16) * 16 ;
    ((StructureOperatePosRange*)obj)->middleZ1 = number_div(startZ, 16) * 16;
    return obj;
}



static PyObject* cycle_xor(PyObject* self, PyObject* args) {
    const unsigned char *input_bytes;
    Py_ssize_t input_len;
    const unsigned char *key_bytes;
    Py_ssize_t key_len;

    if (!PyArg_ParseTuple(args, "y#y#", &input_bytes, 
        &input_len, &key_bytes, &key_len)) return NULL;

    unsigned char *result = malloc(input_len);
    if (!result) return PyErr_NoMemory();

    for (Py_ssize_t i = 0; i < input_len; i++) {
        result[i] = input_bytes[i] ^ key_bytes[i % key_len];
    }

    PyObject *output = PyBytes_FromStringAndSize(result, input_len);
    free(result);
    return output;
}

static PyObject* is_chunk_key(PyObject* self, PyObject* args) {
    char *input_bytes;
    Py_ssize_t input_len;
    int32_t dimensionID;

    if (!PyArg_ParseTuple(args, "iy#", &dimensionID, &input_bytes, &input_len)) return NULL;
    if (!dimensionID && (input_len != 9 || input_bytes[input_len-1] != '6')) Py_RETURN_FALSE;
    if (dimensionID && (input_len != 13 || input_bytes[input_len-1] != '6')) Py_RETURN_FALSE;
    if (dimensionID) {
        int32_t dimension = ((int32_t *)input_bytes)[2] ;
        if (dimension != dimensionID) Py_RETURN_FALSE; 
    }

    PyObject* tuple = PyTuple_New(2);
    PyTuple_SetItem(tuple, 0, PyLong_FromLongLong( ((int32_t *)input_bytes)[0] ));  // 设置第0个元素
    PyTuple_SetItem(tuple, 1, PyLong_FromLongLong( ((int32_t *)input_bytes)[1] ));  // 设置第1个元素
    return tuple;
}

static PyObject* chunk_upgrade(PyObject* self, PyObject* args) {
    unsigned char *index_bytes, *data_bytes;
    Py_ssize_t index_len, data_len;
    PyObject *ChunkIndexArray;
    unsigned short BlockCount = 1;

    if (!PyArg_ParseTuple(args, "Oy#y#", &ChunkIndexArray, &index_bytes, &index_len, &data_bytes, &data_len)) return NULL;
    struct ArrayAttr ChunkIndexAttr = GetArrayAttr(ChunkIndexArray);
    unsigned short *IndexDataArray = calloc(256*256, sizeof(unsigned short));
    for (size_t i = 0; i < index_len; i++) {
        unsigned char Index = index_bytes[i];
        unsigned char Data = data_bytes[i>>1];
        if (i & 1) Data = (Data & 0xf0) >> 4;
        else Data = (Data & 0x0f);
        unsigned short IndexData = (Index << 8) | Data;
        if (!IndexDataArray[IndexData]) {
            IndexDataArray[IndexData] = BlockCount;
            BlockCount++;
        }
        SetArrayValue(&ChunkIndexAttr, i, IndexDataArray[IndexData]-1) ;
    }
    
    PyObject *output = PyBytes_FromStringAndSize((char*)IndexDataArray, 256*256*sizeof(unsigned short));
    free(IndexDataArray);
    return output;
}

static PyObject* chunk_parser(PyObject* self, PyObject* args) {
    const unsigned char *input_bytes;
    Py_ssize_t input_len;
    PyObject *ChunkArrayObject;
    unsigned char block_use_bit;

    if (!PyArg_ParseTuple(args, "nOy#", &block_use_bit, &ChunkArrayObject, &input_bytes, &input_len)) return NULL;
    struct ArrayAttr ChunkArrayAttr = GetArrayAttr(ChunkArrayObject);

    if (input_len <= 0 || input_len % 4 != 0) {
        PyErr_SetString(PyExc_ValueError, "zip_bytes_array must be positive and divisible by 4");
        return NULL;
    } else if (block_use_bit == 0 || block_use_bit > 32) {
        PyErr_SetString(PyExc_ValueError, "block_use_bit must be between 1 and 32");
        return NULL;
    }

    unsigned int block_count_in_4_bytes = 32 / block_use_bit;
    unsigned int and_oper = 0xffffffff >> (32 - block_use_bit);
    unsigned int chunk_data_int = 0, array_index = 0;
    for ( Py_ssize_t i = 0; i < input_len; i+=4) {
        memcpy(&chunk_data_int, input_bytes+i, sizeof(unsigned int));
        for (Py_ssize_t j = 0; j < block_count_in_4_bytes; j++) {
            if (array_index+j >= 4096) break;
            SetArrayValue(&ChunkArrayAttr, array_index+j, chunk_data_int&and_oper);
            chunk_data_int >>= block_use_bit;
        }
        array_index += block_count_in_4_bytes;
    }

    Py_RETURN_NONE;
}

static PyObject* chunk_serialize(PyObject* self, PyObject* args) {
    PyObject *ChunkArrayObject;
    Py_ssize_t block_use_bit;

    if (!PyArg_ParseTuple(args, "nO", &block_use_bit, &ChunkArrayObject)) return NULL;
    if (PyObject_Size(ChunkArrayObject) != 4096) { 
        PyErr_SetString(PyExc_TypeError, "ChunkArrayObject len must be 4096");
        return NULL;
    } else if (block_use_bit <= 0) {
        PyErr_SetString(PyExc_ValueError, "block_use_bit must be positive");
        return NULL;
    }

    unsigned int block_count_in_4_bytes = 32 / block_use_bit;
    unsigned int chunk_data_len = ceil( 4096.0 / block_count_in_4_bytes );
    struct ArrayAttr ChunkArrayAttr = GetArrayAttr(ChunkArrayObject);
    unsigned int *chunk_data_array = calloc(chunk_data_len, sizeof(unsigned int));
    if (!chunk_data_array) return PyErr_NoMemory();

    unsigned int block_index_data = 0;
    for (unsigned int i = 0; i < 4096; i++) {
        unsigned int index = i / block_count_in_4_bytes;
        unsigned int left_move = block_use_bit * (i%block_count_in_4_bytes);
        block_index_data |= GetArrayValue(&ChunkArrayAttr, i) << left_move;
        if ((i%block_count_in_4_bytes)==(block_count_in_4_bytes-1) || i==4095) {
            chunk_data_array[index] = block_index_data;
            block_index_data = 0;
        }
    }

    PyObject *output = PyBytes_FromStringAndSize((char*)chunk_data_array, chunk_data_len*sizeof(unsigned int));
    free(chunk_data_array);
    return output;
}

static PyObject* CommonStructure_to_chunk(PyObject* self, PyObject* args) {
    Py_ssize_t StartX, StartY, StartZ, SizeX, SizeY, SizeZ;
    Py_ssize_t ChunkStartX, ChunkStartY, ChunkStartZ, ChunkEndX, ChunkEndY, ChunkEndZ;
    PyObject *SubChunkDict, *CommonStructureArray, *CommonBlockPalette, *CommonBlockToChunkArray;

    if (!PyArg_ParseTuple(args, "nnnnnnnnnnnnOOOO", &StartX, &StartY, &StartZ, &SizeX, &SizeY, &SizeZ,
        &ChunkStartX, &ChunkStartY, &ChunkStartZ, &ChunkEndX, &ChunkEndY, &ChunkEndZ,
        &SubChunkDict, &CommonStructureArray, &CommonBlockPalette, &CommonBlockToChunkArray)) return NULL;
    //printf("%lld %lld %lld %lld %lld %lld %lld %lld %lld %lld %lld %lld\n", StartX, StartY, StartZ, SizeX, SizeY, SizeZ,
        //ChunkStartX, ChunkStartY, ChunkStartZ, ChunkEndX, ChunkEndY, ChunkEndZ);

    Py_ssize_t Y_Layer_Last = -1000;
    PyObject *SubChunk = NULL;
    PyObject *ChunkBlockPalette = NULL;
    struct ArrayAttr ChunkBlockArrayAttr = {0, NULL, 0, 'b'};
    struct ArrayAttr CommonBlockArrayAttr = GetArrayAttr(CommonStructureArray);
    struct ArrayAttr CommonBlockToChunkArrayAttr = GetArrayAttr(CommonBlockToChunkArray);
    
    for (Py_ssize_t y=ChunkStartY; y<ChunkEndY; y++) {
        Py_ssize_t TestNum1 = number_div(y, 16);
        if (Y_Layer_Last != TestNum1) {
            memset(CommonBlockToChunkArrayAttr.pointer, 0, CommonBlockToChunkArrayAttr.type_length*CommonBlockToChunkArrayAttr.length);
            SubChunk = PyDict_GetItem(SubChunkDict, PyIntArray[TestNum1+128]);
            PyObject *ChunkBlockIndex = PyObject_GetAttrString(SubChunk, "BlockIndex");
            ChunkBlockPalette = PyObject_GetAttrString(SubChunk, "BlockPalette");
            ChunkBlockArrayAttr = GetArrayAttr( ChunkBlockIndex );
            Py_DECREF(ChunkBlockIndex);
        }

        Py_ssize_t common_y = y - StartY;
        Py_ssize_t local_y = number_mod(y, 16);
        for (Py_ssize_t x=ChunkStartX; x<ChunkEndX; x++) {
            Py_ssize_t common_x = x - StartX;
            Py_ssize_t local_x =  number_mod(x, 16);
            for (Py_ssize_t z=ChunkStartZ; z<ChunkEndZ; z++) {
                Py_ssize_t common_z = z - StartZ;
                Py_ssize_t local_z = number_mod(z, 16);
                
                long long CommonPointer = common_x * (SizeY * SizeZ) + common_y * SizeZ + common_z;
                long long ChunkPointer = local_x * 256 + local_z * 16 + local_y;
                long long CommonIndex = GetArrayValue(&CommonBlockArrayAttr, CommonPointer);

                long long CommonToChunkBlock_IndexData = GetArrayValue(&CommonBlockToChunkArrayAttr, CommonIndex);
                if (!CommonToChunkBlock_IndexData) {
                    PyObject *CommonBlockObj = PyList_GetItem(CommonBlockPalette, CommonIndex);
                    Py_ssize_t Index = PySequence_Index(ChunkBlockPalette, CommonBlockObj);

                    if (Index == -1) {
                        PyErr_Clear();
                        PyList_Append(ChunkBlockPalette, CommonBlockObj);
                        Index = PyList_Size(ChunkBlockPalette);
                    } else { Index += 1; }

                    SetArrayValue(&CommonBlockToChunkArrayAttr, CommonIndex, Index);
                    CommonToChunkBlock_IndexData = Index;
                } 

                //printf("(%lld %lld %lld) (%lld %lld %lld) (%lld %lld %lld) (%lld %lld %lld) \n", 
                    //x, y, z, common_x, common_y, common_z, local_x, local_y, local_z,
                    //CommonPointer, ChunkPointer, CommonToChunkBlock_IndexData);
                SetArrayValue(&ChunkBlockArrayAttr, ChunkPointer, CommonToChunkBlock_IndexData-1);
            }
        }

        if (Y_Layer_Last != TestNum1) {
            Py_DECREF(ChunkBlockPalette);
            Y_Layer_Last = TestNum1;
        }
    }

    Py_RETURN_NONE;
}

static PyObject* chunk_to_CommonStructure(PyObject* self, PyObject* args) {
    Py_ssize_t StartX, StartY, StartZ, SizeX, SizeY, SizeZ;
    Py_ssize_t ChunkStartX, ChunkStartY, ChunkStartZ, ChunkEndX, ChunkEndY, ChunkEndZ;
    PyObject *SubChunkDict, *CommonStructureArray, *CommonStructureBlockLogDict, 
    *CommonStructureBlockPalette, *ChunkBlockToCommonArray, *ChunkBlockLogToCommonArray;

    if (!PyArg_ParseTuple(args, "nnnnnnnnnnnnOOOOOO", &StartX, &StartY, &StartZ, &SizeX, &SizeY, &SizeZ,
        &ChunkStartX, &ChunkStartY, &ChunkStartZ, &ChunkEndX, &ChunkEndY, &ChunkEndZ,
        &SubChunkDict, &CommonStructureArray, &CommonStructureBlockLogDict, 
        &CommonStructureBlockPalette, &ChunkBlockToCommonArray, &ChunkBlockLogToCommonArray)) return NULL;

    Py_ssize_t Y_Layer_Last = -1000;
    PyObject *SubChunk = NULL;
    PyObject *ChunkBlockPalette = NULL;
    PyObject *ChunkBlockLogPalette = NULL;
    struct ArrayAttr ChunkBlockArrayAttr = {0, NULL, 0, 'b'};
    struct ArrayAttr ChunkBlockLogArrayAttr = {0, NULL, 0, 'b'};
    struct ArrayAttr CommonBlockArrayAttr = GetArrayAttr(CommonStructureArray);
    struct ArrayAttr ChunkBlockToCommonArrayAttr = GetArrayAttr(ChunkBlockToCommonArray);
    struct ArrayAttr ChunkBlockLogToCommonArrayAttr = GetArrayAttr(ChunkBlockLogToCommonArray);

    for (Py_ssize_t y=ChunkStartY; y<ChunkEndY; y++) {

        Py_ssize_t TestNum1 = number_div(y, 16);
        if (Y_Layer_Last != TestNum1) {
            SubChunk = PyDict_GetItem(SubChunkDict, PyIntArray[TestNum1+128]);
            if (SubChunk == NULL) { continue; }
            PyObject *ChunkBlockIndex = PyObject_GetAttrString(SubChunk, "BlockIndex");
            PyObject *ChunkBlockLogIndex = PyObject_GetAttrString(SubChunk, "ContainBlockIndex");
            ChunkBlockPalette = PyObject_GetAttrString(SubChunk, "BlockPalette");
            ChunkBlockLogPalette = PyObject_GetAttrString(SubChunk, "ContainBlockPalette");
            ChunkBlockArrayAttr = GetArrayAttr(ChunkBlockIndex);
            ChunkBlockLogArrayAttr = GetArrayAttr(ChunkBlockLogIndex);
            memset(ChunkBlockToCommonArrayAttr.pointer, 0, ChunkBlockToCommonArrayAttr.type_length*ChunkBlockToCommonArrayAttr.length);
            memset(ChunkBlockLogToCommonArrayAttr.pointer, 0, ChunkBlockLogToCommonArrayAttr.type_length*ChunkBlockLogToCommonArrayAttr.length);
            Py_DECREF(ChunkBlockIndex);
            Py_DECREF(ChunkBlockLogIndex);
        }

        Py_ssize_t common_y = y - StartY;
        Py_ssize_t local_y = number_mod(y, 16);
        for (Py_ssize_t x=ChunkStartX; x<ChunkEndX; x++) {
            Py_ssize_t common_x = x - StartX;
            Py_ssize_t local_x =  number_mod(x, 16);
            for (Py_ssize_t z=ChunkStartZ; z<ChunkEndZ; z++) {
                Py_ssize_t common_z = z - StartZ;
                Py_ssize_t local_z = number_mod(z, 16);

                long long CommonPointer = common_x * (SizeY * SizeZ) + common_y * SizeZ + common_z;
                long long ChunkPointer = local_x * 256 + local_z * 16 + local_y;
                long long ChunkBlockIndex = GetArrayValue(&ChunkBlockArrayAttr, ChunkPointer);
                long long ChunkBlockLogIndex = GetArrayValue(&ChunkBlockLogArrayAttr, ChunkPointer);

                //printf("(%lld %lld %lld) (%lld %lld %lld) (%lld %lld %lld) \n", 
                    //common_x, common_y, common_z, local_x, local_y, local_z,
                    //CommonPointer, ChunkPointer, ChunkBlockIndex);

                long long ChunkToCommonBlock_IndexData = GetArrayValue(&ChunkBlockToCommonArrayAttr, ChunkBlockIndex);
                if (!ChunkToCommonBlock_IndexData) {
                    PyObject *CommonBlockObj = PyList_GetItem(ChunkBlockPalette, ChunkBlockIndex);
                    Py_ssize_t Index = PySequence_Index(CommonStructureBlockPalette, CommonBlockObj);

                    if (Index == -1) {
                        PyErr_Clear();
                        PyList_Append(CommonStructureBlockPalette, CommonBlockObj);
                        Index = PyList_Size(CommonStructureBlockPalette);
                    } else { Index += 1; }
                    
                    SetArrayValue(&ChunkBlockToCommonArrayAttr, ChunkBlockIndex, Index);
                    ChunkToCommonBlock_IndexData = Index;
                }
                SetArrayValue(&CommonBlockArrayAttr, CommonPointer, ChunkToCommonBlock_IndexData-1);

                long long ChunkToCommonBlockLog_IndexData = GetArrayValue(&ChunkBlockLogToCommonArrayAttr, ChunkBlockLogIndex);
                if (!ChunkToCommonBlockLog_IndexData) {
                    PyObject *CommonBlockObj = PyList_GetItem(ChunkBlockLogPalette, ChunkBlockLogIndex);
                    PyObject *CommonBlockIdentifier = PyObject_GetAttrString(CommonBlockObj, "Identifier");
                    Py_ssize_t Index = PySequence_Index(CommonStructureBlockPalette, CommonBlockObj);
                    
                    if (!PyUnicode_CompareWithASCIIString(CommonBlockIdentifier, "minecraft:air")) {
                        SetArrayValue(&ChunkBlockLogToCommonArrayAttr, ChunkBlockLogIndex, 65535);
                        ChunkToCommonBlockLog_IndexData = 65535;
                    } else if (Index == -1) {
                        PyErr_Clear();
                        PyList_Append(CommonStructureBlockPalette, CommonBlockObj);
                        Index = PyList_Size(CommonStructureBlockPalette);
                        SetArrayValue(&ChunkBlockLogToCommonArrayAttr, ChunkBlockLogIndex, Index);
                        ChunkToCommonBlockLog_IndexData = Index;
                    } else {
                        SetArrayValue(&ChunkBlockLogToCommonArrayAttr, ChunkBlockLogIndex, Index+1);
                        ChunkToCommonBlockLog_IndexData = Index+1;
                    }

                    Py_DECREF(CommonBlockIdentifier);
                }
                if (ChunkToCommonBlockLog_IndexData != 65535) {
                    PyObject *Index1IntObject = PyLong_FromSsize_t(CommonPointer);
                    PyObject *Index2IntObject = PyLong_FromSsize_t(ChunkToCommonBlockLog_IndexData-1);
                    PyDict_SetItem(CommonStructureBlockLogDict, Index1IntObject, Index2IntObject);
                    Py_DECREF(Index1IntObject);
                    Py_DECREF(Index2IntObject);
                }
            }
        }

        if (Y_Layer_Last != TestNum1) {
            Py_DECREF(ChunkBlockPalette);
            Py_DECREF(ChunkBlockLogPalette);
            Y_Layer_Last = TestNum1;
        }
    }

    Py_RETURN_NONE;
}


static PyMethodDef Methods[] = {
    {"cycle_xor", cycle_xor, METH_VARARGS, "C API cycle xor operation"},
    {"chunk_upgrade", chunk_upgrade, METH_VARARGS, "C API fast upgrade chunk data"},
    {"chunk_parser", chunk_parser, METH_VARARGS, "C API fast parser chunk data"},
    {"chunk_serialize", chunk_serialize, METH_VARARGS, "C API fast serialize chunk data"},
    {"is_chunk_key", is_chunk_key, METH_VARARGS, "C API fast test chunk key bytes"},
    {"StructureOperatePosRange", StructureOperatePosRange_Iteration, METH_VARARGS, "C API MC structure pos operate iter in mcworld"},
    {"CommonStructure_to_chunk", CommonStructure_to_chunk, METH_VARARGS, "C API MCstructure to mcworld Chunk"},
    {"chunk_to_CommonStructure", chunk_to_CommonStructure, METH_VARARGS, "C API MCstructure to mcworld Chunk"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef module = {
    PyModuleDef_HEAD_INIT,
    "MCBEWorld_C_API",
    NULL,
    -1,
    Methods
};

PyMODINIT_FUNC PyInit_MCBEWorld_C_API(void) {
    PyIntArray = (PyObject**)PyMem_Malloc(sizeof(PyObject*)*256);
    for (long i = -128; i < 128; i++) PyIntArray[i+128] = PyLong_FromLong(i);
    
    return PyModule_Create(&module);
}

