from setuptools import setup, Extension

setup(
    name="MCBEStructure_C_API",
    ext_modules=[
        Extension(
            "MCBEStructure_C_API", 
            sources=["fast_api_cache.c"],
            define_macros=[("Py_LIMITED_API", "0x03080000")],
            py_limited_api=True
        )
    ]
)

