#define Py_LIMITED_API 0x03080000
#define PY_SSIZE_T_CLEAN
#include <math.h>
#include <Python.h>




struct ArrayAttr {
    Py_ssize_t length;
    unsigned char *pointer;
    Py_UCS4 typecode;
    unsigned char type_length;
};

static struct ArrayAttr GetArrayAttr(PyObject* ArrayObject) {
    struct ArrayAttr Attr = {0, NULL, 0, 'b'};
    
    PyObject *buffer_info = PyObject_CallMethod(ArrayObject, "buffer_info", NULL);
    Attr.pointer = (char*)PyLong_AsLongLong( PyTuple_GetItem(buffer_info, 0) );
    Attr.length = PyLong_AsSsize_t( PyTuple_GetItem(buffer_info, 1) );
    Py_UCS4 typecode = PyUnicode_ReadChar( PyObject_GetAttrString(ArrayObject, "typecode"), 0);
    Attr.typecode = typecode;

    if (typecode == 'b' || typecode == 'B') Attr.type_length = 1;
    else if (typecode == 'h' || typecode == 'H') Attr.type_length = 2;
    else if (typecode == 'l' || typecode == 'L') Attr.type_length = 4;
    else if (typecode == 'q' || typecode == 'Q') Attr.type_length = 8;

    Py_DECREF(buffer_info);
    return Attr;
}

static long long GetArrayValue(struct ArrayAttr *Attr, long long Index) {
    long long NowPointer = Attr->type_length * Index;
    switch (Attr->typecode) {
        case 'b': return *(int8_t *)(Attr->pointer + NowPointer);
        case 'B': return *(uint8_t *)(Attr->pointer + NowPointer);
        case 'h': return *(int16_t *)(Attr->pointer + NowPointer);
        case 'H': return *(uint16_t *)(Attr->pointer + NowPointer);
        case 'l': return *(int32_t *)(Attr->pointer + NowPointer);
        case 'L': return *(uint32_t *)(Attr->pointer + NowPointer);
        case 'q': return *(int64_t *)(Attr->pointer + NowPointer);
        case 'Q': return *(uint64_t *)(Attr->pointer + NowPointer);
        default : return 0;
    }
}

static void SetArrayValue(struct ArrayAttr *Attr, long long Index, long long Value) {
    long long NowPointer = Attr->type_length * Index;
    switch (Attr->typecode) {
        case 'b': {*(int8_t *)(Attr->pointer + NowPointer) = Value; break;}
        case 'B': {*(uint8_t *)(Attr->pointer + NowPointer) = Value; break;}
        case 'h': {*(int16_t *)(Attr->pointer + NowPointer) = Value; break;}
        case 'H': {*(uint16_t *)(Attr->pointer + NowPointer) = Value; break;}
        case 'l': {*(int32_t *)(Attr->pointer + NowPointer) = Value; break;}
        case 'L': {*(uint32_t *)(Attr->pointer + NowPointer) = Value; break;}
        case 'q': {*(int64_t *)(Attr->pointer + NowPointer) = Value; break;}
        case 'Q': {*(uint64_t *)(Attr->pointer + NowPointer) = Value; break;}
    }
}

static PyObject* codecs_parser_schematic(PyObject* self, PyObject* args) {
    PyObject *blockArrayObject, *blockDataArrayObject;
    PyObject *blockIndexObject, *blockPaletteObject;
    PyObject *VolumeObject;

    if (!PyArg_ParseTuple(args, "OOOOO", &blockArrayObject, &blockDataArrayObject,
        &blockIndexObject, &blockPaletteObject, &VolumeObject)) return NULL;

    struct ArrayAttr blockArrayAttr = GetArrayAttr(blockArrayObject);
    struct ArrayAttr blockDataArrayAttr = GetArrayAttr(blockDataArrayObject);
    struct ArrayAttr blockIndexArrayAttr = GetArrayAttr(blockIndexObject);
    struct ArrayAttr blockPaletteArrayAttr = GetArrayAttr(blockPaletteObject);
    long long LengthX = PyLong_AsLongLong( PyObject_GetItem(VolumeObject, PyLong_FromLong(0)) );
    long long LengthY = PyLong_AsLongLong( PyObject_GetItem(VolumeObject, PyLong_FromLong(1)) );
    long long LengthZ = PyLong_AsLongLong( PyObject_GetItem(VolumeObject, PyLong_FromLong(2)) );
    
    if (blockArrayAttr.length != blockDataArrayAttr.length) {
        PyErr_SetString(PyExc_Exception, "Blocks length not equal BlockData length.");
        return NULL;
    }

    long long blockArrayIndex = 0;
    short block_index_count = 1;
    for (long long y = 0; y < LengthY; y++) {
        for (long long z = 0; z < LengthZ; z++) {
            for (long long x = 0; x < LengthX; x++) {
                unsigned char Block = GetArrayValue(&blockArrayAttr, blockArrayIndex);
                unsigned char BlockData = GetArrayValue(&blockDataArrayAttr, blockArrayIndex);
                blockArrayIndex++;
                if (Block == 0) continue;

                long long index = (Block << 8) | BlockData;
                long long Palette = GetArrayValue(&blockPaletteArrayAttr, index);
                if (Palette == 0) {
                    SetArrayValue(&blockPaletteArrayAttr, index, block_index_count);
                    block_index_count++;
                }
                long long block_index_array_pointer = x * (LengthY * LengthZ) + y * LengthZ + z;
                SetArrayValue(&blockIndexArrayAttr, block_index_array_pointer, Palette);

            }
        }
    }
    Py_RETURN_NONE;
}

static PyObject* codecs_parser_schem(PyObject* self, PyObject* args) {
    PyObject *blockArrayObject, *blockIndexObject, *NBTblockBitObject;
    PyObject *VolumeObject;

    if (!PyArg_ParseTuple(args, "OOOO", &blockArrayObject, &blockIndexObject, 
        &NBTblockBitObject, &VolumeObject)) return NULL;

    struct ArrayAttr blockArrayAttr = GetArrayAttr(blockArrayObject);
    struct ArrayAttr blockIndexArrayAttr = GetArrayAttr(blockIndexObject);
    struct ArrayAttr NBTblockBitArrayAttr = GetArrayAttr(NBTblockBitObject);
    long long LengthX = PyLong_AsLongLong( PyObject_GetItem(VolumeObject, PyLong_FromLong(0)) );
    long long LengthY = PyLong_AsLongLong( PyObject_GetItem(VolumeObject, PyLong_FromLong(1)) );
    long long LengthZ = PyLong_AsLongLong( PyObject_GetItem(VolumeObject, PyLong_FromLong(2)) );
    PyObject *NBTBlockMap = PyDict_New();
    if (!NBTBlockMap) return NULL;

    long long positionInInt = 0, blockIndex = 0, x = 0, y = 0, z = 0;
    for (long long i = 0; i < blockArrayAttr.length; i++) {
        unsigned char Block = GetArrayValue(&blockArrayAttr, i);
        blockIndex |= (0x7f & Block) << positionInInt;
        positionInInt += 7;
        
        if (Block > 127) continue;
        long long block_index_array_pointer = x * (LengthY * LengthZ) + y * LengthZ + z;
        SetArrayValue(&blockIndexArrayAttr, block_index_array_pointer, blockIndex);
        long long BlockType = GetArrayValue(&NBTblockBitArrayAttr, blockIndex);
        if (BlockType > 0) {
            PyObject *key = PyLong_FromLongLong(block_index_array_pointer);
            PyObject *value = PyLong_FromLongLong(BlockType);
            PyDict_SetItem(NBTBlockMap, key, value);
            Py_DECREF(key);
            Py_DECREF(value);
        }

        positionInInt = blockIndex = 0; 
        x++;
        if (x >= LengthX) {x = 0; z++;}
        if (z >= LengthZ) {z = 0; y++;}
    }
    return NBTBlockMap;
}




static PyMethodDef Methods[] = {
    {"codecs_parser_schematic", codecs_parser_schematic, METH_VARARGS, "speed parser schematic file C API"},
    {"codecs_parser_schem", codecs_parser_schem, METH_VARARGS, "speed parser schem file C API"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef module = {
    PyModuleDef_HEAD_INIT,
    "MCBEStructure_C_API",
    NULL,
    -1,
    Methods
};

PyMODINIT_FUNC PyInit_MCBEStructure_C_API(void) {
    return PyModule_Create(&module);
}