#define Py_LIMITED_API 0x03080000
#define PY_SSIZE_T_CLEAN
#include <math.h>
#include <Python.h>


struct ArrayAttr {
    Py_ssize_t length;
    unsigned char *pointer;
    Py_UCS4 typecode;
    unsigned char type_length;
};

static struct ArrayAttr GetArrayAttr(PyObject* ArrayObject) {
    struct ArrayAttr Attr = {0, NULL, 0, 'b'};
    
    PyObject *buffer_info = PyObject_CallMethod(ArrayObject, "buffer_info", NULL);
    PyObject *typecode_obj = PyObject_GetAttrString(ArrayObject, "typecode");
    PyObject *itemsize_obj = PyObject_GetAttrString(ArrayObject, "itemsize");

    Attr.pointer = (unsigned char*)PyLong_AsVoidPtr( PyTuple_GetItem(buffer_info, 0) );
    Attr.length = PyLong_AsSsize_t( PyTuple_GetItem(buffer_info, 1) );
    Attr.typecode = PyUnicode_ReadChar(typecode_obj, 0);
    Attr.type_length = (unsigned char)PyLong_AsLong(itemsize_obj);

    Py_DECREF(buffer_info);
    Py_DECREF(typecode_obj);
    Py_DECREF(itemsize_obj);
    return Attr;
}

static long long GetArrayValue(struct ArrayAttr *Attr, long long Index) {
    long long NowPointer = Attr->type_length * Index;
    switch (Attr->typecode) {
        case 'b': return *(signed char *)(Attr->pointer + NowPointer);
        case 'B': return *(unsigned char *)(Attr->pointer + NowPointer);
        case 'h': return *(signed short *)(Attr->pointer + NowPointer);
        case 'H': return *(unsigned short *)(Attr->pointer + NowPointer);
        case 'i': return *(signed int *)(Attr->pointer + NowPointer);
        case 'I': return *(unsigned int *)(Attr->pointer + NowPointer);
        case 'l': return *(signed long *)(Attr->pointer + NowPointer);
        case 'L': return *(unsigned long *)(Attr->pointer + NowPointer);
        case 'q': return *(signed long long *)(Attr->pointer + NowPointer);
        case 'Q': return *(unsigned long long *)(Attr->pointer + NowPointer);
        default : return 0;
    }
}

static void SetArrayValue(struct ArrayAttr *Attr, long long Index, long long Value) {
    long long NowPointer = Attr->type_length * Index;
    switch (Attr->typecode) {
        case 'b': {*(signed char *)(Attr->pointer + NowPointer) = Value; break;}
        case 'B': {*(unsigned char *)(Attr->pointer + NowPointer) = Value; break;}
        case 'h': {*(signed short *)(Attr->pointer + NowPointer) = Value; break;}
        case 'H': {*(unsigned short *)(Attr->pointer + NowPointer) = Value; break;}
        case 'i': {*(signed int *)(Attr->pointer + NowPointer) = Value; break;}
        case 'I': {*(unsigned int *)(Attr->pointer + NowPointer) = Value; break;}
        case 'l': {*(signed long *)(Attr->pointer + NowPointer) = Value; break;}
        case 'L': {*(unsigned long *)(Attr->pointer + NowPointer) = Value; break;}
        case 'q': {*(signed long long *)(Attr->pointer + NowPointer) = Value; break;}
        case 'Q': {*(unsigned long long *)(Attr->pointer + NowPointer) = Value; break;}
    }
}

static void PrintArrayAttr(struct ArrayAttr *Attr) {
    printf("length -> %d \n", Attr->length);
    printf("pointer -> %p \n", Attr->pointer);
    printf("typecode -> %c \n", Attr->typecode);
    printf("type_length -> %d \n", Attr->type_length);
}



static PyObject* split_commonstructure(PyObject *self, PyObject *args) {
    PyObject *InputBlockIndexArray, *OutputBlockIndexArray, *Size, *StartPos, *EndPos;

    if (!PyArg_ParseTuple(args, "OOOOO", &InputBlockIndexArray, &OutputBlockIndexArray,
        &Size, &StartPos, &EndPos)) return NULL;

    PyObject *IntObject_0 = PyLong_FromLong(0);
    PyObject *IntObject_1 = PyLong_FromLong(1);
    PyObject *IntObject_2 = PyLong_FromLong(2);
    PyObject *PosInt1 = PyObject_GetItem(Size, IntObject_0);
    PyObject *PosInt2 = PyObject_GetItem(Size, IntObject_1);
    PyObject *PosInt3 = PyObject_GetItem(Size, IntObject_2);
    PyObject *PosInt4 = PyObject_GetItem(StartPos, IntObject_0);
    PyObject *PosInt5 = PyObject_GetItem(StartPos, IntObject_1);
    PyObject *PosInt6 = PyObject_GetItem(StartPos, IntObject_2);
    PyObject *PosInt7 = PyObject_GetItem(EndPos, IntObject_0);
    PyObject *PosInt8 = PyObject_GetItem(EndPos, IntObject_1);
    PyObject *PosInt9 = PyObject_GetItem(EndPos, IntObject_2);
    long long SizeX = PyLong_AsLongLong( PosInt1 );
    long long SizeY = PyLong_AsLongLong( PosInt2 );
    long long SizeZ = PyLong_AsLongLong( PosInt3 );
    long long StartX = PyLong_AsLongLong( PosInt4 );
    long long StartY = PyLong_AsLongLong( PosInt5 );
    long long StartZ = PyLong_AsLongLong( PosInt6 );
    long long EndX = PyLong_AsLongLong( PosInt7 );
    long long EndY = PyLong_AsLongLong( PosInt8 );
    long long EndZ = PyLong_AsLongLong( PosInt9 );
    Py_DECREF(IntObject_0);
    Py_DECREF(IntObject_1);
    Py_DECREF(IntObject_2);
    Py_DECREF(PosInt1);
    Py_DECREF(PosInt2);
    Py_DECREF(PosInt3);
    Py_DECREF(PosInt4);
    Py_DECREF(PosInt5);
    Py_DECREF(PosInt6);
    Py_DECREF(PosInt7);
    Py_DECREF(PosInt8);
    Py_DECREF(PosInt9);

    long long LoopX = EndX - StartX + 1, LoopY = EndY - StartY + 1, LoopZ = EndZ - StartZ + 1;
    struct ArrayAttr InputArrayAttr = GetArrayAttr(InputBlockIndexArray);
    struct ArrayAttr OutputArrayAttr = GetArrayAttr(OutputBlockIndexArray);
    //PrintArrayAttr(&InputArrayAttr);

    if (EndX >= SizeX || EndY >= SizeY || EndZ >= SizeZ) {
        PyErr_SetString(PyExc_Exception, "End Pos cant out of range.");
        return NULL;
    } else if (EndX < StartX || EndY < StartY || EndZ < StartZ) {
        PyErr_SetString(PyExc_Exception, "End Pos cant lower than Start Pos.");
        return NULL;
    } else if (StartX < 0 || StartY < 0 || StartZ < 0) {
        PyErr_SetString(PyExc_Exception, "Start Pos cant out of range.");
        return NULL;
    }

    for (Py_ssize_t x=StartX; x<=EndX; x++) {
        for (Py_ssize_t y=StartY; y<=EndY; y++) {
            for (Py_ssize_t z=StartZ; z<=EndZ; z++) {
                long long index_pointer_1 = x * (SizeY * SizeZ) + y * SizeZ + z;
                long long index_pointer_2 = (x - StartX) * (LoopY * LoopZ) + (y - StartY) * LoopZ + (z - StartZ);
                long long value1 = GetArrayValue(&InputArrayAttr, index_pointer_1);
                //printf("%d %d %d \n", index_pointer_1, index_pointer_2, value1);
                SetArrayValue(&OutputArrayAttr, index_pointer_2, value1);
            }
        }
    }

    Py_RETURN_NONE;
}

static PyObject* codecs_parser_schematic(PyObject *self, PyObject *args) {
    PyObject *blockArrayObject, *blockDataArrayObject;
    PyObject *blockIndexObject, *blockPaletteObject;
    PyObject *blockTypeObject, *VolumeObject;

    if (!PyArg_ParseTuple(args, "OOOOOO", &blockArrayObject, &blockDataArrayObject,
        &blockIndexObject, &blockPaletteObject, &blockTypeObject, &VolumeObject)) return NULL;

    PyObject *IntObject_0 = PyLong_FromLong(0);
    PyObject *IntObject_1 = PyLong_FromLong(1);
    PyObject *IntObject_2 = PyLong_FromLong(2);
    PyObject *PosInt1 = PyObject_GetItem(VolumeObject, IntObject_0);
    PyObject *PosInt2 = PyObject_GetItem(VolumeObject, IntObject_1);
    PyObject *PosInt3 = PyObject_GetItem(VolumeObject, IntObject_2);
    long long LengthX = PyLong_AsLongLong( PosInt1 );
    long long LengthY = PyLong_AsLongLong( PosInt2 );
    long long LengthZ = PyLong_AsLongLong( PosInt3 );
    Py_DECREF(IntObject_0);
    Py_DECREF(IntObject_1);
    Py_DECREF(IntObject_2);
    Py_DECREF(PosInt1);
    Py_DECREF(PosInt2);
    Py_DECREF(PosInt3);

    struct ArrayAttr blockArrayAttr = GetArrayAttr(blockArrayObject);
    struct ArrayAttr blockDataArrayAttr = GetArrayAttr(blockDataArrayObject);
    struct ArrayAttr blockIndexArrayAttr = GetArrayAttr(blockIndexObject);
    struct ArrayAttr blockPaletteArrayAttr = GetArrayAttr(blockPaletteObject);
    struct ArrayAttr blockTypeArrayAttr = GetArrayAttr(blockTypeObject);
    PyObject *NBTBlockMap = PyDict_New();
    if (!NBTBlockMap) return NULL;
    
    if (blockArrayAttr.length != blockDataArrayAttr.length) {
        PyErr_SetString(PyExc_Exception, "Blocks length not equal BlockData length.");
        return NULL;
    }

    long long blockArrayIndex = 0;
    short block_index_count = 1;
    for (long long y = 0; y < LengthY; y++) {
        for (long long z = 0; z < LengthZ; z++) {
            for (long long x = 0; x < LengthX; x++) {
                unsigned char Block = GetArrayValue(&blockArrayAttr, blockArrayIndex);
                unsigned char BlockData = GetArrayValue(&blockDataArrayAttr, blockArrayIndex);
                blockArrayIndex++;
                if (Block == 0) continue;

                long long index = (Block << 8) | BlockData;
                long long Palette = GetArrayValue(&blockPaletteArrayAttr, index);
                if (Palette == 0) {
                    SetArrayValue(&blockPaletteArrayAttr, index, block_index_count);
                    Palette = block_index_count;
                    block_index_count++;
                }
                long long block_index_array_pointer = x * (LengthY * LengthZ) + y * LengthZ + z;
                SetArrayValue(&blockIndexArrayAttr, block_index_array_pointer, Palette);

                long long BlockType = GetArrayValue(&blockTypeArrayAttr, Block);
                if (BlockType > 0) {
                    PyObject *key = PyLong_FromLongLong(block_index_array_pointer);
                    PyObject *value = PyLong_FromLongLong(BlockType);
                    PyDict_SetItem(NBTBlockMap, key, value);
                    Py_DECREF(key);
                    Py_DECREF(value);
                }
            }
        }
    }
    
    return NBTBlockMap;
}

static PyObject* codecs_parser_schem(PyObject *self, PyObject *args) {
    PyObject *blockArrayObject, *blockIndexObject, *NBTblockBitObject;
    PyObject *VolumeObject;

    if (!PyArg_ParseTuple(args, "OOOO", &blockArrayObject, &blockIndexObject, 
        &NBTblockBitObject, &VolumeObject)) return NULL;

    PyObject *IntObject_0 = PyLong_FromLong(0);
    PyObject *IntObject_1 = PyLong_FromLong(1);
    PyObject *IntObject_2 = PyLong_FromLong(2);
    PyObject *PosInt1 = PyObject_GetItem(VolumeObject, IntObject_0);
    PyObject *PosInt2 = PyObject_GetItem(VolumeObject, IntObject_1);
    PyObject *PosInt3 = PyObject_GetItem(VolumeObject, IntObject_2);
    long long LengthX = PyLong_AsLongLong( PosInt1 );
    long long LengthY = PyLong_AsLongLong( PosInt2 );
    long long LengthZ = PyLong_AsLongLong( PosInt3 );
    Py_DECREF(IntObject_0);
    Py_DECREF(IntObject_1);
    Py_DECREF(IntObject_2);
    Py_DECREF(PosInt1);
    Py_DECREF(PosInt2);
    Py_DECREF(PosInt3);

    struct ArrayAttr blockArrayAttr = GetArrayAttr(blockArrayObject);
    struct ArrayAttr blockIndexArrayAttr = GetArrayAttr(blockIndexObject);
    struct ArrayAttr NBTblockBitArrayAttr = GetArrayAttr(NBTblockBitObject);
    PyObject *NBTBlockMap = PyDict_New();
    if (!NBTBlockMap) return NULL;

    long long positionInInt = 0, blockIndex = 0, x = 0, y = 0, z = 0;
    for (long long i = 0; i < blockArrayAttr.length; i++) {
        unsigned char Block = GetArrayValue(&blockArrayAttr, i);
        blockIndex |= (0x7f & Block) << positionInInt;
        positionInInt += 7;

        if (Block > 127) continue;
        long long block_index_array_pointer = x * (LengthY * LengthZ) + y * LengthZ + z;
        SetArrayValue(&blockIndexArrayAttr, block_index_array_pointer, blockIndex);
        long long BlockType = GetArrayValue(&NBTblockBitArrayAttr, blockIndex);
        if (BlockType > 0) {
            PyObject *key = PyLong_FromLongLong(block_index_array_pointer);
            PyObject *value = PyLong_FromLongLong(BlockType);
            PyDict_SetItem(NBTBlockMap, key, value);
            Py_DECREF(key);
            Py_DECREF(value);
        }

        x++;
        if (x >= LengthX) {x = 0; z++;}
        if (z >= LengthZ) {z = 0; y++;}
        positionInInt = blockIndex = 0; 
    }
    return NBTBlockMap;
}

static PyObject* codecs_parser_litematic(PyObject *self, PyObject *args) {
    PyObject *blockMapArray, *blockNBTBitArray, *blockIndexArray, *CommonIndexArray;
    Py_ssize_t OriginX, OriginY, OriginZ;
    Py_ssize_t SizeX, SizeY, SizeZ;
    Py_ssize_t RegionOriginX, RegionOriginY, RegionOriginZ;
    Py_ssize_t RegionSizeX, RegionSizeY, RegionSizeZ;
    Py_ssize_t BitsPerBlock;

    if (!PyArg_ParseTuple(args, "OOOOnnnnnnnnnnnnn", 
        &blockMapArray, &blockNBTBitArray, &blockIndexArray, &CommonIndexArray, 
        &OriginX, &OriginY, &OriginZ, 
        &SizeX, &SizeY, &SizeZ, 
        &RegionOriginX, &RegionOriginY, &RegionOriginZ, 
        &RegionSizeX, &RegionSizeY, &RegionSizeZ,
        &BitsPerBlock)) return NULL;

    Py_ssize_t DeltaX = RegionOriginX - OriginX;
    Py_ssize_t DeltaY = RegionOriginY - OriginY;
    Py_ssize_t DeltaZ = RegionOriginZ - OriginZ;
    Py_ssize_t AndOperatInt = pow(2, BitsPerBlock) - 1;
    Py_ssize_t RegionVolume = RegionSizeX * RegionSizeY * RegionSizeZ;
    struct ArrayAttr blockMapAttr = GetArrayAttr(blockMapArray);
    struct ArrayAttr blockNBTBitAttr = GetArrayAttr(blockNBTBitArray);
    struct ArrayAttr blockIndexAttr = GetArrayAttr(blockIndexArray);
    struct ArrayAttr CommonIndexAttr = GetArrayAttr(CommonIndexArray);
    PyObject *NBTBlockMap = PyDict_New();
    if (!NBTBlockMap) return NULL;

    long long x = 0, y = 0, z = 0;
    for (long long i = 0; i < RegionVolume; i++) {
        long long start_offset = i * BitsPerBlock;
        long long start_arr_index = start_offset / 64; 
        long long end_arr_index = ((i + 1) * BitsPerBlock - 1) / 64;
        long long start_bit_offset = start_offset % 64;
        long long block_index = 0;
        unsigned long long BlockData1 = GetArrayValue(&blockIndexAttr, start_arr_index);
        unsigned long long BlockData2 = GetArrayValue(&blockIndexAttr, end_arr_index);

        if (start_arr_index == end_arr_index) 
            block_index = (BlockData1 >> start_bit_offset) & AndOperatInt ;
        else {
            long long end_offset = 64 - start_bit_offset;
            long long val = (BlockData1 >> start_bit_offset) | (BlockData2 << end_offset);
            block_index = val & AndOperatInt;
        }

        long long common_index = GetArrayValue(&blockMapAttr, block_index);
        long long block_index_array_pointer = (x + DeltaX) * (SizeY * SizeZ) + (y + DeltaY) * SizeZ + (z + DeltaZ);
        SetArrayValue(&CommonIndexAttr, block_index_array_pointer, common_index);
        long long BlockType = GetArrayValue(&blockNBTBitAttr, common_index);
        if (BlockType > 0) {
            PyObject *key = PyLong_FromLongLong(block_index_array_pointer);
            PyObject *value = PyLong_FromLongLong(BlockType);
            PyDict_SetItem(NBTBlockMap, key, value);
            Py_DECREF(key);
            Py_DECREF(value);
        }

        x++;
        if (x >= RegionSizeX) {x = 0; z++;}
        if (z >= RegionSizeZ) {z = 0; y++;}
        if (y >= RegionSizeY) {break;}
    }

    return NBTBlockMap;
}

static PyObject* handling_waterlog(PyObject *self, PyObject *args) {
    PyObject *BlockIndexArray, *WaterLogDict, *BlockPaletteList, *VolumeArray;
    if (!PyArg_ParseTuple(args, "OOOO", &BlockIndexArray, &WaterLogDict, &BlockPaletteList, &VolumeArray)) return NULL;
    
    Py_ssize_t PaletteLen = PyList_Size(BlockPaletteList);
    struct ArrayAttr SizeArrayAttr = GetArrayAttr(VolumeArray);
    struct ArrayAttr BlockIndexAttr = GetArrayAttr(BlockIndexArray);
    unsigned char *BlockWaterLogArray = calloc(PaletteLen, sizeof(unsigned char));
    long long SizeX = GetArrayValue(&SizeArrayAttr, 0);
    long long SizeY = GetArrayValue(&SizeArrayAttr, 1);
    long long SizeZ = GetArrayValue(&SizeArrayAttr, 2);
    long long return_code = 0;
    PyObject *WaterBlockIndexObject = NULL;

    for (Py_ssize_t i = 0; i < PaletteLen; i++) {
        PyObject *BlockObj = PyList_GetItem(BlockPaletteList, i);
        PyObject *BlockName = PyObject_GetAttrString(BlockObj, "name");
        PyObject *WaterlogBool = PyObject_GetAttrString(BlockObj, "waterlogged");
        if (WaterlogBool == Py_True) BlockWaterLogArray[i] = 1;
        else if (!PyUnicode_CompareWithASCIIString(BlockName, "minecraft:seagrass")) BlockWaterLogArray[i] = 1;
        else if (!PyUnicode_CompareWithASCIIString(BlockName, "minecraft:kelp")) BlockWaterLogArray[i] = 1;
        Py_DECREF(BlockName);
        Py_DECREF(WaterlogBool);
    }

    for (Py_ssize_t i = 0; i < PaletteLen; i++) {
        PyObject *BlockObj = PyList_GetItem(BlockPaletteList, i);
        PyObject *BlockID = PyObject_GetAttrString(BlockObj, "name");
        int result = PyUnicode_CompareWithASCIIString(BlockID, "minecraft:water");
        Py_DECREF(BlockID);
        if (result == 0) {WaterBlockIndexObject = PyLong_FromLong(i); break;}
    }
    if (WaterBlockIndexObject == NULL) {
        WaterBlockIndexObject = PyLong_FromLong(PaletteLen); 
        return_code = 1;
    }
    
    for (long long x = 0; x < SizeX; x++) {
        for (long long y = 0; y < SizeY; y++) {
            for (long long z = 0; z < SizeZ; z++) {
                long long index_pointer_1 = x * (SizeY * SizeZ) + y * SizeZ + z;
                long long value1 = GetArrayValue(&BlockIndexAttr, index_pointer_1);
                if (!BlockWaterLogArray[value1]) continue;
                PyObject *IntObj = PyLong_FromLongLong(index_pointer_1) ;
                PyDict_SetItem(WaterLogDict, IntObj, WaterBlockIndexObject);
                Py_DECREF(IntObj);
            }
        }
    }
    
    Py_DECREF(WaterBlockIndexObject);
    free(BlockWaterLogArray);
    if (return_code) Py_RETURN_TRUE;
    else Py_RETURN_FALSE;
}



static PyMethodDef Methods[] = {
    {"codecs_parser_schematic", codecs_parser_schematic, METH_VARARGS, "speed parser schematic file C API"},
    {"codecs_parser_schem", codecs_parser_schem, METH_VARARGS, "speed parser schem file C API"},
    {"codecs_parser_litematic", codecs_parser_litematic, METH_VARARGS, "speed parser schem litematic C API"},
    {"split_commonstructure", split_commonstructure, METH_VARARGS, "split CommonStructure fast C API"},
    {"handling_waterlog", handling_waterlog, METH_VARARGS, "handling waterlog C API"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef module = {
    PyModuleDef_HEAD_INIT,
    "MCBEStructure_C_API",
    NULL,
    -1,
    Methods
};

PyMODINIT_FUNC PyInit_MCBEStructure_C_API(void) {
    return PyModule_Create(&module);
}