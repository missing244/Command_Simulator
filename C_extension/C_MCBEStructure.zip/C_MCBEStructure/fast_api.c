#define Py_LIMITED_API 0x03080000
#define PY_SSIZE_T_CLEAN
#include <math.h>
#include <Python.h>
#include "C_module/array.h"



static PyObject* heightmap_commonstructure(PyObject *self, PyObject *args) {
    PyObject *InputBlockIndexArray, *Size, *AirData;
    long long MaxHeight;
    PyObject *OutputHeightArray, *OutputBlockIndexArray, *OutputShadowArray;

    if (!PyArg_ParseTuple(args, "OOOOOOL", &InputBlockIndexArray, &OutputHeightArray, 
        &OutputBlockIndexArray, &OutputShadowArray, &Size, &AirData, &MaxHeight)) return NULL;

    PyObject *IntObject_0 = PyLong_FromLong(0);
    PyObject *IntObject_1 = PyLong_FromLong(1);
    PyObject *IntObject_2 = PyLong_FromLong(2);
    PyObject *PosInt1 = PyObject_GetItem(Size, IntObject_0);
    PyObject *PosInt2 = PyObject_GetItem(Size, IntObject_1);
    PyObject *PosInt3 = PyObject_GetItem(Size, IntObject_2);
    Py_DECREF(IntObject_0);
    Py_DECREF(IntObject_1);
    Py_DECREF(IntObject_2);
    long long SizeX = PyLong_AsLongLong( PosInt1 );
    long long SizeY = PyLong_AsLongLong( PosInt2 );
    long long SizeZ = PyLong_AsLongLong( PosInt3 );
    MaxHeight = MaxHeight >= SizeY ? SizeY-1 : MaxHeight;
    MaxHeight = MaxHeight < 0 ? 0 : MaxHeight;

    double light_dir_x = -0.5773502691896258;
    double light_dir_y = 0.5773502691896258;
    double light_dir_z = -0.5773502691896258;
    double ambient_strength = 0.4;
    double diffuse_strength = 0.6;
    unsigned short *InputArray = (unsigned short *)GetArrayAttr(InputBlockIndexArray).pointer;
    unsigned short *AirArray = (unsigned short *)GetArrayAttr(AirData).pointer;
    unsigned short *HeightArray = (unsigned short *)GetArrayAttr(OutputHeightArray).pointer;
    unsigned short *IndexArray = (unsigned short *)GetArrayAttr(OutputBlockIndexArray).pointer;
    unsigned short *ShadowArray = (unsigned short *)GetArrayAttr(OutputShadowArray).pointer;

    for (long long x=0; x<SizeX; x++) {
        for (long long z=0; z<SizeZ; z++) {
            for (long long y=MaxHeight; y>=0; y--) {
                long long index_plane = x * SizeZ + z;
                long long index = x * SizeY * SizeZ + y * SizeZ + z;
                unsigned short input_block_index = InputArray[index];
                if (AirArray[input_block_index]) continue;

                HeightArray[index_plane] = (unsigned short)y;
                IndexArray[index_plane] = input_block_index;
                break;
            }
        }
    }

    for (long long x=0; x<SizeX; x++) {
        for (long long z=0; z<SizeZ; z++) {
            long long index = x * SizeZ + z;

            unsigned short h_center = HeightArray[index];
            unsigned short h_left = z > 0 ? HeightArray[index-1] : h_center;
            unsigned short h_right = z < SizeZ-1 ? HeightArray[index+1] : h_center;
            unsigned short h_up = x > 0 ? HeightArray[index-SizeZ] : h_center;
            unsigned short h_down = x < SizeX-1 ? HeightArray[index+SizeZ] : h_center;

            signed short dx = h_right - h_left;
            signed short dz = h_down - h_up;

            double d_vector = pow(dx*dx + 1.0 + dz*dz, 0.5);
            double diff = (dx*light_dir_x + 1*light_dir_y + dz*light_dir_z) / d_vector;
            double intensity = ambient_strength + diffuse_strength * (diff > 0 ? diff : 0);
            ShadowArray[index] = (unsigned short)(intensity*10000);
        }
    }

    Py_RETURN_NONE;
}

static PyObject* split_commonstructure(PyObject *self, PyObject *args) {
    PyObject *InputBlockIndexArray, *OutputBlockIndexArray, *Size, *StartPos, *EndPos;

    if (!PyArg_ParseTuple(args, "OOOOO", &InputBlockIndexArray, &OutputBlockIndexArray,
        &Size, &StartPos, &EndPos)) return NULL;

    PyObject *IntObject_0 = PyLong_FromLong(0);
    PyObject *IntObject_1 = PyLong_FromLong(1);
    PyObject *IntObject_2 = PyLong_FromLong(2);
    PyObject *PosInt1 = PyObject_GetItem(Size, IntObject_0);
    PyObject *PosInt2 = PyObject_GetItem(Size, IntObject_1);
    PyObject *PosInt3 = PyObject_GetItem(Size, IntObject_2);
    PyObject *PosInt4 = PyObject_GetItem(StartPos, IntObject_0);
    PyObject *PosInt5 = PyObject_GetItem(StartPos, IntObject_1);
    PyObject *PosInt6 = PyObject_GetItem(StartPos, IntObject_2);
    PyObject *PosInt7 = PyObject_GetItem(EndPos, IntObject_0);
    PyObject *PosInt8 = PyObject_GetItem(EndPos, IntObject_1);
    PyObject *PosInt9 = PyObject_GetItem(EndPos, IntObject_2);
    long long SizeX = PyLong_AsLongLong( PosInt1 );
    long long SizeY = PyLong_AsLongLong( PosInt2 );
    long long SizeZ = PyLong_AsLongLong( PosInt3 );
    long long StartX = PyLong_AsLongLong( PosInt4 );
    long long StartY = PyLong_AsLongLong( PosInt5 );
    long long StartZ = PyLong_AsLongLong( PosInt6 );
    long long EndX = PyLong_AsLongLong( PosInt7 );
    long long EndY = PyLong_AsLongLong( PosInt8 );
    long long EndZ = PyLong_AsLongLong( PosInt9 );
    Py_DECREF(IntObject_0);
    Py_DECREF(IntObject_1);
    Py_DECREF(IntObject_2);
    Py_DECREF(PosInt1);
    Py_DECREF(PosInt2);
    Py_DECREF(PosInt3);
    Py_DECREF(PosInt4);
    Py_DECREF(PosInt5);
    Py_DECREF(PosInt6);
    Py_DECREF(PosInt7);
    Py_DECREF(PosInt8);
    Py_DECREF(PosInt9);

    long long LoopX = EndX - StartX + 1, LoopY = EndY - StartY + 1, LoopZ = EndZ - StartZ + 1;
    unsigned short *InputArray = (unsigned short *)GetArrayAttr(InputBlockIndexArray).pointer;
    unsigned short *OutputArray = (unsigned short *)GetArrayAttr(OutputBlockIndexArray).pointer;
    //PrintArrayAttr(&InputArrayAttr);

    if (EndX >= SizeX || EndY >= SizeY || EndZ >= SizeZ) {
        PyErr_SetString(PyExc_Exception, "End Pos cant out of range.");
        return NULL;
    } else if (EndX < StartX || EndY < StartY || EndZ < StartZ) {
        PyErr_SetString(PyExc_Exception, "End Pos cant lower than Start Pos.");
        return NULL;
    } else if (StartX < 0 || StartY < 0 || StartZ < 0) {
        PyErr_SetString(PyExc_Exception, "Start Pos cant out of range.");
        return NULL;
    }

    for (Py_ssize_t x=StartX; x<=EndX; x++) {
        for (Py_ssize_t y=StartY; y<=EndY; y++) {
            for (Py_ssize_t z=StartZ; z<=EndZ; z++) {
                long long index_pointer_1 = x * (SizeY * SizeZ) + y * SizeZ + z;
                long long index_pointer_2 = (x - StartX) * (LoopY * LoopZ) + (y - StartY) * LoopZ + (z - StartZ);
                unsigned short value1 = InputArray[index_pointer_1];
                OutputArray[index_pointer_2] = value1;
                //printf("%d %d %d \n", index_pointer_1, index_pointer_2, value1);
            }
        }
    }

    Py_RETURN_NONE;
}

static PyObject* codecs_parser_schematic(PyObject *self, PyObject *args) {
    PyObject *blockArrayObject, *blockDataArrayObject;
    PyObject *blockIndexObject, *blockPaletteObject;
    PyObject *blockTypeObject, *VolumeObject;

    if (!PyArg_ParseTuple(args, "OOOOOO", &blockArrayObject, &blockDataArrayObject,
        &blockIndexObject, &blockPaletteObject, &blockTypeObject, &VolumeObject)) return NULL;

    PyObject *IntObject_0 = PyLong_FromLong(0);
    PyObject *IntObject_1 = PyLong_FromLong(1);
    PyObject *IntObject_2 = PyLong_FromLong(2);
    PyObject *PosInt1 = PyObject_GetItem(VolumeObject, IntObject_0);
    PyObject *PosInt2 = PyObject_GetItem(VolumeObject, IntObject_1);
    PyObject *PosInt3 = PyObject_GetItem(VolumeObject, IntObject_2);
    long long LengthX = PyLong_AsLongLong( PosInt1 );
    long long LengthY = PyLong_AsLongLong( PosInt2 );
    long long LengthZ = PyLong_AsLongLong( PosInt3 );
    Py_DECREF(IntObject_0);
    Py_DECREF(IntObject_1);
    Py_DECREF(IntObject_2);
    Py_DECREF(PosInt1);
    Py_DECREF(PosInt2);
    Py_DECREF(PosInt3);

    struct ArrayAttr blockArrayAttr = GetArrayAttr(blockArrayObject);
    struct ArrayAttr blockDataArrayAttr = GetArrayAttr(blockDataArrayObject);
    PyObject *NBTBlockMap = PyDict_New();
    if (!NBTBlockMap) return NULL;
    
    if (blockArrayAttr.length != blockDataArrayAttr.length) {
        PyErr_SetString(PyExc_Exception, "Blocks length not equal BlockData length.");
        return NULL;
    }

    unsigned char *blockArrayPointer = blockArrayAttr.pointer;
    unsigned char *blockDataArrayPointer = blockDataArrayAttr.pointer;
    unsigned short *blockIndexArray = (unsigned short *)GetArrayAttr(blockIndexObject).pointer;
    unsigned short *blockPaletteArray = (unsigned short *)GetArrayAttr(blockPaletteObject).pointer;
    unsigned short *blockTypeArray = (unsigned short *)GetArrayAttr(blockTypeObject).pointer;
    long long blockArrayIndex = 0;
    unsigned short block_index_count = 1;
    for (long long y = 0; y < LengthY; y++) {
        for (long long z = 0; z < LengthZ; z++) {
            for (long long x = 0; x < LengthX; x++) {
                unsigned char Block = blockArrayPointer[blockArrayIndex];
                unsigned char BlockData = blockDataArrayPointer[blockArrayIndex];
                blockArrayIndex++;
                if (Block == 0) continue;

                unsigned short index = (Block << 8) | BlockData;
                unsigned short Palette = blockPaletteArray[index];
                if (Palette == 0) {
                    blockPaletteArray[index] = block_index_count;
                    Palette = block_index_count;
                    block_index_count++;
                }
                long long block_index_array_pointer = x * (LengthY * LengthZ) + y * LengthZ + z;
                blockIndexArray[block_index_array_pointer] = Palette;

                unsigned short BlockType = blockTypeArray[Block];
                if (BlockType > 0) {
                    PyObject *key = PyLong_FromLongLong(block_index_array_pointer);
                    PyObject *value = PyLong_FromLongLong(BlockType);
                    PyDict_SetItem(NBTBlockMap, key, value);
                    Py_DECREF(key);
                    Py_DECREF(value);
                }
            }
        }
    }
    
    return NBTBlockMap;
}

static PyObject* codecs_parser_schem(PyObject *self, PyObject *args) {
    PyObject *blockArrayObject, *blockIndexObject, *NBTblockBitObject;
    PyObject *CotainDict, *WaterTagObject, *WaterIndex;
    PyObject *VolumeObject;

    if (!PyArg_ParseTuple(args, "OOOOOOO", &blockArrayObject, &blockIndexObject, 
        &NBTblockBitObject, &CotainDict, &WaterTagObject, &WaterIndex, &VolumeObject)) return NULL;

    PyObject *IntObject_0 = PyLong_FromLong(0);
    PyObject *IntObject_1 = PyLong_FromLong(1);
    PyObject *IntObject_2 = PyLong_FromLong(2);
    PyObject *PosInt1 = PyObject_GetItem(VolumeObject, IntObject_0);
    PyObject *PosInt2 = PyObject_GetItem(VolumeObject, IntObject_1);
    PyObject *PosInt3 = PyObject_GetItem(VolumeObject, IntObject_2);
    long long LengthX = PyLong_AsLongLong( PosInt1 );
    long long LengthY = PyLong_AsLongLong( PosInt2 );
    long long LengthZ = PyLong_AsLongLong( PosInt3 );
    Py_DECREF(IntObject_0);
    Py_DECREF(IntObject_1);
    Py_DECREF(IntObject_2);
    Py_DECREF(PosInt1);
    Py_DECREF(PosInt2);
    Py_DECREF(PosInt3);

    struct ArrayAttr blockArrayAttr = GetArrayAttr(blockArrayObject);
    unsigned char *blockArray = blockArrayAttr.pointer;
    unsigned short *blockIndexArray = (unsigned short *)GetArrayAttr(blockIndexObject).pointer;
    unsigned short *NBTblockBitArray = (unsigned short *)GetArrayAttr(NBTblockBitObject).pointer;
    unsigned short *WaterTag = (unsigned short *)GetArrayAttr(WaterTagObject).pointer;
    PyObject *NBTBlockMap = PyDict_New();
    if (!NBTBlockMap) return NULL;
    
    unsigned short positionInInt = 0, blockIndex = 0, x = 0, y = 0, z = 0;
    for (long long i = 0; i < blockArrayAttr.length; i++) {
        unsigned char Block = blockArray[i];
        blockIndex |= (0x7f & Block) << positionInInt;
        positionInInt += 7;

        if (Block > 127) continue;
        long long block_index_array_pointer = x * (LengthY * LengthZ) + y * LengthZ + z;
        blockIndexArray[block_index_array_pointer] = blockIndex;
        
        unsigned short BlockType = NBTblockBitArray[blockIndex];
        if (BlockType) {
            PyObject *key = PyLong_FromLongLong(block_index_array_pointer);
            PyObject *value = PyLong_FromLongLong(BlockType);
            PyDict_SetItem(NBTBlockMap, key, value);
            Py_DECREF(key);
            Py_DECREF(value);
        }
        if (WaterTag[blockIndex]) {
            PyObject *IntObj = PyLong_FromLongLong(block_index_array_pointer) ;
            PyDict_SetItem(CotainDict, IntObj, WaterIndex);
            Py_DECREF(IntObj);
        }

        x++;
        if (x >= LengthX) {x = 0; z++;}
        if (z >= LengthZ) {z = 0; y++;}
        positionInInt = blockIndex = 0; 
    }
    return NBTBlockMap;
}

static PyObject* codecs_parser_litematic(PyObject *self, PyObject *args) {
    PyObject *blockMapArray, *blockIndexArray, *CommonIndexArray, *blockNBTBitArray;
    PyObject *CotainDict, *WaterTagArray, *WaterIndex;
    Py_ssize_t OriginX, OriginY, OriginZ;
    Py_ssize_t SizeX, SizeY, SizeZ;
    Py_ssize_t RegionOriginX, RegionOriginY, RegionOriginZ;
    Py_ssize_t RegionSizeX, RegionSizeY, RegionSizeZ;
    Py_ssize_t BitsPerBlock;

    if (!PyArg_ParseTuple(args, "OOOOOOOnnnnnnnnnnnnn", 
        &blockMapArray, &blockIndexArray, &CommonIndexArray, &blockNBTBitArray,
        &CotainDict, &WaterTagArray, &WaterIndex,
        &OriginX, &OriginY, &OriginZ, 
        &SizeX, &SizeY, &SizeZ, 
        &RegionOriginX, &RegionOriginY, &RegionOriginZ, 
        &RegionSizeX, &RegionSizeY, &RegionSizeZ,
        &BitsPerBlock)) return NULL;

    Py_ssize_t DeltaX = RegionOriginX - OriginX;
    Py_ssize_t DeltaY = RegionOriginY - OriginY;
    Py_ssize_t DeltaZ = RegionOriginZ - OriginZ;
    Py_ssize_t AndOperatInt = (Py_ssize_t)(pow(2.0, (double)BitsPerBlock) - 1);
    Py_ssize_t RegionVolume = RegionSizeX * RegionSizeY * RegionSizeZ;
    unsigned short *blockMap = (unsigned short *)GetArrayAttr(blockMapArray).pointer;
    unsigned long long *blockIndex = (unsigned long long *)GetArrayAttr(blockIndexArray).pointer;
    unsigned short *CommonIndex = (unsigned short *)GetArrayAttr(CommonIndexArray).pointer;
    unsigned short *blockNBTBit = (unsigned short *)GetArrayAttr(blockNBTBitArray).pointer;
    unsigned short *WaterTag = (unsigned short *)GetArrayAttr(WaterTagArray).pointer;
    PyObject *NBTBlockMap = PyDict_New();
    if (!NBTBlockMap) return NULL;

    long long x = 0, y = 0, z = 0;
    for (long long i = 0; i < RegionVolume; i++) {
        long long start_offset = i * BitsPerBlock;
        long long start_arr_index = start_offset / 64; 
        long long end_arr_index = ((i + 1) * BitsPerBlock - 1) / 64;
        long long start_bit_offset = start_offset % 64;
        long long block_index = 0;
        unsigned long long BlockData1 = blockIndex[start_arr_index];
        unsigned long long BlockData2 = blockIndex[end_arr_index];

        if (start_arr_index == end_arr_index) 
            block_index = (BlockData1 >> start_bit_offset) & AndOperatInt ;
        else {
            long long end_offset = 64 - start_bit_offset;
            long long val = (BlockData1 >> start_bit_offset) | (BlockData2 << end_offset);
            block_index = val & AndOperatInt;
        }

        unsigned short common_index = blockMap[block_index];
        long long block_index_array_pointer = (x + DeltaX) * (SizeY * SizeZ) + (y + DeltaY) * SizeZ + (z + DeltaZ);
        CommonIndex[block_index_array_pointer] = common_index;
        
        unsigned short BlockType = blockNBTBit[common_index];
        if (BlockType) {
            PyObject *key = PyLong_FromLongLong(block_index_array_pointer);
            PyObject *value = PyLong_FromLongLong(BlockType);
            PyDict_SetItem(NBTBlockMap, key, value);
            Py_DECREF(key);
            Py_DECREF(value);
        }
        if (WaterTag[common_index]) {
            PyObject *IntObj = PyLong_FromLongLong(block_index_array_pointer) ;
            PyDict_SetItem(CotainDict, IntObj, WaterIndex);
            Py_DECREF(IntObj);
        }

        x++;
        if (x >= RegionSizeX) {x = 0; z++;}
        if (z >= RegionSizeZ) {z = 0; y++;}
        if (y >= RegionSizeY) {break;}
    }

    return NBTBlockMap;
}

static PyObject* handling_waterlog(PyObject *self, PyObject *args) {
    PyObject *BlockIndexArray, *WaterLogDict, *BlockPaletteList, *VolumeArray;
    if (!PyArg_ParseTuple(args, "OOOO", &BlockIndexArray, &WaterLogDict, &BlockPaletteList, &VolumeArray)) return NULL;
    
    Py_ssize_t PaletteLen = PyList_Size(BlockPaletteList);
    struct ArrayAttr SizeArrayAttr = GetArrayAttr(VolumeArray);
    unsigned short *BlockIndex = (unsigned short *)GetArrayAttr(BlockIndexArray).pointer;
    unsigned char *BlockWaterLogArray = calloc(PaletteLen, sizeof(unsigned char));
    long long SizeX = SizeArrayAttr.GetArrayValue(&SizeArrayAttr, 0);
    long long SizeY = SizeArrayAttr.GetArrayValue(&SizeArrayAttr, 1);
    long long SizeZ = SizeArrayAttr.GetArrayValue(&SizeArrayAttr, 2);
    long return_code = 0;
    PyObject *WaterBlockIndexObject = NULL;

    for (Py_ssize_t i = 0; i < PaletteLen; i++) {
        PyObject *BlockObj = PyList_GetItem(BlockPaletteList, i);
        PyObject *BlockName = PyObject_GetAttrString(BlockObj, "name");
        PyObject *WaterlogBool = PyObject_GetAttrString(BlockObj, "waterlogged");
        if (WaterlogBool == Py_True) BlockWaterLogArray[i] = 1;
        else if (!PyUnicode_CompareWithASCIIString(BlockName, "minecraft:seagrass")) BlockWaterLogArray[i] = 1;
        else if (!PyUnicode_CompareWithASCIIString(BlockName, "minecraft:kelp")) BlockWaterLogArray[i] = 1;
        Py_DECREF(BlockName);
        Py_DECREF(WaterlogBool);
    }

    for (Py_ssize_t i = 0; i < PaletteLen; i++) {
        PyObject *BlockObj = PyList_GetItem(BlockPaletteList, i);
        PyObject *BlockID = PyObject_GetAttrString(BlockObj, "name");
        int result = PyUnicode_CompareWithASCIIString(BlockID, "minecraft:water");
        Py_DECREF(BlockID);
        if (result == 0) {WaterBlockIndexObject = PyLong_FromSsize_t(i); break;}
    }
    if (WaterBlockIndexObject == NULL) {
        WaterBlockIndexObject = PyLong_FromSsize_t(PaletteLen); 
        return_code = 1;
    }
    
    for (long long x = 0; x < SizeX; x++) {
        for (long long y = 0; y < SizeY; y++) {
            for (long long z = 0; z < SizeZ; z++) {
                long long index_pointer_1 = x * (SizeY * SizeZ) + y * SizeZ + z;
                unsigned short value1 = BlockIndex[index_pointer_1];
                if (!BlockWaterLogArray[value1]) continue;
                PyObject *IntObj = PyLong_FromLongLong(index_pointer_1) ;
                PyDict_SetItem(WaterLogDict, IntObj, WaterBlockIndexObject);
                Py_DECREF(IntObj);
            }
        }
    }
    
    Py_DECREF(WaterBlockIndexObject);
    free(BlockWaterLogArray);
    return PyBool_FromLong(return_code);
}



static PyMethodDef Methods[] = {
    {"codecs_parser_schematic", codecs_parser_schematic, METH_VARARGS, "speed parser schematic file C API"},
    {"codecs_parser_schem", codecs_parser_schem, METH_VARARGS, "speed parser schem file C API"},
    {"codecs_parser_litematic", codecs_parser_litematic, METH_VARARGS, "speed parser schem litematic C API"},
    {"heightmap_commonstructure", heightmap_commonstructure, METH_VARARGS, "split CommonStructure fast C API"},
    {"split_commonstructure", split_commonstructure, METH_VARARGS, "split CommonStructure fast C API"},
    {"handling_waterlog", handling_waterlog, METH_VARARGS, "handling waterlog C API"},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef module = {
    PyModuleDef_HEAD_INIT,
    "MCBEStructure_C_API",
    NULL,
    -1,
    Methods
};

PyMODINIT_FUNC PyInit_MCBEStructure_C_API(void) {
    return PyModule_Create(&module);
}