#define Py_LIMITED_API 0x03080000
#define PY_SSIZE_T_CLEAN 1
#include <Python.h>
#include <bytesobject.h>
#include <structmember.h>

#include <brotli/decode.h>
#include <brotli/encode.h>

#if PY_MAJOR_VERSION >= 3
#define PyInt_Check PyLong_Check
#define PyInt_AsLong PyLong_AsLong
#else
#define Py_ARRAY_LENGTH(array)  (sizeof(array) / sizeof((array)[0]))
#endif

static PyObject *BrotliError;

/* -----------------------------------
     BlocksOutputBuffer code
   ----------------------------------- */
typedef struct {
    /* List of blocks */
    PyObject *list;
    /* Number of whole allocated size. */
    Py_ssize_t allocated;
} BlocksOutputBuffer;
typedef struct { BrotliEncoderState *enc; } brotli_Compressor;

static const char unable_allocate_msg[] = "Unable to allocate output buffer.";

/* Block size sequence */
#define KB (1024)
#define MB (1024*1024)
static const Py_ssize_t BUFFER_BLOCK_SIZE[] =
    { 32*KB, 64*KB, 256*KB, 1*MB, 4*MB, 8*MB, 16*MB, 16*MB,
      32*MB, 32*MB, 32*MB, 32*MB, 64*MB, 64*MB, 128*MB, 128*MB,
      256*MB };
#undef KB
#undef MB

/* According to the block sizes defined by BUFFER_BLOCK_SIZE, the whole
   allocated size growth step is:
    1   32 KB       +32 KB
    2   96 KB       +64 KB
    3   352 KB      +256 KB
    4   1.34 MB     +1 MB
    5   5.34 MB     +4 MB
    6   13.34 MB    +8 MB
    7   29.34 MB    +16 MB
    8   45.34 MB    +16 MB
    9   77.34 MB    +32 MB
    10  109.34 MB   +32 MB
    11  141.34 MB   +32 MB
    12  173.34 MB   +32 MB
    13  237.34 MB   +64 MB
    14  301.34 MB   +64 MB
    15  429.34 MB   +128 MB
    16  557.34 MB   +128 MB
    17  813.34 MB   +256 MB
    18  1069.34 MB  +256 MB
    19  1325.34 MB  +256 MB
    20  1581.34 MB  +256 MB
    21  1837.34 MB  +256 MB
    22  2093.34 MB  +256 MB
    ...
*/

/* Initialize the buffer, and grow the buffer.
   Return 0 on success
   Return -1 on failure
*/
static inline int BlocksOutputBuffer_InitAndGrow(BlocksOutputBuffer *buffer, size_t *avail_out, uint8_t **next_out) {
    PyObject *b;
    const Py_ssize_t block_size = BUFFER_BLOCK_SIZE[0];

    // Ensure .list was set to NULL, for BlocksOutputBuffer_OnError().
    assert(buffer->list == NULL);

    // The first block
    b = PyBytes_FromStringAndSize(NULL, block_size);
    if (b == NULL) {
        return -1;
    }

    // Create list
    buffer->list = PyList_New(1);
    if (buffer->list == NULL) {
        Py_DECREF(b);
        return -1;
    }
    PyList_SetItem(buffer->list, 0, b);

    // Set variables
    buffer->allocated = block_size;

    *avail_out = (size_t) block_size;
    *next_out = (uint8_t*) PyBytes_AsString(b);
    return 0;
}

/* Grow the buffer. The avail_out must be 0, please check it before calling.
   Return 0 on success
   Return -1 on failure
*/
static inline int BlocksOutputBuffer_Grow(BlocksOutputBuffer *buffer, size_t *avail_out, uint8_t **next_out) {
    PyObject *b;
    const Py_ssize_t list_len = Py_SIZE(buffer->list);
    Py_ssize_t block_size;

    // Ensure no gaps in the data
    assert(*avail_out == 0);

    // Get block size
    if (list_len < (Py_ssize_t) Py_ARRAY_LENGTH(BUFFER_BLOCK_SIZE)) {
        block_size = BUFFER_BLOCK_SIZE[list_len];
    } else {
        block_size = BUFFER_BLOCK_SIZE[Py_ARRAY_LENGTH(BUFFER_BLOCK_SIZE) - 1];
    }

    // Check buffer->allocated overflow
    if (block_size > PY_SSIZE_T_MAX - buffer->allocated) {
        PyErr_SetString(PyExc_MemoryError, unable_allocate_msg);
        return -1;
    }

    // Create the block
    b = PyBytes_FromStringAndSize(NULL, block_size);
    if (b == NULL) {
        PyErr_SetString(PyExc_MemoryError, unable_allocate_msg);
        return -1;
    }
    if (PyList_Append(buffer->list, b) < 0) {
        Py_DECREF(b);
        return -1;
    }
    Py_DECREF(b);

    // Set variables
    buffer->allocated += block_size;

    *avail_out = (size_t) block_size;
    *next_out = (uint8_t*) PyBytes_AsString(b);
    return 0;
}

/* Finish the buffer.
   Return a bytes object on success
   Return NULL on failure
*/
static inline PyObject *BlocksOutputBuffer_Finish(BlocksOutputBuffer *buffer, size_t avail_out) {
    PyObject *result, *block;
    const Py_ssize_t list_len = Py_SIZE(buffer->list);

    // Fast path for single block
    if ((list_len == 1 && avail_out == 0) ||
        (list_len == 2 && Py_SIZE(PyList_GetItem(buffer->list, 1)) == (Py_ssize_t) avail_out))
    {
        block = PyList_GetItem(buffer->list, 0);
        Py_INCREF(block);

        Py_CLEAR(buffer->list);
        return block;
    }

    // Final bytes object
    result = PyBytes_FromStringAndSize(NULL, buffer->allocated - avail_out);
    if (result == NULL) {
        PyErr_SetString(PyExc_MemoryError, unable_allocate_msg);
        return NULL;
    }

    // Memory copy
    if (list_len > 0) {
        char *posi = PyBytes_AsString(result);

        // Blocks except the last one
        Py_ssize_t i = 0;
        for (; i < list_len-1; i++) {
            block = PyList_GetItem(buffer->list, i);
            memcpy(posi, PyBytes_AsString(block), Py_SIZE(block));
            posi += Py_SIZE(block);
        }
        // The last block
        block = PyList_GetItem(buffer->list, i);
        memcpy(posi, PyBytes_AsString(block), Py_SIZE(block) - avail_out);
    } else {
        assert(Py_SIZE(result) == 0);
    }

    Py_CLEAR(buffer->list);
    return result;
}

/* Clean up the buffer */
static inline void BlocksOutputBuffer_OnError(BlocksOutputBuffer *buffer) {
    Py_CLEAR(buffer->list);
}


static int as_bounded_int(PyObject *o, int* result, int lower_bound, int upper_bound) {
  long value = PyInt_AsLong(o);
  if ((value < (long) lower_bound) || (value > (long) upper_bound)) {
    return 0;
  }
  *result = (int) value;
  return 1;
}

static int mode_convertor(PyObject *o, BrotliEncoderMode *mode) {
  if (!PyInt_Check(o)) {
    PyErr_SetString(BrotliError, "Invalid mode");
    return 0;
  }

  int mode_value = -1;
  if (!as_bounded_int(o, &mode_value, 0, 255)) {
    PyErr_SetString(BrotliError, "Invalid mode");
    return 0;
  }
  *mode = (BrotliEncoderMode) mode_value;
  if (*mode != BROTLI_MODE_GENERIC &&
      *mode != BROTLI_MODE_TEXT &&
      *mode != BROTLI_MODE_FONT) {
    PyErr_SetString(BrotliError, "Invalid mode");
    return 0;
  }

  return 1;
}

static int quality_convertor(PyObject *o, int *quality) {
  if (!PyInt_Check(o)) {
    PyErr_SetString(BrotliError, "Invalid quality");
    return 0;
  }

  if (!as_bounded_int(o, quality, 0, 11)) {
    PyErr_SetString(BrotliError, "Invalid quality. Range is 0 to 11.");
    return 0;
  }

  return 1;
}

static int lgwin_convertor(PyObject *o, int *lgwin) {
  if (!PyInt_Check(o)) {
    PyErr_SetString(BrotliError, "Invalid lgwin");
    return 0;
  }

  if (!as_bounded_int(o, lgwin, 10, 24)) {
    PyErr_SetString(BrotliError, "Invalid lgwin. Range is 10 to 24.");
    return 0;
  }

  return 1;
}

static int lgblock_convertor(PyObject *o, int *lgblock) {
  if (!PyInt_Check(o)) {
    PyErr_SetString(BrotliError, "Invalid lgblock");
    return 0;
  }

  if (!as_bounded_int(o, lgblock, 0, 24) || (*lgblock != 0 && *lgblock < 16)) {
    PyErr_SetString(BrotliError, "Invalid lgblock. Can be 0 or in range 16 to 24.");
    return 0;
  }

  return 1;
}




static PyObject* compress_stream(BrotliEncoderState* enc, BrotliEncoderOperation op, uint8_t* input, size_t input_length) {
  BROTLI_BOOL ok;

  size_t available_in = input_length;
  const uint8_t* next_in = input;

  size_t available_out;
  uint8_t* next_out;
  BlocksOutputBuffer buffer = {.list=NULL};
  PyObject *ret;

  if (BlocksOutputBuffer_InitAndGrow(&buffer, &available_out, &next_out) < 0) goto error;

  while (1) {
    Py_BEGIN_ALLOW_THREADS
    ok = BrotliEncoderCompressStream(enc, op, &available_in, &next_in, &available_out, &next_out, NULL);
    Py_END_ALLOW_THREADS
    if (!ok) goto error;

    if (available_in || BrotliEncoderHasMoreOutput(enc)) {
      if (available_out == 0) {
        if (BlocksOutputBuffer_Grow(&buffer, &available_out, &next_out) < 0) {
          goto error;
        }
      }
      continue;
    }

    break;
  }

  ret = BlocksOutputBuffer_Finish(&buffer, available_out);
  if (ret != NULL) return ret;

error:
  BlocksOutputBuffer_OnError(&buffer);
  return NULL;
}

static PyObject* brotli_Compressor_process(brotli_Compressor *self, unsigned char *bytes, Py_ssize_t length) {
  PyObject* ret;

  if (!self->enc) goto error;

  ret = compress_stream(self->enc, BROTLI_OPERATION_PROCESS, (uint8_t*)bytes, length);
  if (ret != NULL) goto finally;

error:
  PyErr_SetString(BrotliError, "BrotliEncoderCompressStream failed while processing the stream");
  ret = NULL;

finally:
  return ret;
}

static PyObject* brotli_Compressor_finish(brotli_Compressor *self) {
  PyObject *ret;

  if (!self->enc) goto error;

  ret = compress_stream(self->enc, BROTLI_OPERATION_FINISH, NULL, 0);
  if (ret == NULL || !BrotliEncoderIsFinished(self->enc)) goto error;
  goto finally;

error:
  PyErr_SetString(BrotliError, "BrotliEncoderCompressStream failed while finishing the stream");
  ret = NULL;
finally:
  return ret;
}


static PyObject *brotli_compress(PyObject *self, PyObject *args, PyObject *keywds) {
  brotli_Compressor *Compressor = malloc(sizeof(brotli_Compressor));
  BrotliEncoderMode mode = (BrotliEncoderMode) -1;
  unsigned char *input = NULL;
  Py_ssize_t input_len = 0;
  int quality = -1;
  int lgwin = -1;
  int lgblock = -1;
  int ok;

  static const char *kwlist[] = {"", "mode", "quality", "lgwin", "lgblock", NULL};
  ok = PyArg_ParseTupleAndKeywords(args, keywds, "y#|O&O&O&O&:Compress",
    (char **) kwlist, &input, &input_len,
    &mode_convertor, &mode, &quality_convertor, &quality,
    &lgwin_convertor, &lgwin, &lgblock_convertor, &lgblock);
  if (!ok) return NULL;
  Compressor->enc = BrotliEncoderCreateInstance(0, 0, 0);

  if ((int) mode != -1) BrotliEncoderSetParameter(Compressor->enc, BROTLI_PARAM_MODE, (uint32_t)mode);
  if (quality != -1) BrotliEncoderSetParameter(Compressor->enc, BROTLI_PARAM_QUALITY, (uint32_t)quality);
  if (lgwin != -1) BrotliEncoderSetParameter(Compressor->enc, BROTLI_PARAM_LGWIN, (uint32_t)lgwin);
  if (lgblock != -1) BrotliEncoderSetParameter(Compressor->enc, BROTLI_PARAM_LGBLOCK, (uint32_t)lgblock);

  PyObject *bytes1 = brotli_Compressor_process(Compressor, input, input_len);
  PyObject *bytes2 = brotli_Compressor_finish(Compressor);

  return PyNumber_Add(bytes1, bytes2);
}

static PyObject *brotli_decompress(PyObject *self, PyObject *args) {
  BrotliDecoderState* state;
  BrotliDecoderResult result;

  const uint8_t* next_in;
  size_t available_in;

  uint8_t* next_out;
  size_t available_out;
  BlocksOutputBuffer buffer = {.list=NULL};
  PyObject *ret;

  unsigned char *input = NULL;
  Py_ssize_t input_len = 0;
  int ok;

  ok = PyArg_ParseTuple(args, "y#", &input, &input_len);
  if (!ok) return NULL;

  state = BrotliDecoderCreateInstance(0, 0, 0);
  next_in = input;
  available_in = input_len;

  if (BlocksOutputBuffer_InitAndGrow(&buffer, &available_out, &next_out) < 0) goto error;

  while (1) {
    Py_BEGIN_ALLOW_THREADS
    result = BrotliDecoderDecompressStream(
      state, &available_in, &next_in, &available_out, &next_out, 0);
    Py_END_ALLOW_THREADS

    if (result == BROTLI_DECODER_RESULT_NEEDS_MORE_OUTPUT) {
      if (available_out == 0) {
        if (BlocksOutputBuffer_Grow(&buffer, &available_out, &next_out) < 0) goto error;
      }
      continue;
    }

    break;
  }

  if (result != BROTLI_DECODER_RESULT_SUCCESS || available_in != 0) goto error;
  ret = BlocksOutputBuffer_Finish(&buffer, available_out);
  if (ret != NULL) goto finally;

error:
  BlocksOutputBuffer_OnError(&buffer);
  PyErr_SetString(BrotliError, "BrotliDecompress failed");
  ret = NULL;

finally:
  BrotliDecoderDestroyInstance(state);
  return ret;
}

static PyMethodDef brotli_methods[] = {
  {"decompress", (PyCFunction)brotli_decompress, METH_VARARGS, ""},
  {"compress", (PyCFunction)brotli_compress, METH_VARARGS|METH_KEYWORDS, ""},
  {NULL, NULL, 0, NULL}
};

#define INIT_BROTLI   PyInit__brotli
#define CREATE_BROTLI PyModule_Create(&brotli_module)
#define RETURN_BROTLI return m
#define RETURN_NULL return NULL
PyDoc_STRVAR(brotli_doc, "Implementation module for the Brotli library.");
static struct PyModuleDef brotli_module = {
  PyModuleDef_HEAD_INIT,
  "_brotli",      /* m_name */
  brotli_doc,     /* m_doc */
  0,              /* m_size */
  brotli_methods, /* m_methods */
  NULL,           /* m_reload */
  NULL,           /* m_traverse */
  NULL,           /* m_clear */
  NULL            /* m_free */
};

PyMODINIT_FUNC INIT_BROTLI(void) {
  PyObject *m = CREATE_BROTLI;

  BrotliError = PyErr_NewException((char*) "brotli.error", NULL, NULL);
  if (BrotliError != NULL) {
    Py_INCREF(BrotliError);
    PyModule_AddObject(m, "error", BrotliError);
  }

  PyModule_AddIntConstant(m, "MODE_GENERIC", (int) BROTLI_MODE_GENERIC);
  PyModule_AddIntConstant(m, "MODE_TEXT", (int) BROTLI_MODE_TEXT);
  PyModule_AddIntConstant(m, "MODE_FONT", (int) BROTLI_MODE_FONT);

  char version[16];
  uint32_t decoderVersion = BrotliDecoderVersion();
  snprintf(version, sizeof(version), "%d.%d.%d",
      decoderVersion >> 24, (decoderVersion >> 12) & 0xFFF, decoderVersion & 0xFFF);
  PyModule_AddStringConstant(m, "__version__", version);

  RETURN_BROTLI;
}
